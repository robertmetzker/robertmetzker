---
name: Build ETL to populate Model
about: Etl steps to populate model
title: ETL steps for Model
labels: deployment
assignees: 
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] Build Code to populate dimensions for Premium Fact Table
- [ ] QA Dimensions for Premium Fact Table
- [ ] Build Code to populate Premium Fact Table
- [ ] QA Premium Fact Table Load
- [ ] Present to BI Team to build dashboards and give feedback
- [ ] Reengage Business for UAT
- [ ] Develop ETL Code based on feedback from BI Team and Business UAT
