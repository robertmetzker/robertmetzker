---
name: Source Load
about: Data Load
title: Source data load
labels: data load
assignees: 
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] Load data into Source Schema
- [ ] Verify row Counts

Please load the following source table from this database. 
