---
name: History Rebuild 
about: History Rebuild
title: History Rebuild
labels: bug, deployment, manual fix
assignees: 
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] Update history.xlsx if columns are added, removed, or renamed.
- [ ] Upload modified history.xlsx
- [ ] Rebuild history SQL via generate_history.py
- [ ] Drop original history table in HISTORY schema.
- [ ] Run generated history SQL -or-
- [ ] Create table as select * from DSV view into HISTORY schema as starting point
- [ ] Drop / rebuild STEP1 as a copy of HISTORY
- [ ] If new HISTORY SQL, create a pull request to merge back into Main.

Please remove unnecessary steps when creating the issue.
This should be a one-time fix for each environment.  Once completed, this issue should be closed.
