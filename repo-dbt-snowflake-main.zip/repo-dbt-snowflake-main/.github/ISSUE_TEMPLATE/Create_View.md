---
name: View Creation
about: View Creation
title: Business View Creation
labels: deployment
assignees: 
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] Update Release Notes
- [ ] Create issue for VIEW Deployment
- [ ] Assign Business Mart

Views are created as: select * from ref{{source}}
