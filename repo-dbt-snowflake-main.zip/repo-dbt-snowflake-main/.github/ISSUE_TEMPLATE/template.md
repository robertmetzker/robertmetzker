---
name: DBT
about: DBT development
title: DBT
labels: 
assignees: kumarganap, robertmetzker
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] triage
- [ ] developed
- [ ] unit test
