---
name: dbt run --model 
about: DBT development
title: DBT data load
labels: 
assignees: 10111831, 10140138
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] Extract Source Table
- [ ] Load data into Source Schema
- [ ] Execute dbt code to load STG Table
- [ ] Add to source.yml file
- [ ] Run View creator python program

This table needs to be reloaded due to source table changes.
