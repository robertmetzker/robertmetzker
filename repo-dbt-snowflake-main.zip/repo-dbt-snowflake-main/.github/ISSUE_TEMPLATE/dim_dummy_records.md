---
name: DIM dummy records
about: DBT development
title: DIM dummy records
labels: dim default records 
assignees: 10140138, 10111831
projects: Snowflake (Data Warehouse Redesign)

---

The DML for the Default records
- [ ] DELETE FROM "DEV_EDW"."EDW_STAGING"."DIM_DUMMY" WHERE TABLE_NAME LIKE 'DIM_TABLE_NAME%';
- [ ] INSERT INTO "DEV_EDW"."EDW_STAGING"."DIM_DUMMY" values
    ('DIM_CPT1','INSERT INTO EDW_STAGING_DIM.DIM_CPT (CPT_HKEY, UNIQUE_ID_KEY, PROCEDURE_CODE, PROCEDURE_DESC, PROCEDURE_SERVICE_TYPE_DESC, CPT_PAYMENT_CATEGORY, CPT_FEE_SCHEDULE_DESC, LOAD_DATETIME,CURRENT_RECORD_IND, RECORD_EFFECTIVE_DATE, PRIMARY_SOURCE_SYSTEM)
    SELECT MD5($1), MD5($2), $3, $4, $5, $6, $7, $8, $9, $10,$11 FROM VALUES (''99999'', ''99999'', ''UNK'', ''UNKNOWN'', ''UNKNOWN'', ''UNKNOWN'', ''UNKNOWN'', SYSDATE(), ''Y'' ,''1901-01-01'', ''MANUAL ENTRY'');' );
- [ ] Manually run the above insert statements to the DIM table 
- [ ] Commit insert
- [ ] Link it to the associated pull request
