---
name: DBT stg table
about: DBT development
title: DBT stg table
labels: 
assignees: kumarganap, robertmetzker
projects: Snowflake (Data Warehouse Redesign)

---

- [ ] load source data
- [ ] build automated mapping
- [ ] build table
- [ ] run tests
