---
name: DIM Rebuild 
about: DIM Rebuild
title: DIM Rebuild
labels: bug, deployment, manual fix
assignees: 
projects: Snowflake (Data Warehouse Redesign)

---
replace: xxxxxxx   with the appropriate model name
replace: {{env}}   with the appropriate environment

If the table structure has changed, then replace the DEV_VIEW with replacement sql:
  ==> IN SNOWFLAKE: CREATE OR REPLACE VIEW "DEV_VIEWS".xxxxxx AS SELECT * FROM "DEV_SOURCE".xxxxxx;

set prof=%USERPROFILE%\Desktop\repo-dbt-engineering\dbt_root\profiles\dbt_edw_svc_batch 
set proj=%USERPROFILE%\Desktop\repo-dbt-engineering\dbt_root\projects\repo-dbt-snowflake

dbt run --profiles-dir %prof%  --project-dir %proj% --models STG_CPT_PAYMENT_CATEGORY
dbt run --profiles-dir %prof%  --project-dir %proj% --models DST_CPT_CODE
dbt run --profiles-dir %prof%  --project-dir %proj% --models DSV_CPT_CODE
dbt run --profiles-dir %prof%  --project-dir %proj% --models DIM_CPT_SNAPSHOT_HISTORY
  ==> IN SNOWFLAKE: CREATE OR REPLACE TABLE {{env}}."EDW_STAGING_SNAPSHOT"."DIM_CPT_SNAPSHOT_STEP1" CLONE {{env}}."HISTORY"."DIM_CPT_SNAPSHOT_HISTORY" ;
dbt snapshot --profiles-dir %prof% --select DIM_CPT_SNAPSHOT_STEP1
dbt run --profiles-dir %prof%  --project-dir %proj% --models DIM_CPT_SCDALL_STEP2
dbt run --profiles-dir %prof%  --project-dir %proj% --models DIM_CPT

  ==> Update DIM_DUMMY.csv if changed or new columns identified for key values.

dbt seed --profiles-dir %prof% --project-dir %proj% 
dbt run-operation insert_dummy --profiles-dir %prof% --project-dir %proj% 
  ==> IN SNOWFLAKE: CREATE OR REPLACE TABLE {{env}}."DIMENSIONS".xxxxx CLONE {{env}}."EDW_STAGING_DIM".xxxxx ;
  ==> IN SNOWFLAKE: ALTER TABLE IF EXISTS {{env}}."DIMENSIONS".xxxxx DROP COLUMN unique_id_key;


Please remove unnecessary steps when creating the issue.
This should be a one-time fix for each environment.  Once completed, this issue should be closed.
