# macros/swap_database.sql
{% macro swap_database() %}

    
    {% set sql= 'alter database PERF_STAGE2 swap with PERF_EDW;' %}
    {% do run_query(sql) %}
    {{ log("database swapped", info=True) }}
    #use role etl_admin
{% endmacro %}