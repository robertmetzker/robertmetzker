{% macro run_grant_alters() %}
{#-
To run it:
    $ dbt seed
    $ dbt run-operation RUN_GRANT_ALTERS

This would then be followed by the GRANT_PROD_USAGE macro...

-#}

{% set tablename_query %}
select
        distinct GRANT_STMT
    from EDW_STAGING.VIEW_ACCESS_CONTROL
{% endset %}

{% set results = run_query(tablename_query) %}
{{ log(tablename_query, info=True) }}

{% if execute %}
{# Return the first column #}
{% set results_list = results.columns[0].values() %}
{% else %}
{% set results_list = [] %}
{% endif %}

{% set query1 %}
    {% for STATEMENTS in results_list %}
            {{STATEMENTS}}
    {% endfor %}
{% endset %}

{% do run_query(query1) %} 
{{ log(query1, info=True) }}

{% set sql='COMMIT;' %}
    {% do run_query(sql) %}
{{ log(sql, info=True) }}


{% endmacro %}
