{% macro create_prd_rollback() %}

{% set sql='create or replace schema PRD_EDW_ROLLBACK.DIMENSIONS clone PRD_EDW.DIMENSIONS;
    create or replace schema PRD_EDW_ROLLBACK.MEDICAL_MART clone PRD_EDW.MEDICAL_MART;' %}
    {% do run_query(sql) %}
    {{ log("Rollback SCHEMA (PRD_EDW_ROLLBACK) created", info=True) }}
    {{ log(sql, info=True) }}

{{ log(sql, info=True) }}
{% endmacro %}
