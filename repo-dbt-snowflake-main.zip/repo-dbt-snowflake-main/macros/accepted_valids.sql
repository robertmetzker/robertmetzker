{% macro test_accepted_valids(model, values) %}

{%- set column_name = kwargs.get('column_name', kwargs.get('field')) -%}
{%  set ignore_hkey = kwargs.get('ignore', kwargs.get('arg')) %}
{%  set quote_values = kwargs.get('quote', True) %}


with all_values as(
  select distinct {{ column_name }} as value_field
  from {{ model }} 
  {% if ignore_hkey %}
      where {{ ignore_hkey }} not in ( MD5('99999'), MD5('-1111'), MD5('-2222'), MD5('88888'), MD5('00000') )
  {% endif %}
),

validation_errors as (
  select distinct value_field
  from all_values 
    where value_field not in (
        {% for value in values -%}
            {% if quote_values -%}
            '{{ value }}'
            {%- else -%}
            {{ value }}
            {%- endif -%}
            {%- if not loop.last -%},{%- endif %}
        {%- endfor %}
        )
)

select *
from validation_errors

{% endmacro %}
