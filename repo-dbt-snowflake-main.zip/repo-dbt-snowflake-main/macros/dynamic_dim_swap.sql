{% macro dynamic_dim_swap() %}

{%set swapsql %}
CREATE OR REPLACE TABLE DIMENSIONS.{{- env_var('modelname') }} CLONE EDW_STAGING_DIM.{{- env_var('modelname') }};
{% endset %}

{% set results = run_query(swapsql) %}
{{ log(swapsql, info=True) }}

{%set altersql %}
ALTER TABLE IF EXISTS DIMENSIONS.{{- env_var('modelname') }} DROP COLUMN unique_id_key;
{% endset %}

{% set results = run_query(altersql) %}
{{ log(altersql, info=True) }}


{% set sql='COMMIT;' %}
    {% do run_query(sql) %}
{{ log(sql, info=True) }}


{% endmacro %}
