{% macro test_has_default(model, column_name, hashval, hash) %}

with meet_condition as (

    select count( {{ column_name }} ) as matches from {{ model }}
    where PRIMARY_SOURCE_SYSTEM = 'MANUAL ENTRY' 
    and {{ column_name }} in (
        {% for value in hashval %}
        {%- if hash == False -%} 
        '{{ value }}' 
        {%- else -%}
        MD5( '{{ value }}' )
        {% endif -%}
        {% if not loop.last -%} , {%- endif %}
        {%- endfor %}
    )
),
equal_cnt as (
    select ( case when MATCHES = {{ hashval|length }}
     then 0 else 
          (case when matches = 0 then 1 else matches end)
     end ) as test
    from meet_condition
 )
select * from equal_cnt where test <> 0

{% endmacro %}
