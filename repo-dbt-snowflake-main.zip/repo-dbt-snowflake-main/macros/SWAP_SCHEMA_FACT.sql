{% macro swap_schema_fact() %}

{% set sql='create or replace SCHEMA MEDICAL_MART clone EDW_STG_MEDICAL_MART;' %}
    {% do run_query(sql) %}
    {{ log("Fact (MEDICAL_MART) SCHEMA cloned over using EDW_STG_MEDICAL_MART", info=True) }}
    {{ log(sql, info=True) }}

{% set sql='grant usage on schema MEDICAL_MART to role BUS_ANALYST; grant select on all tables in schema MEDICAL_MART to role BUS_ANALYST;
    grant usage on schema MEDICAL_MART to role ACT_INQ; grant select on all tables in schema MEDICAL_MART to role ACT_INQ;
    grant usage on schema MEDICAL_MART to role BATCH_READ; grant select on all tables in schema MEDICAL_MART to role BATCH_READ;'
%}
    {% do run_query(sql) %}
    {{ log(sql, info=True) }}


{% set sql='create or replace SCHEMA CLAIMS_MART clone EDW_STG_CLAIMS_MART;' %}
    {% do run_query(sql) %}
    {{ log("Fact (CLAIMS_MART) SCHEMA cloned over using EDW_STG_CLAIMS_MART", info=True) }}
    {{ log(sql, info=True) }}

{% set sql='grant usage on schema CLAIMS_MART to role BUS_ANALYST; grant select on all tables in schema CLAIMS_MART to role BUS_ANALYST;
    grant usage on schema CLAIMS_MART to role ACT_INQ; grant select on all tables in schema CLAIMS_MART to role ACT_INQ;
    grant usage on schema CLAIMS_MART to role BATCH_READ; grant select on all tables in schema CLAIMS_MART to role BATCH_READ;'
%}
    {% do run_query(sql) %}
    {{ log(sql, info=True) }}


{% set sql='create or replace SCHEMA POLICY_MART clone EDW_STG_POLICY_MART;' %}
    {% do run_query(sql) %}
    {{ log("Fact (POLICY_MART) SCHEMA cloned over using EDW_STG_POLICY_MART", info=True) }}
    {{ log(sql, info=True) }}

{% set sql='grant usage on schema POLICY_MART to role BUS_ANALYST; grant select on all tables in schema POLICY_MART to role BUS_ANALYST;
    grant usage on schema POLICY_MART to role ACT_INQ; grant select on all tables in schema POLICY_MART to role ACT_INQ;
    grant usage on schema POLICY_MART to role BATCH_READ; grant select on all tables in schema POLICY_MART to role BATCH_READ;'
%}
    {% do run_query(sql) %}
    {{ log(sql, info=True) }}
{% endmacro %}
