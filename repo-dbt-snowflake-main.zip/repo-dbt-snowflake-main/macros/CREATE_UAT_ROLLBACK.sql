{% macro create_uat_rollback() %}

{% set sql='create or replace schema UAT_EDW_ROLLBACK.DIMENSIONS clone UAT_EDW.DIMENSIONS;
    create or replace schema UAT_EDW_ROLLBACK.MEDICAL_MART clone UAT_EDW.MEDICAL_MART;' %}
    {% do run_query(sql) %}
    {{ log("Rollback SCHEMA (UAT_EDW_ROLLBACK) created", info=True) }}
    {{ log(sql, info=True) }}

{{ log(sql, info=True) }}
{% endmacro %}
