{% macro swap_schema_dim() %}

{% set sql='create or replace SCHEMA DIMENSIONS clone EDW_STAGING_DIM; ' %}
    {% do run_query(sql) %}
    {{ log("DIMENSIONS SCHEMA cloned over using EDW_STAGING_DIM", info=True) }}
    {{ log(sql, info=True) }}

{% set tablename_query %}
select distinct table_name 
    from INFORMATION_SCHEMA.COLUMNS
    where table_schema = 'EDW_STAGING_DIM'
    and column_name = 'UNIQUE_ID_KEY'
{% endset %}

{% set results = run_query(tablename_query) %}
{{ log(tablename_query, info=True) }}

{% if execute %}
{# Return the first column #}
{% set results_list = results.columns[0].values() %}
{% else %}
{% set results_list = [] %}
{% endif %}
{{ log("DIMS - ", info=True) }}
{{ log(results_list, info=True) }}

{% set dropcols %}
    {% for table in results_list %}
    use schema DIMENSIONS; ALTER TABLE  IF EXISTS {{ table }} DROP COLUMN unique_id_key; 
    {% endfor %}
{% endset %}

{% do run_query(dropcols) %}
{{ log(dropcols, info=True) }}
{{ log("UNIQUE_ID_KEY Columns removed", info=True) }}

{% set usage %}
    grant usage on schema dimensions to role BUS_ANALYST; grant select on all tables in schema dimensions to role BUS_ANALYST;
    grant usage on schema dimensions to role ACT_INQ; grant select on all tables in schema dimensions to role ACT_INQ;
    grant usage on schema dimensions to role BATCH_READ; grant select on all tables in schema dimensions to role BATCH_READ;
{% endset %}

{% do run_query(usage) %}
{{ log(usage, info=True) }}
{{ log("Usage Granted", info=True) }}

{% endmacro %}


