{% macro clone_hist_step1() %}


{% set tablename_query %}
select 'create or replace table EDW_STAGING_SNAPSHOT.' || replace(table_name, 'HISTORY','STEP1') ||' clone HISTORY.' || table_name ||'; ' as clone_stm
from INFORMATION_SCHEMA.TABLES
where table_name like 'DIM%_HISTORY' and table_name not in ('LOAD_HISTORY')
{% endset %}

{% set results = run_query(tablename_query) %}
{{ log(tablename_query, info=True) }}

{% if execute %}
{# Return the first column #}
{% set results_list = results.columns[0].values() %}
{% else %}
{% set results_list = [] %}
{% endif %}

{% set query1 %}
    {% for STATMENTS in results_list %}
            {{STATMENTS}}
    {% endfor %}
{% endset %}


{% do run_query(query1) %} 
{{ log(query1, info=True) }}

{% set sql='COMMIT;' %}
    {% do run_query(sql) %}
{{ log(sql, info=True) }}


{% endmacro %}
