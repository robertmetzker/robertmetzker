{% macro GRANT_PROD_USAGE (role) %}
{#-
To run it:
    $ dbt run-operation GRANT_PROD_USAGE --args {'role':'prod'}

-#}

{% set grant_qry %}
select distinct 'grant USAGE on DATABASE '|| object_database ||'  to ROLE PROD_VIZ;' as "--GRANT SELECTS"
from  snowflake.account_usage.tag_references
where tag_name = 'VIEW_LEVEL' and tag_value = '{{-role-}}' and object_deleted is null
and object_database = 'PRD_EDW'
{% endset %}

    {% set database_usage = run_query(grant_qry) %}
    {% set db_list = database_usage.columns[0].values() %}
    {{ log("grant on DATABASES were performed for ROLE PROD_VIZ", info=True) }}
    {{ log(grant_qry, info=True) }}

    {% set db_sql %}
        {% for STATEMENTS in db_list %}
                {{STATEMENTS}}
        {% endfor %}
    {% endset %}
    {% do run_query(db_sql) %} 

{% set grant_qry %}
select distinct 'grant USAGE on SCHEMA '|| object_database||'.'||object_schema || ' to ROLE PROD_VIZ;' as "--GRANT SELECTS"
from  snowflake.account_usage.tag_references
where tag_name = 'VIEW_LEVEL' and tag_value = '{{-role-}}' and object_deleted is null
and object_database = 'PRD_EDW'
{% endset %}

    {% set schema_usage = run_query(grant_qry) %}
    {% set schema_list = schema_usage.columns[0].values() %}
    {{ log("grant on SCHEMAs were performed for ROLE PROD_VIZ", info=True) }}
    {{ log(grant_qry, info=True) }}

    {% set schema_sql %}
        {% for STATEMENTS in schema_list %}
                {{STATEMENTS}}
        {% endfor %}
    {% endset %}
    {% do run_query(schema_sql) %} 

{% set grant_qry %}
select 'grant SELECT on  '||domain||' '|| object_database||'.'||object_schema||'.'||object_name || ' to ROLE PROD_VIZ;' as "--GRANT SELECTS"
from  snowflake.account_usage.tag_references
where tag_name = 'VIEW_LEVEL' and tag_value = '{{-role-}}' and object_deleted is null
and object_database = 'PRD_EDW'

{% endset %}
    {% set grant_generated_sql = run_query(grant_qry) %}
    {# set run_grants = grant_generated_sql.columns[0].values() #}

{% if execute %}
    {% set run_list = grant_generated_sql.columns[0].values() %}
{% else %}
    {% set run_list = [] %}
{% endif %}


{% set table_sql %}
    {% for STATEMENTS in run_list %}
            {{STATEMENTS}}
    {% endfor %}
{% endset %}


    {{ dbt_utils.log_info("Granting select access on tables flagged for " ~ role ~ " to the PROD_VIZ role.") }}
        {% do run_query(table_sql) %} 
    {{ dbt_utils.log_info("Grants complete.") }}

{% endmacro %}

