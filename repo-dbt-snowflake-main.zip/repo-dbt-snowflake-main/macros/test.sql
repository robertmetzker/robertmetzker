# macros/test.sql
{% macro test() %}

{% set tablename_query %}
INSERT INTO dimensions.DIM_DATE (DATE_KEY, LOAD_DATETIME, PRIMARY_SOURCE_SYSTEM)
VALUES (-1, current_date(), 'MANUAL ENTRY')
{% endset %}

{% do run_query(tablename_query) %}
{{ log(tablename_query, info=True) }}



{% endmacro %}