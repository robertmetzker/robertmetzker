# Operations Manual 

# High Level Rules
- We use version control and branching to deliver changes safely to production
- Small incremental manageable changes
- Our release flow lets us keep main buildable at all times and work from short-lived topic branches
- Release branches never merge back to main (hence cherry picking)
- The engineer starts by syncing to the *latest* commit on **main**
- We work out of a single main, virtually eliminating merge debt
- Pull request flow gives us a common point to force testing, code review, and error detection 
- At the end of each sprint, we create a deployment branch from the main branch
- Simple, trunk-based branching strategy

## Issue Management
- Issue consist of the set of tables required to build a business table (dim/fact)
  - ex: Issue = (stg,dst,dsv,dim)
  - Issues are not attached to individual tables
  - Closed branches can be re-opened/restored to make fixes

## Branch Management

### Developer
- Pull down main
- Work on local copy of main
- Schema sync: clone dev schema (perhaps: dbt run_operation create_rollback)
- Run tests: dbt test, dbt run +/-
- Create DEV branch
  - Naming Standard(Target_Schema + Table_Name + Action_Taken + Columns_Modified) 
    > eg: dimensions_dimdate_change_month_integer
  - Developement code happens in local main
  - Local Schema clone/table build/run tests
- Issue pull request
  - Code sync before pull request
  - Resolve merge conflicts
  - Only valid warnings should survive 
- DEV branch review on github
    - **Denied**
      - Re-work on local main 
      - Re-commit to same DEV branch
    - **Approve**
      - Merge to main
      - Delete branch (dev deletes local branch)

## Release Management

### UAT (pre-release)

- Construct pre-release
  - Release manager builds pre-release and release notes
    - Creation of release zip file
    - Flagged as pre-release
    - Naming standard - 2022-02-R1
    - Other tags (medical, claim, policy, etc)

- Python grabs latest pre-release for UAT run on ETL server
  - Automatic daily vs manual (ETL team)
  - ETL server does not know github/version control exists

### Production (release)
- Non promotion to production
  - Too many commits to cherry pick
  - Dependency problems (deadly embrace)
    - If table is a final stage table there are no downstream impacts
- Production promotion
  - No UAT failures
  - Small UAT Hot Fix cherry pick into the release (If required for emergency changes)
  - Must pass business team validation in UAT
  - Release manager removes pre-release tag
- Python grabs latest release for PROD run on ETL server
  - Automatic daily vs manual request (ETL team)
  - ETL server does not know github/version control exists

# future
    feature flags
    - when expose to prod vs when expose to business

     - cloning
        claim_v1     [clone] ----> claim ---> Tableau
        claim_v2

        later becomes

        claim_v1     
        claim_v2     [clone] ----> claim  ---> Tableau

     - dbt tags
       if these tags: do this
       mark models with tags 
       claim_v1 (model header: tagged with prod, set to be claim)
       claim_v2  (post hook clone to prod environment)
