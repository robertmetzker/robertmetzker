# Post Processing Audits

Both of the post table build/batch run audits reside in the **DEV_EDW.PUBLIC** schema.

I can get some very basic MART information through the use of the **FACT_METRICS** procedure.
To get the aggregates (*count, sum, min, max, average* ) for all of the *COUNT* or *AMOUNT* fields in a MART, use the following syntax:
- call dev_edw.public.FACT_METRICS ('*MART NAME*', *row limit* );

If the row limit is set to 0 or a negative value, all of the metrics will be returned.

e.g.
>`call dev_edw.public.FACT_METRICS ('CLAIMS_MART',0 );`

In this example, it will return all of the aggregates for the COUNT/AMOUNT columns in the **CLAIMS_MART**

|DB     |TABLE_SCHEMA |TABLE_NAME                    |TABLE_COLUMN                     |NUMROWS  |TOTAL      |MIN_VAL|MAX_VAL|ROW_AVG|
|-------|-------------|------------------------------|---------------------------------|---------|-----------|-------|-------|-------|
|DEV_EDW|"CLAIMS_MART"|"FACT_CLAIM_PROGRESS_SNAPSHOT"|"FROI_TO_ARTW_LAG_DAY_COUNT"     |4,670,919|440,595,931|-14,882| 25,788|  94.32|
|DEV_EDW|"CLAIMS_MART"|"FACT_CLAIM_PROGRESS_SNAPSHOT"|"FROI_TO_CLOSED_LAG_DAY_COUNT"  \*|9,055,309|          0|      0|      0|      0|

This may lead me into investigatingwhy the **TOTAL**, **MIN**, **MAX** for **FROI_TO_CLOSED_LAG_DAY_COUNT** are all zeroes.

**NOTE:** Column names will have an asterisk (\*) after them if the TOTAL = 0.

___
Alternately, we can do some basic profiling of a table via the **TABLE_PROFILE** procedure.
It is called in much the same way:
- call dev_edw.public.TABLE_PROFILE ( '*Database*' , '*Schema*', '*Table Name*');

e.g.
> `call dev_edw.public.TABLE_PROFILE ('DEV_EDW','STAGING', 'DST_ACTIVITY');`

or

> `call dev_edw.public.TABLE_PROFILE ('DEV_EDW_32600145','STAGING', 'DST_ACTIVITY');`

Would yields the following results:
|TABLE_DB          |TABLE_SCHEMA|TABLE_NAME    |FIELD_NAME        |TOTAL_ROWS|TOTAL_VALS|TOTAL_BLANKS|PCT_POP|PCT_DIST|MIN_VAL                       |MAX_VAL|TOP_RANK|TOP_RANK_COUNT|NONBLANK_TOP_RANK|NONBLANK_TOP_RANK_COUNT|NONBLANK_TOP_RANK_LENGTH|BOTTOM_RANK|BOTTOM_RANK_COUNT|BOTTOM_RANK_LENGTH|
|------------------|------------|----------    |------------        |----------|----------|------------|-------|--------|-------                       |-------|--------|--------------|-----------------|-----------------------|------------------------|-----------|-----------------|------------------|
|"DEV_EDW_32600145"|"STAGING"   |"DST_ACTIVITY"|"ACTV_ACTN_TYP_NM" \*|   785,207|         1|           0|    100|       0|ADDED                         |ADDED  |ADDED   |       785,207|ADDED            |                785,207|                       5|ADDED      |          785,207|                 5|
|"DEV_EDW_32600145"|"STAGING"   |"DST_ACTIVITY"|"ACTV_DTL_COL_NM" |   785,207|        55|     630,882|  19.65|       0|ACP STATUS                    |WTN    |        |       630,882|INDMPAY          |                 49,450|                       7|WTN        |                1|                 3|


## Table Profile Elements ##
|Column Name             |Description                                                                        |
|------------------------|-----------------------------------------------------------------------------------|
|TABLE_DB                | DATABASE name as specified during the call of the procedure.                      |
|TABLE_SCHEMA            | SCHEMA name as specified during the call of the procedure.                        |
|TABLE_NAME              | TABLE name as specified during the call of the procedure.                         |
|FIELD_NAME              | COLUMN name from the specified table.                                             |
|TOTAL_ROWS              | Total Number of Rows that are populated.                                          |
|TOTAL_VALS              | Total Number of UNIQUE values for the COLUMN                                      |
|TOTAL_BLANKS            | Total Number of Rows that are Blank or contain a NULL value.                      |
|PCT_POP                 | Percent of the COLUMN that is Populated (TOTAL_ROWS-TOTAL_BLANKS / TOTAL_ROWS)    |
|PCT_DIST                | Percent of the COLUMN that is Unique/Distinct (TOTAL_VALS / TOTAL_ROWS )          |
|MIN_VAL                 | The Minimum value in the COLUMN (based on an ascii sort)                          |
|MAX_VAL                 | The Maximum value in the COLUMN (based on an ascii sort)                          |
|TOP_RANK                | The Most frequently occurring value in the COLUMN                                 |
|TOP_RANK_COUNT          | How many rows contain the TOP_RANK value.                                         |
|NONBLANK_TOP_RANK       | The Most frequently occurring non-blank and non-null value in the COLUMN          |
|NONBLANK_TOP_RANK_COUNT | How many rows contain the NONBLANK_TOP_RANK value.                                |
|NONBLANK_TOP_RANK_LENGTH| The length of the NONBLANK_TOP_RANK value.                                        |
|BOTTOM_RANK             | One of the least frequently occurring values in the COLUMN                        |
|BOTTOM_RANK_COUNT       | How many rows contain the BOTTOM_RANK value.                                      |
|BOTTOM_RANK_LENGTH      | TThe length of the BOTTOM_RANK value.                                             |


**NOTE:** Similarly, Field names will have an asterisk (\*) after them if the total number of unique values (TOTAL_VALS) is 1.


# Real World Example #
First, I ran a summary against the CLAIMS_MART to see if there were any data elements whose values do not match my understanding of what they are meant to represent.

>`call dev_edw.public.FACT_METRICS ('CLAIMS_MART',0 );`

![ClaimsMart_Results](./imgs/profile_scenario1.png "CLAIMS_MART Metric example result")

I see that the "FROI_TO_CLOSED_LAG_DAY_COUNT" is flagged with an asterisk, and has a TOTAL, MIN/MAX value of 0.  Since this element is meant to show the number of days between the First Report of Injury until it is closed, zero days do not make sense.   Looking at the mapping for this element, I can see that the logic is probably not determined yet as it has a hard-coded value: `, 0                                                   AS                                    FROI_TO_CLOSED_LAG_DAY_COUNT`


That made sense, but looking through other values, the `FROI_TO_FIRST_PAYMENT_LAG_DAY_COUNT` has an average that is much higher than I would expect.
![FroiPaymentLag](./imgs/froi_payment_lag.png "DSV_CLAIM_PAYMENT_SUMMARY payment lag average")

Looking at the mapping that describes this element, I see that it should be represented by: `DATEDIFF(DAYS, CLAIM_FILE_DATE , least(FIRST_INDEMNITY_PAYMENT_DATE, FIRST_MEDICAL_PAYMENT_DATE)) AS FROI_TO_FIRST_PAYMENT_LAG_DAY_COUNT`

Checking the mapping also yields that the `FIRST_INDEMNITY_PAYMENT_DATE` and `FIRST_MEDICAL_PAYMENT_DATE` both come from the same table.  They can be found in `DSV_CLAIM_PAYMENT_SUMMARY`, so I will run a profile against this table.

>`call dev_edw.public.table_profile('DEV_EDW','STAGING','DSV_CLAIM_PAYMENT_SUMMARY');`

![ClaimPaaymentSummary_Results](./imgs/profile_scenario2.png "DSV_CLAIM_PAYMENT_SUMMARY table profile subset")

Here I see that both fields seem to be populated with dates, but there is a high frequency of **NULL** values.  Those probably affect the calculation since we are doing a *least* operator and non-values will not work.   I will run a test and bring both the original calculation and a modified calculation side-by-side.

![ClaimPaaymentSummary_Comparison](./imgs/profile_scenario3.png "DSV_CLAIM_PAYMENT_SUMMARY calcuation comparison")

Great!  Now to open an issue to work with the ETL team and have the calculation corrected.

