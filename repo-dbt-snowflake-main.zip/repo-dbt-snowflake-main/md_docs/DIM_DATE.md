# DIM_DATE

## DESCRIPTION:
> This table stores related fields for each date, from January 1, 1900 to December 31, 2099.	
  	
  
### TABLE TYPE [(more info)](https://adatis.co.uk/introduction-to-slowly-changing-dimensions-scd-type):    
> Type 1 Dimension[^1]

### GRANULARITY:
> One row per Date  
  
  

**DEFAULT RECORDS:**
| Default | Value |
| ------- | ----- |
| 1 | Unknown Date |
| 2 | Dates prior to 1-1-1900 |
| 3 | Dates after 12-31-2099 |

[^1]: Type 1 Dimensions- Do not contain History.  We Update the record directly. There is no record of historical values, only current state.

