 {{ config(schema = 'EDW_STAGING', tags=["dim"] ) }}
 ----SRC LAYER----
WITH
SCD1 as ( SELECT EOB_CODE, APPLIED_DESC , UNIQUE_ID_KEY    
	from      {{ ref( 'DSV_EOB') }} ),
SCD2 as ( SELECT *    
	from      {{ ref('DIM_EOB_SNAPSHOT_STEP1') }} ),
FINAL as ( SELECT * 
			from  SCD2 
				INNER JOIN SCD1 USING( UNIQUE_ID_KEY )  )
select * from FINAL