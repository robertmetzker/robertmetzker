
 ----SRC LAYER----
WITH
SCD1 as ( SELECT *    from      {{ ref( 'DSV_INVOICE_PROFILE') }} )
select * from SCD1
