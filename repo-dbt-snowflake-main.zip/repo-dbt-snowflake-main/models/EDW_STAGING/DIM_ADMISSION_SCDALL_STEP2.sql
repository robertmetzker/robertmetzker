
 ----SRC LAYER----
WITH
SCD1 as ( SELECT *    from      {{ ref( 'DSV_ADMISSION') }} )
select * from SCD1
