 {{ config(schema = 'EDW_STAGING', tags=["dim"] ) }}
 ----SRC LAYER----
WITH
SCD1 as ( SELECT DISPOSITION_DESC, SOURCE_CODE, ADJUDICATION_PHASE, DISPOSITION_CODE 
, UNIQUE_ID_KEY    
	from      {{ ref( 'DSV_EDIT_EOB_ENTRY') }} )
select * from SCD1