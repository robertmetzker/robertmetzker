account = 'fbhs_gpg.east-us-2.azure' # https://fbhs_gpg.east-us-2.azure.snowflakecomputing.com/fed/login
user = 'robert.metzker@fbwinn.com'
database = 'EDP_BRONZE_DEV'
role = 'DATAREAD_DEV'
warehouse = 'WH_DATAREAD_DEV'
authenticator = 'externalbrowser'  # externalbrowser, snowflake``
CLIENT_SESSION_KEEP_ALIVE = True # 3600 default heartbeat freq in sec