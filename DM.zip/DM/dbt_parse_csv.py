"""
create a dbt source.yml file based on a csv dump of:
    select  
        table_catalog
        , table_schema
        , table_name
    from information_schema.tables
    where is_temporary = 'NO'
    order by table_catalog, table_schema, table_name
"""
import argparse, csv
import pandas as pd

def process_args():
    parser = argparse.ArgumentParser( description="Convert csv to sources.yml")
    parser.add_argument( '-f','--filename', help='filename', required= False)

    args = parser.parse_args()
    # Default file for testing
    if not args.filename:
        args.filename = 'dbt_dump.csv'

    return args

def read_csv( filename ):
    ...
    """
    TABLE_CATALOG,TABLE_SCHEMA,TABLE_NAME
    EDP_BRONZE_DEV,ABHINAV_KODANDA,CUSTOMER_TEST
    """
    csv_data = pd.read_csv( filename )
    return csv_data


def write_source_yml( header ):
    with open('source.yml', 'w') as ymlfile:
        for row in header:
            ymlfile.write( row )


def main():
    ...
    args = process_args()

    print( args.filename )
    header = """
version: 2

sources:
  - name: FBWINN
"""

    # print( header )

    df = read_csv( args.filename )

    # Use Pandas to get the Unique Schema names
    db_list = df.TABLE_CATALOG.unique()
    schema_list = df.TABLE_SCHEMA.unique()
    # table_list = [df.TABLE_NAME.unique()]

    # print(f"Databases: {db_list}")
    # print(f"Schemas: {schema_list}")


    #Loop through the Databases, filter to schemas, and list assoc. tables
    for db in db_list:
        header += f'\n    database: {db.upper()}'
        for schema in schema_list:
            table_list = df[ df.TABLE_SCHEMA == schema]['TABLE_NAME'].unique().tolist()

            header += f'\n    schema: {schema.upper()}'
            header += f'\n    tables:\n'
            for table in table_list:
                header += f'      - name: {table}\n'

    print(f'read csv_file {args.filename}:\n{header}')
    # print(f'read csv_file {args.filename}:\n{csv_data}')

    write_source_yml( header )

if __name__ == "__main__":
    main()

"""

python dbt_parse_csv.py -f dbt_dump_test.csv
python dbt_parse_csv.py -f dump.csv

"""