# Take an argument (database name) and generate the dbt sources.yml from that.
"""
version: 2

sources:
  - name: jaffle_shop
    database: raw  
    schema: jaffle_shop  
    tables:
      - name: orders
      - name: customers

  - name: stripe
    tables:
      - name: payments
"""

import snowflake.connector
import argparse, time, pandas as pd
import config
from platform import python_version


def process_args( ):
    parser = argparse.ArgumentParser( description="Convert csv to sources.yml")
    parser.add_argument( '-d','--database', help='Database Name', required= False)

    args = parser.parse_args()
    # Default file for testing
    if args.database:
        args.database = args.database.upper()
    else:
        args.database = config.database

    return args


def main():
    print(f"Using python: {python_version()}")    
    args = process_args( )

    
    cs = sf_connect()
    # sql = "select current_date()"
    # cs.execute(sql)
    # results = cs.fetchall()
    # print(f"it's currently {results}")
    get_tables( args.database )
    

def sf_connect():
    conn = snowflake.connector.connect (
    account = config.account,
    user = config.user,
    warehouse = config.warehouse,
    role = config.role,
    database = config.database,
    schemea = 'PUBLIC',
    authenticator = config.authenticator,
    CLIENT_SESSION_KEEP_ALIVE = config.CLIENT_SESSION_KEEP_ALIVE

    )

    cs = conn.cursor()
    return cs


def get_tables( db_name):
    # Establish a connection to SF.  Hardcoded for now
    conn = sf_connect()
    outputfile = f'{db_name}_dump.csv'

    sql = f"""
    select  
        table_catalog
        , table_schema
        , table_name
    from information_schema.tables
    where table_catalog = '{db_name}'
        and is_temporary = 'NO'
    order by table_catalog, table_schema, table_name
    """
    
    qry_results = conn.execute( sql )
    # qry_results = conn.execute( sql ).fetchall()
    # print(f"I get {len(qry_results)} rows")

    qry_results.fetch_pandas_all().to_csv( outputfile )
    print(f'=== Wrote to {outputfile} \n')

if __name__ == "__main__":
    main()

"""

python generate_dbt_sources.py -d EDP_BRONZE_DEV
python dbt_parse_csv.py -f dump.csv

"""