# DBconnect.py
import sqlalchemy as sa
import pyodbc
 

try:
    cnxn = pyodbc.connect('dsn=mant6sqlsrv3;UID=fivetran;PWD=Our8020Deal')
    print("Passed")
except Exception as e:
    print(f"!!! Database CONNECTION issue detected. Please check your database account details. \n{e}")
