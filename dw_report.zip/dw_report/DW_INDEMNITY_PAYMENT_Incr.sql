--\set ON_ERROR_STOP on
TRUNCATE TABLE DW_REPORT.DW_INDEMNITY_PAYMENT;
INSERT
    /*+DIRECT*/
    INTO
        DW_REPORT.DW_INDEMNITY_PAYMENT(
            INDM_PAY_SCHD_ID,
            INDM_PAY_ID,
            AGRE_ID,
            INDM_SCH_ID,
            BNFT_TYP_CD,
            BNFT_TYP_NM,
            BNFT_RPT_TYP_ID,
            INDM_PAY_EFF_DT,
            INDM_PAY_END_DT,
            INDM_PAY_DRV_WEK,
            INDM_PAY_DRV_DD,
            INDM_PAY_BNFT_RT_AMT,
            INDM_PAY_CALC_BNFT_RT_AMT,
            INDM_PAY_OVRD_BNFT_RT_AMT,
            INDM_PAY_OVRD_BNFT_RT_CMT,
            INDM_PAY_DRV_TOT_AMT,
            INDM_PAY_DRV_SCH_TOT_AMT,
            INDM_PAY_OVRD_POST_INJR_AMT,
            INDM_PAY_DD_NOT_PD,
            INDM_PAY_OVRD_POST_INJR_COMT,
            INDM_PAY_RECALC_IND,
            INDM_PAY_NOTE_IND,
            INDM_RSN_TYP_CD,
            CALC_RSLT_ID,
            CLM_AVG_WG_ID,
            CLM_EARN_CAP_ID,
            AUDIT_USER_CREA_DTM,
            AUDIT_USER_ID_CREA,
            AUDIT_USER_ID_UPDT,
            AUDIT_USER_UPDT_DTM,
            INDM_FREQ_TYP_CD,
            INDM_FREQ_TYP_NM,
            INDM_SCH_FST_PRCS_DT,
            INDM_SCH_AUTO_PAY_IND,
            INDM_SCH_OFST_CHG_IND,
            INDM_SCH_NO_OF_PAY,
            INDM_PAY_VOID_IND,
            INDM_SCH_VOID_IND,
            BNFT_RPT_TYP_CD,
            BNFT_RPT_TYP_NM,
            DW_CREATE_DTTM,
            DW_UPDATE_DTTM
        )(
            SELECT
                ROW_NUMBER() OVER( order by INDM_PAY_ID ) AS INDM_PAY_SCHD_ID,
                INDM_PAY_ID,
                AGRE_ID,
                INDM_SCH_ID,
                CASE
                    WHEN BNFT_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BNFT_TYP_CD
                END BNFT_TYP_CD,
                BNFT_TYP_NM,
                BNFT_RPT_TYP_ID,
                INDM_PAY_EFF_DT,
                INDM_PAY_END_DT,
                INDM_PAY_DRV_WEK,
                INDM_PAY_DRV_DD,
                INDM_PAY_BNFT_RT_AMT,
                INDM_PAY_CALC_BNFT_RT_AMT,
                INDM_PAY_OVRD_BNFT_RT_AMT,
                INDM_PAY_OVRD_BNFT_RT_CMT,
                INDM_PAY_DRV_TOT_AMT,
                INDM_PAY_DRV_SCH_TOT_AMT,
                INDM_PAY_OVRD_POST_INJR_AMT,
                INDM_PAY_DD_NOT_PD,
                INDM_PAY_OVRD_POST_INJR_COMT,
                INDM_PAY_RECALC_IND,
                INDM_PAY_NOTE_IND,
                CASE
                    WHEN INDM_RSN_TYP_CD IS NULL
                    THEN '-1'
                    ELSE INDM_RSN_TYP_CD
                END INDM_RSN_TYP_CD,
                CALC_RSLT_ID,
                CLM_AVG_WG_ID,
                CLM_EARN_CAP_ID,
                AUDIT_USER_CREA_DTM,
                AUDIT_USER_ID_CREA,
                AUDIT_USER_ID_UPDT,
                AUDIT_USER_UPDT_DTM,
                CASE
                    WHEN INDM_FREQ_TYP_CD IS NULL
                    THEN '-1'
                    ELSE INDM_FREQ_TYP_CD
                END INDM_FREQ_TYP_CD,
                INDM_FREQ_TYP_NM,
                INDM_SCH_FST_PRCS_DT,
                INDM_SCH_AUTO_PAY_IND,
                INDM_SCH_OFST_CHG_IND,
                INDM_SCH_NO_OF_PAY,
                INDM_PAY_VOID_IND,
                INDM_SCH_VOID_IND,
                CASE
                    WHEN BNFT_RPT_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BNFT_RPT_TYP_CD
                END BNFT_RPT_TYP_CD,
                BNFT_RPT_TYP_NM,
                CURRENT_DATE AS DW_CREATE_DTTM,
                CURRENT_DATE AS DW_UPDATE_DTTM
            FROM
                (
                    SELECT
                        DISTINCT IP.INDM_PAY_ID,
                        IP.AGRE_ID,
                        ISC.INDM_SCH_ID,
                        IP.BNFT_TYP_CD,
                        BT.BNFT_TYP_NM,
                        IP.BNFT_RPT_TYP_ID,
                        IP.INDM_PAY_EFF_DT,
                        IP.INDM_PAY_END_DT,
                        IP.INDM_PAY_DRV_WEK,
                        IP.INDM_PAY_DRV_DD,
                        IP.INDM_PAY_BNFT_RT_AMT,
                        IP.INDM_PAY_CALC_BNFT_RT_AMT,
                        IP.INDM_PAY_OVRD_BNFT_RT_AMT,
                        IP.INDM_PAY_OVRD_BNFT_RT_CMT,
                        IP.INDM_PAY_DRV_TOT_AMT,
                        IP.INDM_PAY_DRV_SCH_TOT_AMT,
                        IP.INDM_PAY_OVRD_POST_INJR_AMT,
                        IP.INDM_PAY_DD_NOT_PD,
                        IP.INDM_PAY_OVRD_POST_INJR_COMT,
                        IP.INDM_PAY_RECALC_IND,
                        IP.INDM_PAY_NOTE_IND,
                        IP.INDM_RSN_TYP_CD,
                        IP.CALC_RSLT_ID,
                        IP.CLM_AVG_WG_ID,
                        IP.CLM_EARN_CAP_ID,
                        IP.AUDIT_USER_CREA_DTM,
                        IP.AUDIT_USER_ID_CREA,
                        IP.AUDIT_USER_ID_UPDT,
                        IP.AUDIT_USER_UPDT_DTM,
                        ISC.INDM_FREQ_TYP_CD,
                        IFT.INDM_FREQ_TYP_NM,
                        ISC.INDM_SCH_FST_PRCS_DT,
                        ISC.INDM_SCH_AUTO_PAY_IND,
                        ISC.INDM_SCH_OFST_CHG_IND,
                        ISC.INDM_SCH_NO_OF_PAY,
                        IP.VOID_IND AS INDM_PAY_VOID_IND,
                        ISC.VOID_IND AS INDM_SCH_VOID_IND,
                        BRT.BNFT_RPT_TYP_CD,
                        BRT.BNFT_RPT_TYP_NM
                    FROM
                        PCMP.INDEMNITY_PAYMENT IP LEFT OUTER JOIN PCMP.INDEMNITY_SCHEDULE ISC
                            ON IP.INDM_PAY_ID = ISC.INDM_PAY_ID LEFT OUTER JOIN PCMP.BENEFIT_TYPE BT
                            ON BT.BNFT_TYP_CD = IP.BNFT_TYP_CD LEFT OUTER JOIN PCMP.BENEFIT_REPORTING_TYPE BRT
                            ON IP.BNFT_RPT_TYP_ID = BRT.BNFT_RPT_TYP_ID LEFT OUTER JOIN PCMP.INDEMNITY_FREQUENCY_TYPE IFT
                            ON IFT.INDM_FREQ_TYP_CD = ISC.INDM_FREQ_TYP_CD
                ) A
        );COMMIT;