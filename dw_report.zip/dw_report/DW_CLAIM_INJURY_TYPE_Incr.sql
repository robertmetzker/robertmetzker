--\set ON_ERROR_STOP on
-- TRUNCATE AND INSERT ROWS
TRUNCATE TABLE DW_REPORT.DW_CLAIM_INJURY_TYPE;
INSERT
    /*+DIRECT*/
    INTO
        DW_REPORT.DW_CLAIM_INJURY_TYPE(
            INJURY_TYPE_ID,
            AGRE_ID,
            CLM_TYP_CD,
            INJR_TYP_CD,
            INJR_TYP_NM,
            INJR_TYP_SEV,
            JUR_TYP_CD,
            NCCI_INJR_TYP_ID,
            WCSTAT_INJR_TYP_CD,
            DW_CREATE_DTTM,
            DW_UPDATE_DTTM
        )(
SELECT
                ROW_NUMBER() OVER( order by c.AGRE_ID ) AS INJURY_TYPE_ID,
                C.AGRE_ID,
                CASE
                    WHEN CT.CLM_TYP_CD IS NULL THEN '-1' ELSE CT.CLM_TYP_CD END CLM_TYP_CD,
                CASE WHEN WC.INJR_TYP_CD IS NULL THEN '-1' ELSE WC.INJR_TYP_CD END INJR_TYP_CD,
                I.INJR_TYP_NM,
                I.INJR_TYP_SEV,
                CASE WHEN I.JUR_TYP_CD IS NULL THEN '-1' ELSE I.JUR_TYP_CD END JUR_TYP_CD,
                I.NCCI_INJR_TYP_ID,
                CASE WHEN I.WCSTAT_INJR_TYP_CD IS NULL THEN '-1' ELSE I.WCSTAT_INJR_TYP_CD END WCSTAT_INJR_TYP_CD,
                CURRENT_DATE AS DW_CREATE_DTTM,
                CURRENT_DATE AS DW_UPDATE_DTTM
            FROM
                PCMP.CLAIM C 
                LEFT OUTER JOIN PCMP.CLAIM_CLAIM_TYPE CT ON C.AGRE_ID = CT.AGRE_ID 
                left JOIN PCMP.WC_CLAIM WC ON C.AGRE_ID = WC.AGRE_ID 
                LEFT OUTER JOIN PCMP.INJURY_TYPE I  ON WC.INJR_TYP_CD = I.INJR_TYP_CD AND I.VOID_IND = 'n'
				WHERE C.CLM_REL_SNPSHT_IND = 'n' 
        );COMMIT;