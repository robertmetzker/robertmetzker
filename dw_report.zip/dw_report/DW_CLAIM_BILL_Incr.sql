--\set ON_ERROR_STOP on
TRUNCATE TABLE DW_REPORT.DW_CLAIM_BILL;
INSERT /*+DIRECT*/ INTO DW_REPORT.DW_CLAIM_BILL
(BILL_ID, AGRE_ID, BILL_NO, BILL_EDI_REF_NO_PRI, BILL_EDI_REF_NO_SECD, BILL_CNV_NO, BILL_EDI_SRC_TYP_CD, BILL_EDI_SRC_TYP_NM, BILL_PTCP_PAY_IND, BILL_SECD_PAYE_IND, CUST_ID_BILL_PROV, CUST_ID_SERV_PROV, CUST_ID_FACIL_PROV, BILL_TRN_ID_FR, BILL_TRN_ID_TO, BILL_NOTE_IND, BILL_OPN_DT, BILL_COMP_DT, BILL_REOPN_DT, BILL_RECOMP_DT, BILL_LST_TRAN_DT, BILL_CYC_ID, BILL_CYC_NO, BILL_CYC_ICD_VER_CD, BILL_FRMT_TYP_CD, BILL_FRMT_TYP_NM, BILL_MEDA_TYP_CD, BILL_CYC_SERV_EFF_DT, BILL_CYC_SERV_END_DT, BILL_CYC_RECV_DT, BILL_CYC_NOTE_ATTCH_IND, BILL_CYC_FEE_SCH_OVRRD_IND, FEE_SCH_OVRRD_RSN_TYP_CD, BILL_SRC_TYP_CD, BILL_SRC_TYP_NM, BILL_FAST_TRK_ACTN_TYP_CD, BFTART_CD, BILL_CYC_CHR_TOT_AMT, BC_CST_CNTR_TYP_CD, BC_PAY_TYP_CD, BILL_CYC_SUM_SBM_AMT, BILL_CYC_SUM_APRV_AMT, BILL_CYC_SUM_PD_AMT, BILL_CYC_REF_NO, BILL_CYC_MED_REC_NO, BILL_CYC_ADMIT_DTM, BILL_CYC_DISC_DTM, BILL_CYC_LNGTH_OF_STAY_DD, BILL_CYC_DRG_CD, BILL_CYC_DRG_DESC, BILL_CYC_DRG_VRFD_IND, BILL_CYC_ADJ_DRG_CD, BILL_CYC_ADJ_DRG_DESC, BILL_CYC_ADJ_DRG_VRFD_IND, BILL_CYC_UB92_TYP_CD, BILL_CYC_UB92_TYP_DESC, BILL_CYC_UB92_TYP_VRFD_IND, BILL_CYC_ICD_SBM_ADMIT_CD, BILL_CYC_ICD_SBM_ADMIT_DESC, BILL_CYC_ICD_ADMIT_CD, BILL_CYC_ICD_ADMIT_DESC, BILL_CYC_ICD_ADMIT_VRFD_IND, PAY_REQS_ID, BILL_CYC_PPY_TYP_CD, BILL_CYC_PHY_LIC_NO, BILL_ADMIS_TYP_CD, BILL_SCH_TYP_CD, BILL_CYC_OP_PHYS_LIC_NO, BILL_SPL_PROC_TYP_CD, BILL_CYC_SPL_PROC_AMT, BILL_CYC_DO_NOT_RPT_IND, BILL_DO_NOT_RPT_RSN_TYP_CD, BILL_CYC_NET_WK_SERV_IND, AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA, AUDIT_USER_ID_UPDT, AUDIT_USER_UPDT_DTM, BILL_STS_TYP_CD, BILL_STS_TYP_NM, BILL_CYC_STS_EFF_DT, BILL_STT_TYP_CD, BILL_STT_TYP_NM, BILL_CYC_STS_STT_EFF_DT, BILL_TRANS_RSN_TYP_CD, BILL_CYC_STS_COMT, BILL_TRANS_RSN_TYP_NM, BILL_TRANS_RSN_TYP_SYS_IND, BILL_TRANS_RSN_TYP_EOB_CD, BILL_TRANS_RSN_TYP_CFM_IND, BILL_LN_ITEM_ID, BILL_LN_ITEM_NO, BILL_LN_ITEM_EDI_REF_NO, BILL_LN_ITEM_SERV_EFF_DT, BILL_LN_ITEM_SERV_END_DT, BILL_LN_ITEM_TYP_CD, BILL_LN_ITEM_CD_TYP_CD_PRI, BLI_CST_CNTR_TYP_CD, BC_CST_CNTR_TYP_NM, BC_CST_CNTR_CTG_TYP_CD, BC_PAY_TYP_CD_DFLT, BC_CST_CNTRTYP_PAYTYP_UPDT_IND, BLI_PAY_TYP_CD, BC_PAY_TYP_NM, BC_APP_CNTX_TYP_CD, BC_PAY_TYP_BILL_VSBL_IND, BILL_LN_ITEM_SBM_PRI_CD, BILL_LN_ITEM_SBM_PRI_DESC, BILL_LN_ITEM_PRI_CD, BILL_LN_ITEM_PRI_DESC, BILL_LN_ITEM_PRI_VRFD_IND, BILL_LN_ITEM_SUB_VRFD_IND, BILL_LN_ITEM_STR_TIME, BILL_LN_ITEM_END_TIME, BILL_LN_ITEM_UNT, BILL_LN_ITEM_MIN, BILL_LN_ITEM_CD_TYP_CD_SECD, BILL_LN_ITEM_SECD_CD, BILL_LN_ITEM_SECD_DESC, BILL_LN_ITEM_SECD_VRFD_IND, BILL_LN_ITEM_SERV_PLC_CD, BILL_LN_ITEM_SERV_PLC_DESC, BILL_LN_ITEM_SERV_PLC_VRFD_IND, BILL_LN_ITEM_SERV_TYP_CD, BILL_LN_ITEM_SERV_TYP_DESC, BILL_LN_ITEM_SERV_TYP_VRFD_IND, BILL_LN_ITEM_EMRG_TYP_CD, BILL_LN_ITEM_EMRG_TYP_DESC, BILL_LN_ITEM_EMRG_TYP_VRFD_IND, BILL_LN_ITEM_RX_NO, BILL_LN_ITEM_RX_SUPP_DD, BILL_LN_ITEM_RX_PROV_NM, BILL_LN_ITEM_RX_PROV_ID, PROV_ID_TYP_CD, BILL_LN_ITEM_RX_DT, BILL_LN_ITEM_TOOTH_CD, BILL_LN_ITEM_TOOTH_DESC, BILL_LN_ITEM_TOOTH_VRFD_IND, BILL_LN_ITEM_TOOTHSRF_CD, BILL_LN_ITEM_TOOTHSRF_DESC, BILL_LN_ITEM_TOOTHSRF_VRFD_IND, BILL_LN_ITEM_TRVL_FR, BILL_LN_ITEM_TRVL_TO, TRVL_TYP_CD, BILL_LN_ITEM_TRVL_DST, BILL_LN_ITEM_TRVL_NET, BILL_LN_ITEM_TRVL_EXCL, BILL_LN_ITEM_TRVL_RT, BILL_LN_ITEM_TRVL_REMB, BILL_LN_ITEM_COMT, BILL_LN_ITEM_SBM_AMT, BILL_LN_ITEM_PAY_SBM_IND, BILL_LN_ITEM_APRV_AMT, BILL_LN_ITEM_PD_AMT, BILL_LN_ITEM_TAX_AMT, BILL_LN_ITEM_PENL_AMT, BILL_LN_ITEM_PRVS_PD_AMT, BILL_LN_ITEM_ADJ_CYC_ID, BILL_DISD_AS_WRTN_TYP_CD, BILL_NEW_REFL_TYP_CD, BILL_DME_OWNSHP_TYP_CD, BILL_LN_ITEM_OVRRD_FLG_IND, DW_CREATE_DTTM, DW_UPDATE_DTTM)
(
       SELECT   B.BILL_ID,
                C.AGRE_ID,
                B.BILL_NO,
                B.BILL_EDI_REF_NO_PRI,
                B.BILL_EDI_REF_NO_SECD,
                B.BILL_CNV_NO,
                CASE
                    WHEN B.BILL_EDI_SRC_TYP_CD IS NULL
                    THEN '-1'
                    ELSE B.BILL_EDI_SRC_TYP_CD
                END BILL_EDI_SRC_TYP_CD,
                BEST.BILL_EDI_SRC_TYP_NM,
                B.BILL_PTCP_PAY_IND,
                B.BILL_SECD_PAYE_IND,
                B.CUST_ID_BILL_PROV,
                B.CUST_ID_SERV_PROV,
                B.CUST_ID_FACIL_PROV,
                B.BILL_TRN_ID_FR,
                B.BILL_TRN_ID_TO,
                B.BILL_NOTE_IND,
                B.BILL_OPN_DT,
                B.BILL_COMP_DT,
                B.BILL_REOPN_DT,
                B.BILL_RECOMP_DT,
                B.BILL_LST_TRAN_DT,
                BC.BILL_CYC_ID,
                BC.BILL_CYC_NO,
                CASE
                    WHEN BC.BILL_CYC_ICD_VER_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_ICD_VER_CD
                END BILL_CYC_ICD_VER_CD,
                CASE
                    WHEN BC.BILL_FRMT_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_FRMT_TYP_CD
                END BILL_FRMT_TYP_CD,
                BFT.BILL_FRMT_TYP_NM,
                CASE
                    WHEN BC.BILL_MEDA_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_MEDA_TYP_CD
                END BILL_MEDA_TYP_CD,
                BC.BILL_CYC_SERV_EFF_DT,
                BC.BILL_CYC_SERV_END_DT,
                BC.BILL_CYC_RECV_DT,
                BC.BILL_CYC_NOTE_ATTCH_IND,
                BC.BILL_CYC_FEE_SCH_OVRRD_IND,
                CASE
                    WHEN BC.FEE_SCH_OVRRD_RSN_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.FEE_SCH_OVRRD_RSN_TYP_CD
                END FEE_SCH_OVRRD_RSN_TYP_CD,
                CASE
                    WHEN BC.BILL_SRC_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_SRC_TYP_CD
                END BILL_SRC_TYP_CD,
                BST.BILL_SRC_TYP_NM,
                CASE
                    WHEN BC.BILL_FAST_TRK_ACTN_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_FAST_TRK_ACTN_TYP_CD
                END BILL_FAST_TRK_ACTN_TYP_CD,
                CASE
                    WHEN BC.BFTART_CD IS NULL
                    THEN '-1'
                    ELSE BC.BFTART_CD
                END BFTART_CD,
                BC.BILL_CYC_CHR_TOT_AMT,
                CASE
                    WHEN BC.CST_CNTR_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.CST_CNTR_TYP_CD
                END CST_CNTR_TYP_CD,
                CASE
                    WHEN BC.PAY_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.PAY_TYP_CD
                END PAY_TYP_CD,
                BC.BILL_CYC_SUM_SBM_AMT,
                BC.BILL_CYC_SUM_APRV_AMT,
                BC.BILL_CYC_SUM_PD_AMT,
                BC.BILL_CYC_REF_NO,
                BC.BILL_CYC_MED_REC_NO,
                BC.BILL_CYC_ADMIT_DTM,
                BC.BILL_CYC_DISC_DTM,
                BC.BILL_CYC_LNGTH_OF_STAY_DD,
                CASE
                    WHEN BC.BILL_CYC_DRG_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_DRG_CD
                END BILL_CYC_DRG_CD,
                BC.BILL_CYC_DRG_DESC,
                BC.BILL_CYC_DRG_VRFD_IND,
                CASE
                    WHEN BC.BILL_CYC_ADJ_DRG_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_ADJ_DRG_CD
                END BILL_CYC_ADJ_DRG_CD,
                BC.BILL_CYC_ADJ_DRG_DESC,
                BC.BILL_CYC_ADJ_DRG_VRFD_IND,
                CASE
                    WHEN BC.BILL_CYC_UB92_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_UB92_TYP_CD
                END BILL_CYC_UB92_TYP_CD,
                BC.BILL_CYC_UB92_TYP_DESC,
                BC.BILL_CYC_UB92_TYP_VRFD_IND,
                CASE
                    WHEN BC.BILL_CYC_ICD_SBM_ADMIT_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_ICD_SBM_ADMIT_CD
                END BILL_CYC_ICD_SBM_ADMIT_CD,
                BC.BILL_CYC_ICD_SBM_ADMIT_DESC,
                CASE
                    WHEN BC.BILL_CYC_ICD_ADMIT_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_ICD_ADMIT_CD
                END BILL_CYC_ICD_ADMIT_CD,
                BC.BILL_CYC_ICD_ADMIT_DESC,
                BC.BILL_CYC_ICD_ADMIT_VRFD_IND,
                BC.PAY_REQS_ID,
                CASE
                    WHEN BC.BILL_CYC_PPY_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_CYC_PPY_TYP_CD
                END BILL_CYC_PPY_TYP_CD,
                BC.BILL_CYC_PHY_LIC_NO,
                CASE
                    WHEN BC.BILL_ADMIS_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_ADMIS_TYP_CD
                END BILL_ADMIS_TYP_CD,
                CASE
                    WHEN BC.BILL_SCH_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_SCH_TYP_CD
                END BILL_SCH_TYP_CD,
                BC.BILL_CYC_OP_PHYS_LIC_NO,
                CASE
                    WHEN BC.BILL_SPL_PROC_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_SPL_PROC_TYP_CD
                END BILL_SPL_PROC_TYP_CD,
                BC.BILL_CYC_SPL_PROC_AMT,
                BC.BILL_CYC_DO_NOT_RPT_IND,
                CASE
                    WHEN BC.BILL_DO_NOT_RPT_RSN_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BC.BILL_DO_NOT_RPT_RSN_TYP_CD
                END BILL_DO_NOT_RPT_RSN_TYP_CD,
                BC.BILL_CYC_NET_WK_SERV_IND,
                BC.AUDIT_USER_CREA_DTM,
                BC.AUDIT_USER_ID_CREA,
                BC.AUDIT_USER_ID_UPDT,
                BC.AUDIT_USER_UPDT_DTM,
                CASE
                    WHEN BCS.BILL_STS_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BCS.BILL_STS_TYP_CD
                END BILL_STS_TYP_CD,
                BSST.BILL_STS_TYP_NM,
                BCS.BILL_CYC_STS_EFF_DT,
                CASE
                    WHEN BCS.BILL_STT_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BCS.BILL_STT_TYP_CD
                END BILL_STT_TYP_CD,
                BSTT.BILL_STT_TYP_NM,
                BCS.BILL_CYC_STS_STT_EFF_DT,
                CASE
                    WHEN BCS.BILL_TRANS_RSN_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BCS.BILL_TRANS_RSN_TYP_CD
                END BILL_TRANS_RSN_TYP_CD,
                BCS.BILL_CYC_STS_COMT,
                BTRT.BILL_TRANS_RSN_TYP_NM,
                BTRT.BILL_TRANS_RSN_TYP_SYS_IND,
                CASE
                    WHEN BTRT.BILL_TRANS_RSN_TYP_EOB_CD IS NULL
                    THEN '-1'
                    ELSE BTRT.BILL_TRANS_RSN_TYP_EOB_CD
                END BILL_TRANS_RSN_TYP_EOB_CD,
                BTRT.BILL_TRANS_RSN_TYP_CFM_IND,
                BLI.BILL_LN_ITEM_ID,
                BLI.BILL_LN_ITEM_NO,
                BLI.BILL_LN_ITEM_EDI_REF_NO,
                BLI.BILL_LN_ITEM_SERV_EFF_DT,
                BLI.BILL_LN_ITEM_SERV_END_DT,
                CASE
                    WHEN BLI.BILL_LN_ITEM_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_TYP_CD
                END BILL_LN_ITEM_TYP_CD,
                CASE
                    WHEN BLI.BILL_LN_ITEM_CD_TYP_CD_PRI IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_CD_TYP_CD_PRI
                END BILL_LN_ITEM_CD_TYP_CD_PRI,
                CASE
                    WHEN BLI.CST_CNTR_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.CST_CNTR_TYP_CD
                END CST_CNTR_TYP_CD,
                CCT.CST_CNTR_TYP_NM,
                CASE
                    WHEN CCT.CST_CNTR_CTG_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CCT.CST_CNTR_CTG_TYP_CD
                END CST_CNTR_CTG_TYP_CD,
                CCT.PAY_TYP_CD_DFLT,
                CCT.CST_CNTR_TYP_PAY_TYP_UPDT_IND,
                CASE
                    WHEN BLI.PAY_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.PAY_TYP_CD
                END PAY_TYP_CD,
                PT.PAY_TYP_NM,
                CASE
                    WHEN PT.APP_CNTX_TYP_CD IS NULL
                    THEN '-1'
                    ELSE PT.APP_CNTX_TYP_CD
                END APP_CNTX_TYP_CD,
                PT.PAY_TYP_BILL_VSBL_IND,
                CASE
                    WHEN BLI.BILL_LN_ITEM_SBM_PRI_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_SBM_PRI_CD
                END BILL_LN_ITEM_SBM_PRI_CD,
                BLI.BILL_LN_ITEM_SBM_PRI_DESC,
                CASE
                    WHEN BLI.BILL_LN_ITEM_PRI_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_PRI_CD
                END BILL_LN_ITEM_PRI_CD,
                BLI.BILL_LN_ITEM_PRI_DESC,
                BLI.BILL_LN_ITEM_PRI_VRFD_IND,
                BLI.BILL_LN_ITEM_SUB_VRFD_IND,
                BLI.BILL_LN_ITEM_STR_TIME,
                BLI.BILL_LN_ITEM_END_TIME,
                BLI.BILL_LN_ITEM_UNT,
                BLI.BILL_LN_ITEM_MIN,
                CASE
                    WHEN BLI.BILL_LN_ITEM_CD_TYP_CD_SECD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_CD_TYP_CD_SECD
                END BILL_LN_ITEM_CD_TYP_CD_SECD,
                CASE
                    WHEN BLI.BILL_LN_ITEM_SECD_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_SECD_CD
                END BILL_LN_ITEM_SECD_CD,
                BLI.BILL_LN_ITEM_SECD_DESC,
                BLI.BILL_LN_ITEM_SECD_VRFD_IND,
                CASE
                    WHEN BLI.BILL_LN_ITEM_SERV_PLC_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_SERV_PLC_CD
                END BILL_LN_ITEM_SERV_PLC_CD,
                BLI.BILL_LN_ITEM_SERV_PLC_DESC,
                BLI.BILL_LN_ITEM_SERV_PLC_VRFD_IND,
                CASE
                    WHEN BLI.BILL_LN_ITEM_SERV_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_SERV_TYP_CD
                END BILL_LN_ITEM_SERV_TYP_CD,
                BLI.BILL_LN_ITEM_SERV_TYP_DESC,
                BLI.BILL_LN_ITEM_SERV_TYP_VRFD_IND,
                CASE
                    WHEN BLI.BILL_LN_ITEM_EMRG_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_EMRG_TYP_CD
                END BILL_LN_ITEM_EMRG_TYP_CD,
                BLI.BILL_LN_ITEM_EMRG_TYP_DESC,
                BLI.BILL_LN_ITEM_EMRG_TYP_VRFD_IND,
                BLI.BILL_LN_ITEM_RX_NO,
                BLI.BILL_LN_ITEM_RX_SUPP_DD,
                BLI.BILL_LN_ITEM_RX_PROV_NM,
                BLI.BILL_LN_ITEM_RX_PROV_ID,
                CASE
                    WHEN BLI.PROV_ID_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.PROV_ID_TYP_CD
                END PROV_ID_TYP_CD,
                BLI.BILL_LN_ITEM_RX_DT,
                CASE
                    WHEN BLI.BILL_LN_ITEM_TOOTH_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_TOOTH_CD
                END BILL_LN_ITEM_TOOTH_CD,
                BLI.BILL_LN_ITEM_TOOTH_DESC,
                BLI.BILL_LN_ITEM_TOOTH_VRFD_IND,
                CASE
                    WHEN BLI.BILL_LN_ITEM_TOOTHSRF_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_LN_ITEM_TOOTHSRF_CD
                END BILL_LN_ITEM_TOOTHSRF_CD,
                BLI.BILL_LN_ITEM_TOOTHSRF_DESC,
                BLI.BILL_LN_ITEM_TOOTHSRF_VRFD_IND,
                BLI.BILL_LN_ITEM_TRVL_FR,
                BLI.BILL_LN_ITEM_TRVL_TO,
                CASE
                    WHEN BLI.TRVL_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.TRVL_TYP_CD
                END TRVL_TYP_CD,
                BLI.BILL_LN_ITEM_TRVL_DST,
                BLI.BILL_LN_ITEM_TRVL_NET,
                BLI.BILL_LN_ITEM_TRVL_EXCL,
                BLI.BILL_LN_ITEM_TRVL_RT,
                BLI.BILL_LN_ITEM_TRVL_REMB,
                BLI.BILL_LN_ITEM_COMT,
                BLI.BILL_LN_ITEM_SBM_AMT,
                BLI.BILL_LN_ITEM_PAY_SBM_IND,
                BLI.BILL_LN_ITEM_APRV_AMT,
                BLI.BILL_LN_ITEM_PD_AMT,
                BLI.BILL_LN_ITEM_TAX_AMT,
                BLI.BILL_LN_ITEM_PENL_AMT,
                BLI.BILL_LN_ITEM_PRVS_PD_AMT,
                BLI.BILL_LN_ITEM_ADJ_CYC_ID,
                CASE
                    WHEN BLI.BILL_DISD_AS_WRTN_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_DISD_AS_WRTN_TYP_CD
                END BILL_DISD_AS_WRTN_TYP_CD,
                CASE
                    WHEN BLI.BILL_NEW_REFL_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_NEW_REFL_TYP_CD
                END BILL_NEW_REFL_TYP_CD,
                CASE
                    WHEN BLI.BILL_DME_OWNSHP_TYP_CD IS NULL
                    THEN '-1'
                    ELSE BLI.BILL_DME_OWNSHP_TYP_CD
                END BILL_DME_OWNSHP_TYP_CD,
                BLI.BILL_LN_ITEM_OVRRD_FLG_IND,
                CURRENT_DATE,
                CURRENT_DATE
            FROM
                PCMP.BILL B JOIN PCMP.CLAIM C
                    ON B.AGRE_ID = C.AGRE_ID
                AND C.CLM_REL_SNPSHT_IND = 'n' LEFT JOIN PCMP.BILL_CYCLE BC
                    ON B.BILL_ID = BC.BILL_ID LEFT JOIN PCMP.BILL_CYCLE_STATUS BCS
                    ON BC.BILL_CYC_ID = BCS.BILL_CYC_ID
                AND BCS.VOID_IND = 'n' LEFT JOIN PCMP.BILL_LINE_ITEM BLI
                    ON BC.BILL_CYC_ID = BLI.BILL_CYC_ID
                AND BLI.VOID_IND = 'n' LEFT JOIN PCMP.BILL_EDI_SOURCE_TYPE BEST
                    ON B.BILL_EDI_SRC_TYP_CD = BEST.BILL_EDI_SRC_TYP_CD LEFT JOIN PCMP.BILL_FORMAT_TYPE BFT
                    ON BC.BILL_FRMT_TYP_CD = BFT.BILL_FRMT_TYP_CD LEFT JOIN PCMP.BILL_TRANSITION_REASON_TYPE BTRT
                    ON BCS.BILL_TRANS_RSN_TYP_CD = BTRT.BILL_TRANS_RSN_TYP_CD LEFT JOIN PCMP.BILL_SOURCE_TYPE BST
                    ON BC.BILL_SRC_TYP_CD = BST.BILL_SRC_TYP_CD LEFT JOIN PCMP.COST_CENTER_TYPE CCT
                    ON BC.CST_CNTR_TYP_CD = CCT.CST_CNTR_TYP_CD LEFT JOIN PCMP.PAYMENT_TYPE PT
                    ON BC.PAY_TYP_CD = PT.PAY_TYP_CD LEFT JOIN PCMP.BILL_STATUS_TYPE BSST
                    ON BCS.BILL_STS_TYP_CD = BSST.BILL_STS_TYP_CD LEFT JOIN PCMP.BILL_STATE_TYPE BSTT
                    ON BCS.BILL_STT_TYP_CD = BSTT.BILL_STT_TYP_CD
);

COMMIT;