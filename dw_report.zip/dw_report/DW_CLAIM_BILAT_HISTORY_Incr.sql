/* Version # 2 		 	:(Prod Release date 03/21/2017 ) */

/* Table Description 	: 	This creates two tables which will be used by the python program in the automic flow*/
                                
							

/* Source Tables 		:       DW_REPORT.DW_CLAIM_INJURY_HISTORY
					DW_REPORT.CLAIM
							*/
						
/* L1 Dependency 		: 	DW_REPORT.DW_CLAIM_INJURY_HISTORY 
			                DW_REPORT.CLAIM */
						
						
/* High level ETL logic : 	Build row for the clm_no,icdc_mpd_code,agre_id for status listed below with all possible change dates */



--\set ON_ERROR_STOP on
-------------------------------CLAIM BILATERAL HISTORY
/*
This is a bulk process because the source L1 is bulk loaded everyday . Vertica is sensitive to alias naming with complex queries. The result of this script is
two tables and few temp tables in between. The intention is for the python code to do a merge between the two tables, the logic is too hard to implement in SQL

*/


--STEP 1: select disitnct records from DW_CLAIM_INJURY_HISTORY after truncating timestamps

-- DROP THE TABLE BEFORE INSERTING
Drop table if exists bwc_etl.temp_dw_bilat1 cascade;



-- create table with unique values from claim_injury_history table for only the status in the sql below as defined in the requirements.

CREATE or replace TABLE BWC_ETL.TEMP_DW_BILAT1 as
(SELECT distinct CLM_NO ,AGRE_ID ,ICDC_MPD_CODE FROM DW_REPORT.DW_CLAIM_INJURY_HISTORY 
WHERE TRIM(ICD_STS_TYP_NM) IN ( 'Accept / Appeal','Accepted','Pending', 'Hearing','SubAgg - Accept/Appeal','SubAgg - Payable', 'SubAgg - Not Payable', 'SubAgg - Pending Abatement') 
AND DATE_TRUNC('DAY', HIST_EFF_DTM) <= DATE_TRUNC('DAY', coalesce(HIST_END_DTM, '9999-12-31'))
and void_ind = 'n' 
ORDER BY CLM_NO,ICDC_MPD_CODE,AGRE_ID);


-- create temp table to get min hist eff dtm, this had to be separated out because of vertica subquery restrictions

CREATE or replace TEMPORARY TABLE TEMP_DW_BILAT_MIN_EFF  AS
SELECT MIN(ALZ.HIST_EFF_DTM) OVER(PARTITION BY CLM_NO,AGRE_ID,ICDC_MPD_CODE) AS MINI ,CLM_NO,AGRE_ID,ICDC_MPD_CODE FROM DW_REPORT.DW_CLAIM_INJURY_HISTORY ALZ
where ALZ.void_ind = 'n' ;


-- create temp table to get all the date values from the claim injury history
-- this also creates new dates

CREATE or replace  TEMPORARY TABLE temp_dw_bilat2  as (   
 WITH TEMP_TABLE_SELECT AS(
    (
        SELECT
            AL2.CLM_NO AS CLM_NO,
            AL2.AGRE_ID,
            AL2.ICDC_MPD_CODE AS ICD,
            DATE_TRUNC('DAY', AL2.HIST_EFF_DTM) AS CHG_DATE
        FROM
            DW_REPORT.DW_CLAIM AL1 INNER JOIN DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2
                ON AL2.CLM_NO = AL1.CLM_NO
            AND AL1.CLM_AGRE_ID = AL2.AGRE_ID
        WHERE AL1.CLM_REL_SNPSHT_IND = 'n'
        AND AL2.void_ind = 'n' 
        AND TRIM(AL2.ICD_STS_TYP_NM) IN( 'Accept / Appeal', 'Accepted', 'Pending', 'Hearing',
                    'SubAgg - Accept/Appeal', 'SubAgg - Payable', 'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement')

                 
    )
-- make nulls with end date: coalesce  AL2.HIST_END_DTM, '9999-12-31'
UNION(
    SELECT
        AL2.CLM_NO AS CLM_NO,
        AL2.AGRE_ID,
        AL2.ICDC_MPD_CODE AS ICD,
        DATE_TRUNC('DAY', 
            COALESCE(
                AL2.HIST_END_DTM,
                '9999-12-31'
            )
        ) AS CHG_DATE
    FROM
        DW_REPORT.DW_CLAIM AL1 INNER JOIN DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2
            ON AL2.CLM_NO = AL1.CLM_NO
        AND AL1.CLM_AGRE_ID = AL2.AGRE_ID
    WHERE AL1.CLM_REL_SNPSHT_IND = 'n'
    AND AL2.void_ind = 'n' 
    AND TRIM(AL2.ICD_STS_TYP_NM) IN( 'Accept / Appeal', 'Accepted', 'Pending', 'Hearing',
                    'SubAgg - Accept/Appeal', 'SubAgg - Payable', 'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement')
)
-- select rows where TE.MINI <> AL2.HIST_EFF_DTM, effective date is not the minimum date
UNION(
SELECT
    AL2.CLM_NO AS CLM_NO,
    AL2.AGRE_ID,
    AL2.ICDC_MPD_CODE AS ICD,
    DATE_TRUNC('DAY', AL2.HIST_EFF_DTM) - INTERVAL '1 DAY' AS CHG_DATE
FROM
    DW_REPORT.DW_CLAIM AL1 INNER JOIN DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2
        ON AL2.CLM_NO = AL1.CLM_NO
    AND AL1.CLM_AGRE_ID = AL2.AGRE_ID INNER JOIN temp_dw_bilat_min_eff TE
        ON AL2.CLM_NO = TE.CLM_NO
    AND AL2.AGRE_ID = TE.AGRE_ID
    AND AL2.ICDC_MPD_CODE = TE.ICDC_MPD_CODE
    WHERE
     AL1.CLM_REL_SNPSHT_IND = 'n'
    AND AL2.void_ind = 'n' 
    AND DATE_TRUNC('DAY', AL2.HIST_EFF_DTM) <> TE.MINI
    AND TRIM(AL2.ICD_STS_TYP_NM) IN( 'Accept / Appeal', 'Accepted', 'Pending', 'Hearing',
                    'SubAgg - Accept/Appeal', 'SubAgg - Payable', 'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement')
       
    
)
-- select rows where AL2.HIST_END_DTM is not '9999-12-31'
UNION(
SELECT
AL2.CLM_NO,
AL2.AGRE_ID,
AL2.ICDC_MPD_CODE AS ICD,
(
    DATE_TRUNC('DAY', AL2.HIST_END_DTM) + INTERVAL '1 DAY'
) AS CHG_DATE
FROM
DW_REPORT.DW_CLAIM AL1 INNER JOIN DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2
    ON AL2.CLM_NO = AL1.CLM_NO
AND AL2.AGRE_ID = AL1.CLM_AGRE_ID
where AL1.CLM_REL_SNPSHT_IND = 'n'
AND AL2.void_ind = 'n' 
AND TRIM(AL2.ICD_STS_TYP_NM) IN( 'Accept / Appeal', 'Accepted', 'Pending', 'Hearing',
                    'SubAgg - Accept/Appeal', 'SubAgg - Payable', 'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement')
AND DATE_TRUNC('DAY', 
    COALESCE(
        AL2.HIST_END_DTM,
        '9999-12-31'
    )
) <> DATE('9999-12-31')
)
) 
SELECT
    AL0.*
FROM
    TEMP_TABLE_SELECT AL0 INNER JOIN DW_REPORT.DW_CLAIM AL1
        ON AL1.CLM_NO = AL0.CLM_NO
    AND AL0.AGRE_ID = AL1.CLM_AGRE_ID
    AND AL1.CLM_REL_SNPSHT_IND = 'n')
  
; 

-- create temp table to get all body location code being 'B'

CREATE or replace  TEMPORARY TABLE  temp_dw_bilat4_y_b    as (
SELECT 
            DISTINCT AL0.CLM_NO,
    AL0.AGRE_ID,
    TRIM(AL0.ICD) as btrim, 
    AL0.CLM_NO || AL0.AGRE_ID || AL0.ICD AS COMBO,                         
    AL0.CHG_DATE,
    'y' as bilat_flag
                
            FROM
                DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2 ,temp_dw_bilat2 AL0
            WHERE
                 AL2.AGRE_ID = AL0.AGRE_ID
                AND AL2.CLM_NO = AL0.CLM_NO
                AND AL2.ICDC_MPD_CODE = AL0.ICD
                AND TRIM(AL2.ICD_STS_TYP_NM) IN(
                    'Accept / Appeal',
                    'Accepted',
                    'Pending',
                    'Hearing',
                    'SubAgg - Accept/Appeal',
                    'SubAgg - Payable',
                    'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement'
                )
                AND DATE_TRUNC('DAY', AL2.HIST_EFF_DTM) <= AL0.CHG_DATE
                AND DATE_TRUNC('DAY', 
                    COALESCE(
                        AL2.HIST_END_DTM,
                        '9999-12-31'
                    )
                ) >= AL0.CHG_DATE
	        AND AL2.void_ind = 'n' 
                AND AL2.OBLC_BDY_LCTN_CODE = 'B');
  

-- create temp table to get all body location code being 'L'              

CREATE or replace  TEMPORARY TABLE  temp_dw_bilat4_y_l   as (
SELECT 
            DISTINCT AL0.CLM_NO,
    AL0.AGRE_ID,
     TRIM(AL0.ICD) as btrim, 
    AL0.CLM_NO || AL0.AGRE_ID || AL0.ICD AS COMBO,                         
    AL0.CHG_DATE,
    'y' as bilat_flag
                
            FROM
                DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2 ,temp_dw_bilat2 Al0
            WHERE
             
                 AL2.AGRE_ID = AL0.AGRE_ID
                AND AL2.CLM_NO = AL0.CLM_NO
                AND AL2.ICDC_MPD_CODE = AL0.ICD
                AND TRIM(AL2.ICD_STS_TYP_NM) IN(
                    'Accept / Appeal',
                    'Accepted',
                    'Pending',
                    'Hearing',
                    'SubAgg - Accept/Appeal',
                    'SubAgg - Payable',
                    'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement'
                )
                AND DATE_TRUNC('DAY', AL2.HIST_EFF_DTM) <= AL0.CHG_DATE
                AND DATE_TRUNC('DAY', 
                    COALESCE(
                        AL2.HIST_END_DTM,
                        '9999-12-31'
                    )
                ) >= AL0.CHG_DATE
	        AND AL2.void_ind = 'n' 
                AND AL2.OBLC_BDY_LCTN_CODE = 'L');


-- create temp table to get all body location code being 'R' and make the bilat flag as 'y' 
--(if location code not being 'B' but falls on the same date range as 'L')  
                
CREATE or replace  TEMPORARY TABLE  temp_dw_bilat4_y_r_l  as (              
SELECT
    DISTINCT AL0.CLM_NO,
    AL0.AGRE_ID,
    btrim, 
    COMBO,                         
    AL0.CHG_DATE,
    'y' as bilat_flag
             
            FROM
                DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2,temp_dw_bilat4_y_l Al0
            WHERE
          
                 AL2.AGRE_ID = AL0.AGRE_ID
                AND AL2.CLM_NO = AL0.CLM_NO
                AND AL2.ICDC_MPD_CODE = trim(btrim)
                AND TRIM(AL2.ICD_STS_TYP_NM) IN(
                    'Accept / Appeal',
                    'Accepted',
                    'Pending',
                    'Hearing',
                    'SubAgg - Accept/Appeal',
                    'SubAgg - Payable',
                    'SubAgg - Not Payable',
                    'SubAgg - Pending Abatement'
                )
                AND DATE_TRUNC('DAY', AL2.HIST_EFF_DTM) <= AL0.CHG_DATE
                AND DATE_TRUNC('DAY', 
                    COALESCE(
                        AL2.HIST_END_DTM,
                        '9999-12-31'
                    )
                ) >= AL0.CHG_DATE
		AND AL2.void_ind = 'n' 
                AND AL2.OBLC_BDY_LCTN_CODE = 'R'
                and (AL0.CLM_NO,AL0.AGRE_ID,TRIM(AL0.btrim),AL0.CHG_DATE) NOT IN
                (SELECT CLM_NO,AGRE_ID,btrim,CHG_DATE FROM temp_dw_bilat4_y_b));


-- create temp table to get all bilat flag code being 'D' and 'N' and not in above any temp tables.

CREATE or replace  TEMPORARY TABLE  temp_dw_bilat4_d_n_nonunique   AS (            
SELECT
    AL0.CLM_NO,
    AL0.AGRE_ID,
     TRIM(AL0.ICD) as btrim, 
    AL0.CLM_NO || AL0.AGRE_ID || AL0.ICD AS COMBO,
    AL0.CHG_DATE,
    case when al0.chg_date BETWEEN date(al2.hist_eff_dtm) and coalesce(DATE(al2.hist_end_dtm), '9999-12-31') then 'n'
         else 'D' end as BILAT_FLAG
FROM temp_dw_bilat2 AL0
left outer join DW_REPORT.DW_CLAIM_INJURY_HISTORY AL2 on al2.agre_id = al0.agre_id
and al2.clm_no = al0.clm_no and al2.icdc_mpd_code = al0.icd
AND AL2.void_ind = 'n' 
and TRIM(AL2.ICD_STS_TYP_NM) IN( 'Accept / Appeal', 'Accepted', 'Pending', 'Hearing',
'SubAgg - Accept/Appeal', 'SubAgg - Payable', 'SubAgg - Not Payable',
'SubAgg - Pending Abatement') where (AL0.CLM_NO,AL0.AGRE_ID,TRIM(AL0.ICD),AL0.CHG_DATE) NOT IN (SELECT CLM_NO,AGRE_ID,btrim,CHG_DATE FROM temp_dw_bilat4_y_r_l)
and (AL0.CLM_NO,AL0.AGRE_ID,TRIM(AL0.ICD),AL0.CHG_DATE) NOT IN (SELECT CLM_NO,AGRE_ID,btrim,CHG_DATE FROM temp_dw_bilat4_y_b));


-- create temp table to get all bilat flag code being 'N' from above temp table.

CREATE or replace  TEMPORARY TABLE temp_dw_bilat4_n   as (
  select * from temp_dw_bilat4_d_n_nonunique
where bilat_flag = 'n');

-- create temp table to get all bilat flag code being 'D' from above temp table.

CREATE or replace  TEMPORARY TABLE temp_dw_bilat4_d   as (
select * from temp_dw_bilat4_d_n_nonunique Al0
where bilat_flag = 'D' 
  and (AL0.CLM_NO,AL0.AGRE_ID,btrim,AL0.CHG_DATE) NOT IN
                (SELECT CLM_NO,AGRE_ID,btrim,CHG_DATE FROM temp_dw_bilat4_n));

-- create temp table to get all bilat flag code being 'Y','N','D' from above temp table.

CREATE or replace  TEMPORARY TABLE temp_dw_bilat4_n_y_d  as (
                (select * from temp_dw_bilat4_d
                union all
                select * from temp_dw_bilat4_n
                union all 
                select * from temp_dw_bilat4_y_r_l
                union all
                select * from temp_dw_bilat4_y_b)
                order by 1,2,3,5); 

-- DROP table if exists 

Drop table if exists BWC_ETL.TEMP_DW_BILAT4_N_Y_D_MATCH cascade;


-- create table to get all valid values from the unique table temp_dw_bilat1


CREATE or replace    table  BWC_ETL.TEMP_DW_BILAT4_N_Y_D_MATCH as (
select * from temp_dw_bilat4_n_y_d Al0 
where (AL0.CLM_NO,AL0.AGRE_ID,Al0.btrim) in 
(select clm_no,agre_id,icdc_mpd_code from bwc_etl.temp_dw_bilat1 ));

 commit;


