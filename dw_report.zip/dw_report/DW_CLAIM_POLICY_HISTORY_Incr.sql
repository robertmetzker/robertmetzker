--\set ON_ERROR_STOP on
--This step truncates the table. 
--Truncate is a SQL (Structured Query Language) Command used to delete the contents of a table
truncate table DW_REPORT.DW_CLAIM_POLICY_HISTORY;

--First SQL is used to gather the details of all Claims with just one Policy Record
insert into DW_REPORT.DW_CLAIM_POLICY_HISTORY
(CLM_AGRE_ID, CLM_NO, INS_PARTICIPANT, CLM_OCCR_DATE, CLM_OCCR_DTM, CLM_PTCP_EFF_DATE, CLM_PTCP_EFF_DT, CLM_PLCY_RLTNS_EFF_DATE, CLM_PLCY_RLTNS_EFF_DT, CLM_PLCY_RLTNS_END_DATE, CLM_PLCY_RLTNS_END_DT, PLCY_NO, PLCY_AGRE_ID, BUSN_SEQ_NO, CTL_ELEM_SUB_TYP_CD, CTL_ELEM_SUB_TYP_NM, CRNT_PLCY_IND, CTL_ELEM_TYP_CD, DW_CREATE_DTTM, DW_UPDATE_DTTM)
SELECT distinct  
c.AGRE_ID CLM_AGRE_ID,
c.CLM_NO CLM_NO,
pc.CUST_ID INS_PARTICIPANT,
date(c.clm_occr_dtm) CLM_OCCR_DATE,
(c.clm_occr_dtm) CLM_OCCR_DTM,
date(cp.clm_ptcp_eff_dt) CLM_PTCP_EFF_DATE,
(cp.clm_ptcp_eff_dt) CLM_PTCP_EFF_DT,
date(cp.clm_ptcp_eff_dt) CLM_PLCY_RLTNS_EFF_DATE,
(cp.clm_ptcp_eff_dt) CLM_PLCY_RLTNS_EFF_DT,
NULL ::DATE CLM_PLCY_RLTNS_END_DATE,
NULL ::DATE CLM_PLCY_RLTNS_END_DT,
pd.PLCY_NO PLCY_NO, 
pp.AGRE_ID PLCY_AGRE_ID, 
ppi.PLCY_PRD_PTCP_INS_BUSN_SEQ_NO BUSN_SEQ_NO, 
cest.CTL_ELEM_SUB_TYP_CD CTL_ELEM_SUB_TYP_CD,
cest.CTL_ELEM_SUB_TYP_NM CTL_ELEM_SUB_TYP_NM, 
'y' CRNT_PLCY_IND,
'plcy_typ' CTL_ELEM_TYP_CD, 
CURRENT_DATE DW_CREATE_DTTM,
CURRENT_DATE DW_UPDATE_DTTM
from pcmp.claim c, pcmp.agreement agc, pcmp.participation pc, pcmp.participation pp , pcmp.claim_participation cp,
pcmp.agreement agp, pcmp.policy_period_participation ppp, pcmp.policy_period pd, pcmp.policy_period_ptcp_ins ppi,
PCMP.POLICY_CONTROL_ELEMENT pce, PCMP.CONTROL_ELEMENT_SUB_TYPE cest  
where c.agre_id = agc.agre_id 
and c.clm_rel_snpsht_ind='n' 
and   agc.agre_id = pc.agre_id and pc.ptcp_typ_cd = 'insrd'
and   pc.cust_id = pp.cust_id and pp.ptcp_typ_cd = 'insrd'
and   pd.agre_id = agp.agre_id and agp.agre_typ_cd = 'plcy'
and   pp.ptcp_id = ppp.ptcp_id and ppp.void_ind = 'n'
and   ppp.plcy_prd_id = pd.plcy_prd_id and pd.void_ind = 'n'
and   ppp.ptcp_id = ppi.ptcp_id
and pc.ptcp_id=cp.ptcp_id
and pce.PLCY_PRD_ID=pd.PLCY_PRD_ID 
and pce.CTL_ELEM_TYP_CD='plcy_typ' 
and pce.VOID_IND='n'
and cest.CTL_ELEM_SUB_TYP_ID=pce.CTL_ELEM_SUB_TYP_ID
and c.CLM_NO in 
(
select  c.clm_no
    from PCMP.CLAIM c, PCMP.PARTICIPATION p, PCMP.CLAIM_PARTICIPATION cp
     where  c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'insrd' and c.CLM_REL_SNPSHT_IND = 'n' 
     and cp.ptcp_id=p.ptcp_id 
     group by c.CLM_NO
     having count(cp.clm_ptcp_id)=1
        )
--Union is a SQL Command to join two different SQLs with exact Selection of Columns		
UNION
--Second SQL is used to gather the details of all Claims with multiple Policy Records
SELECT distinct  
c.AGRE_ID, 
c.CLM_NO,  
pc.CUST_ID, 
date(c.clm_occr_dtm), 
(c.clm_occr_dtm), 
date(cp.clm_ptcp_eff_dt),
(cp.clm_ptcp_eff_dt),
(case
when (cp.AUDIT_USER_CREA_DTM) = (select min(cpx.AUDIT_USER_CREA_DTM) from pcmp.claim_participation cpx, pcmp.participation px where cpx.PTCP_ID=px.PTCP_ID and px.agre_id=pc.agre_id and px.ptcp_typ_cd='insrd' )
then date(cp.CLM_PTCP_EFF_DT)
else date(cp.AUDIT_USER_CREA_DTM)
end), 
(case
when (cp.AUDIT_USER_CREA_DTM) = (select min(cpx.AUDIT_USER_CREA_DTM) from pcmp.claim_participation cpx, pcmp.participation px where cpx.PTCP_ID=px.PTCP_ID and px.agre_id=pc.agre_id and px.ptcp_typ_cd='insrd' )
then (cp.CLM_PTCP_EFF_DT)
else (cp.AUDIT_USER_CREA_DTM)
end), 
(case
when cp.clm_ptcp_pri_ind ='y' 
then null
else date(cp.AUDIT_USER_UPDT_DTM)
end 
), 
(case
when cp.clm_ptcp_pri_ind ='y'
then null
else cp.AUDIT_USER_UPDT_DTM
end 
), 
pd.PLCY_NO, 
pp.AGRE_ID, 
ppi.PLCY_PRD_PTCP_INS_BUSN_SEQ_NO, 
cest.CTL_ELEM_SUB_TYP_CD,
cest.CTL_ELEM_SUB_TYP_NM, 
cp.clm_ptcp_pri_ind, 
'plcy_typ', 
CURRENT_DATE,
CURRENT_DATE
from pcmp.claim c, pcmp.agreement agc, pcmp.participation pc, pcmp.participation pp,  pcmp.claim_participation cp,
pcmp.agreement agp, pcmp.policy_period_participation ppp, pcmp.policy_period pd, pcmp.policy_period_ptcp_ins ppi,
PCMP.POLICY_CONTROL_ELEMENT pce, PCMP.CONTROL_ELEMENT_SUB_TYPE cest  
where c.agre_id = agc.agre_id 
and c.clm_rel_snpsht_ind='n' 
and   agc.agre_id = pc.agre_id and pc.ptcp_typ_cd = 'insrd'
and   pc.cust_id = pp.cust_id and pp.ptcp_typ_cd = 'insrd'
and   pd.agre_id = agp.agre_id and agp.agre_typ_cd = 'plcy'
and   pp.ptcp_id = ppp.ptcp_id and ppp.void_ind = 'n'
and   ppp.plcy_prd_id = pd.plcy_prd_id and pd.void_ind = 'n'
and   ppp.ptcp_id = ppi.ptcp_id
and pc.ptcp_id=cp.ptcp_id
and pce.PLCY_PRD_ID=pd.PLCY_PRD_ID 
and pce.CTL_ELEM_TYP_CD='plcy_typ' 
and pce.VOID_IND='n'
and cest.CTL_ELEM_SUB_TYP_ID=pce.CTL_ELEM_SUB_TYP_ID
and c.CLM_NO in 
(
select  c.clm_no
    from PCMP.CLAIM c, PCMP.PARTICIPATION p, PCMP.CLAIM_PARTICIPATION cp
     where  c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'insrd' and c.CLM_REL_SNPSHT_IND = 'n' 
     and cp.ptcp_id=p.ptcp_id 
     group by c.CLM_NO
     having count(cp.clm_ptcp_id)>1
        );                


--This step is to gather the Claims with duplicate values of current policy indicator into a temp table for cleanup        
CREATE TEMPORARY TABLE DW_CLAIM_POLICY_HISTORY_DUP  as 
SELECT *
    from DW_REPORT.DW_CLAIM_POLICY_HISTORY c
    where  CLM_NO in 
    (	select CLM_NO from DW_REPORT.DW_CLAIM_POLICY_HISTORY  t
   where CRNT_PLCY_IND = 'y'  
   group by CLM_NO
   having count(1)>1);

--This step is to gather the Claims with duplicate values of Policy Relationship eff date into a temp table for cleanup        
insert into  DW_CLAIM_POLICY_HISTORY_DUP 
SELECT *
    from DW_REPORT.DW_CLAIM_POLICY_HISTORY c
    where  CLM_NO in 
        (	select CLM_NO from DW_REPORT.DW_CLAIM_POLICY_HISTORY
   group by CLM_NO, CLM_AGRE_ID, CLM_PLCY_RLTNS_EFF_DT having count(*)>1); 

--This step is to delete the duplicate records   
delete from DW_REPORT.DW_CLAIM_POLICY_HISTORY  
where CLM_NO in 
(select clm_no from DW_CLAIM_POLICY_HISTORY_DUP);

--This step is re-insert rows into main table by eliminating duplicate records
insert into DW_REPORT.DW_CLAIM_POLICY_HISTORY
(CLM_AGRE_ID, CLM_NO, INS_PARTICIPANT, CLM_OCCR_DATE, CLM_OCCR_DTM, CLM_PTCP_EFF_DATE, CLM_PTCP_EFF_DT, CLM_PLCY_RLTNS_EFF_DATE, CLM_PLCY_RLTNS_EFF_DT, CLM_PLCY_RLTNS_END_DATE, CLM_PLCY_RLTNS_END_DT, PLCY_NO, PLCY_AGRE_ID, BUSN_SEQ_NO, CTL_ELEM_SUB_TYP_CD, CTL_ELEM_SUB_TYP_NM, CRNT_PLCY_IND, CTL_ELEM_TYP_CD, DW_CREATE_DTTM, DW_UPDATE_DTTM)
SELECT distinct  
c.AGRE_ID,
c.CLM_NO,
pc.CUST_ID,
date(c.clm_occr_dtm),
(c.clm_occr_dtm),
date(c.clm_occr_dtm),
(c.clm_occr_dtm),
date(c.clm_occr_dtm),
(c.clm_occr_dtm),
null,
null,
pd.PLCY_NO, 
pp.AGRE_ID, 
ppi.PLCY_PRD_PTCP_INS_BUSN_SEQ_NO, 
cest.CTL_ELEM_SUB_TYP_CD,
cest.CTL_ELEM_SUB_TYP_NM, 
'y',
'plcy_typ', 
CURRENT_DATE,
CURRENT_DATE
from pcmp.claim c, pcmp.agreement agc, pcmp.participation pc, pcmp.participation pp,  pcmp.claim_participation cp,
pcmp.agreement agp, pcmp.policy_period_participation ppp, pcmp.policy_period pd, pcmp.policy_period_ptcp_ins ppi,
PCMP.POLICY_CONTROL_ELEMENT pce, PCMP.CONTROL_ELEMENT_SUB_TYPE cest, DW_CLAIM_POLICY_HISTORY_DUP  x, pcmp.claim_summary cs  
where c.agre_id = agc.agre_id 
and c.clm_rel_snpsht_ind='n' 
and   agc.agre_id = pc.agre_id and pc.ptcp_typ_cd = 'insrd'
and   pc.cust_id = pp.cust_id and pp.ptcp_typ_cd = 'insrd'
and   pd.agre_id = agp.agre_id and agp.agre_typ_cd = 'plcy'
and   pp.ptcp_id = ppp.ptcp_id and ppp.void_ind = 'n'
and   ppp.plcy_prd_id = pd.plcy_prd_id and pd.void_ind = 'n'
and   ppp.ptcp_id = ppi.ptcp_id
and pc.ptcp_id=cp.ptcp_id
and pce.PLCY_PRD_ID=pd.PLCY_PRD_ID 
and pce.CTL_ELEM_TYP_CD='plcy_typ' 
and pce.VOID_IND='n'
and cest.CTL_ELEM_SUB_TYP_ID=pce.CTL_ELEM_SUB_TYP_ID 
and cp.VOID_IND='n'
and c.CLM_NO =x.clm_no
and c.CLM_NO=cs.CS_CLM_NO
and cs.CS_PLCY_NO=x.PLCY_NO
and cs.CS_END_DT is null
and x.plcy_no=pd.PLCY_NO;

--This step is to delete the records with relationship effective date greater than relationship end date
delete from  DW_REPORT.DW_CLAIM_POLICY_HISTORY  where  CLM_PLCY_RLTNS_EFF_DT > CLM_PLCY_RLTNS_END_DT;

--This step is to re-insert the deleted records by using Claim Participation tables  
insert into DW_REPORT.DW_CLAIM_POLICY_HISTORY
(
 CLM_AGRE_ID,
 CLM_NO,
 INS_PARTICIPANT,
 CLM_OCCR_DATE,
 CLM_OCCR_DTM,
 CLM_PTCP_EFF_DATE,
 CLM_PTCP_EFF_DT,
 CLM_PLCY_RLTNS_EFF_DATE,
 CLM_PLCY_RLTNS_EFF_DT,
 CRNT_PLCY_IND,
 DW_CREATE_DTTM,
 DW_UPDATE_DTTM)
 (select distinct   
c.AGRE_ID, 
c.CLM_NO,
max(ppol.CUST_ID),
date(c.CLM_OCCR_DTM),
c.CLM_OCCR_DTM,
date(c.CLM_OCCR_DTM),
c.CLM_OCCR_DTM,
date(c.CLM_OCCR_DTM),
c.CLM_OCCR_DTM,
'y',
CURRENT_DATE,
CURRENT_DATE
from  pcmp.claim c, pcmp.participation p, pcmp.CLAIM_PARTICIPATION cp, pcmp.PARTICIPATION ppol
where c.AGRE_ID=p.AGRE_ID
and c.AGRE_ID=ppol.AGRE_ID
and ppol.PTCP_TYP_CD='insrd'
and p.PTCP_ID=cp.PTCP_ID
and c.CLM_REL_SNPSHT_IND='n'
and p.PTCP_TYP_CD='clmt'
and c.CLM_NO in 
(select distinct CLM_NO from PCMP.CLAIM
minus
select DISTINCT CLM_NO from DW_REPORT.DW_CLAIM_POLICY_HISTORY)
group by c.AGRE_ID, 
c.CLM_NO,
c.CLM_OCCR_DTM
);

--Updating few bad rows where current policy indicator is 'y' and relationship end date is not null
update DW_REPORT.DW_CLAIM_POLICY_HISTORY 
set CRNT_PLCY_IND='y',
CLM_PLCY_RLTNS_END_DATE=null,
CLM_PLCY_RLTNS_END_DT=null
where CLM_NO in 
(   select distinct CLM_NO from PCMP.CLAIM
minus
select DISTINCT CLM_NO from DW_REPORT.DW_CLAIM_POLICY_HISTORY where CRNT_PLCY_IND = 'y');

--Updating few rows where Claim Relationship date is less than the Claim Injury date
update DW_REPORT.DW_CLAIM_POLICY_HISTORY as t 
set CLM_PLCY_RLTNS_EFF_DT = CLM_OCCR_DTM, CLM_PLCY_RLTNS_EFF_DATE = CLM_OCCR_DATE
WHERE 
(CLM_OCCR_DATE) < (select (min(CLM_PLCY_RLTNS_EFF_DATE)) from DW_REPORT.DW_CLAIM_POLICY_HISTORY as cph where cph.CLM_NO=t.CLM_NO)
and t.CLM_PLCY_RLTNS_EFF_DATE = (select (min(CLM_PLCY_RLTNS_EFF_DATE)) from DW_REPORT.DW_CLAIM_POLICY_HISTORY as cpx where cpx.CLM_NO=t.CLM_NO)
;

--one of the Claims has overlapping bad data and this script will take care of the bad data.
   delete from dw_Report.DW_CLAIM_POLICY_HISTORY 
   where crnt_plcy_ind ='n' and  
   clm_agre_id in 
   (
   select CLM_AGRE_ID from dw_Report.DW_CLAIM_POLICY_HISTORY
   group by CLM_AGRE_ID, CLM_PLCY_RLTNS_EFF_DT having count(*)>1
   );


-- Added this logic on 08/01/2019 to bring the missing claim_numbers.
CREATE TEMPORARY TABLE DW_PLCY_PRD_PARTICIPATION  AS
SELECT PP.* FROM dW_REPORT.DW_PLCY_PRD_PARTICIPATION pp
INNER JOIN (SELECT CUST_ID , max(AUDIT_USER_CREA_DTM)  AS AUDIT_USER_CREA_DTM  FROM DW_REPORT.DW_PLCY_PRD_PARTICIPATION  WHERE PTCP_TYP_CD='insrd' 
			and PLCY_PRD_PTCP_EFF_DT <> PLCY_PRD_PTCP_END_DT group by 1 ) AA
				ON PP.CUST_ID = AA.CUST_ID AND PP.AUDIT_USER_CREA_DTM = AA.AUDIT_USER_CREA_DTM
				WHERE PTCP_TYP_CD='insrd' 
			and PLCY_PRD_PTCP_EFF_DT <> PLCY_PRD_PTCP_END_DT;
-- The below TMP table is credted to find the first Business sequence number from the duplicate rows and filtering these rows.

CREATE TEMPORARY TABLE TMP_PLCY  AS
select DISTINCT har.CLM_AGRE_ID,har.CLM_NO,har.INS_PARTICIPANT,har.BUSN_SEQ_NO,P.busn_seq_no AS P_busn_seq_no ,P.MOST_RCNT_PLCY_PRD_IND,har.CRNT_PLCY_IND,P.AUDIT_USER_CREA_DTM, P.PLCY_NO,p.PLCY_AGRE_ID
from DW_PLCY_PRD_PARTICIPATION p
join pcmp.AGREEMENT ag on p.PLCY_AGRE_ID = ag.AGRE_ID AND AG.AGRE_TYP_CD = 'plcy' and p.PLCY_PRD_PTCP_EFF_DT <> p.PLCY_PRD_PTCP_END_DT
INNER JOIN (SELECT DISTINCT CLM_AGRE_ID,CLM_NO,INS_PARTICIPANT,BUSN_SEQ_NO,CRNT_PLCY_IND,PLCY_AGRE_ID FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY WHERE CLM_NO IN (
SELECT CLM_NO FROM (
SELECT CLM_NO,COUNT(*) FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY WHERE CRNT_PLCY_IND = 'y' GROUP BY CLM_NO HAVING COUNT(*) >1)VAR))HAR ON P.PLCY_AGRE_ID = HAR.PLCY_AGRE_ID
AND P.cust_id = HAR.INS_PARTICIPANT AND P.MOST_RCNT_PLCY_PRD_IND = har.CRNT_PLCY_IND AND P.busn_seq_no = har.BUSN_SEQ_NO  
WHERE PTCP_TYP_CD = 'insrd'
ORDER BY 1,8; 


CREATE TEMPORARY TABLE TMP_PLCY_DEL  AS
SELECT CPH.CLM_AGRE_ID,CPH.CLM_NO,CPH.INS_PARTICIPANT,CPH.BUSN_SEQ_NO,TP.BUSN_SEQ_NO AS TP_BUSN_SEQ_NO,CPH.CRNT_PLCY_IND,CPH.PLCY_NO FROM  DW_REPORT.DW_CLAIM_POLICY_HISTORY CPH INNER JOIN TMP_PLCY TP
ON TP.CLM_AGRE_ID = CPH.CLM_AGRE_ID  AND CPH.BUSN_SEQ_NO <> TP.BUSN_SEQ_NO ;

delete from DW_REPORT.DW_CLAIM_POLICY_HISTORY  where  CLM_AGRE_ID||CLM_NO||INS_PARTICIPANT||BUSN_SEQ_NO IN ( SELECT CLM_AGRE_ID||CLM_NO||INS_PARTICIPANT||BUSN_SEQ_NO FROM TMP_PLCY_DEL);

-- Added this logic on 08/01/2019 to delete the duplicate rows based on 2 current policy indicators.
-- Changed B.PLCY_AGRE_ID <> A.PLCY_AGRE_ID to B.PLCY_AGRE_ID = A.PLCY_AGRE_ID in the code on 12/02/2019.
delete from DW_REPORT.DW_CLAIM_POLICY_HISTORY  where  CLM_NO||INS_PARTICIPANT||PLCY_NO||PLCY_AGRE_ID||BUSN_SEQ_NO IN (
							SELECT B.CLM_NO||B.INS_PARTICIPANT||B.PLCY_NO||B.PLCY_AGRE_ID||B.BUSN_SEQ_NO FROM DW_PLCY_PRD_PARTICIPATION A
									INNER JOIN ( SELECT * FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY  WHERE CLM_NO IN  (SELECT CLM_NO  FROM (SELECT CLM_NO,COUNT(*) FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY WHERE CRNT_PLCY_IND = 'y' GROUP BY 1 HAVING COUNT(*) >1)A)) B
 											ON B.INS_PARTICIPANT = A.CUST_ID AND B.PLCY_AGRE_ID = A.PLCY_AGRE_ID and a.BUSN_SEQ_NO = b.BUSN_SEQ_NO) ;



-- Added the below logic on 09/04/2019 for missing policy information for valid claim_number and cust_id.
CREATE TEMPORARY TABLE TMP_PLCY_UPDATE  AS
select DISTINCT har.CLM_AGRE_ID,har.CLM_NO,har.INS_PARTICIPANT,har.BUSN_SEQ_NO,P.busn_seq_no AS P_busn_seq_no ,P.MOST_RCNT_PLCY_PRD_IND,har.CRNT_PLCY_IND,P.AUDIT_USER_CREA_DTM, P.PLCY_NO,p.PLCY_AGRE_ID,PCE.CTL_ELEM_TYP_CD,CEST.CTL_ELEM_SUB_TYP_CD,CEST.CTL_ELEM_SUB_TYP_NM
from dw_report.DW_PLCY_PRD_PARTICIPATION p
INNER JOIN (SELECT *  FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY WHERE PLCY_NO IS NULL)HAR ON  P.cust_id = HAR.INS_PARTICIPANT 
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON pce.PLCY_PRD_ID=p.PLCY_PRD_ID and pce.CTL_ELEM_TYP_CD='plcy_typ' and pce.VOID_IND='n'
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE CEST ON  cest.CTL_ELEM_SUB_TYP_ID=pce.CTL_ELEM_SUB_TYP_ID 
WHERE PTCP_TYP_CD = 'insrd'
AND P.CUST_ID||P.AUDIT_USER_CREA_DTM  IN (SELECT CUST_ID||AUDIT_USER_CREA_DTM FROM (
SELECT CUST_ID,MAX(AUDIT_USER_CREA_DTM) AS AUDIT_USER_CREA_DTM FROM dw_report.DW_PLCY_PRD_PARTICIPATION WHERE PTCP_TYP_CD = 'insrd' GROUP BY 1)A);


update DW_REPORT.DW_CLAIM_POLICY_HISTORY A
set PLCY_NO = B.PLCY_NO,
PLCY_AGRE_ID = B.PLCY_AGRE_ID,
BUSN_SEQ_NO = B.P_BUSN_SEQ_NO,
CTL_ELEM_SUB_TYP_CD = B.CTL_ELEM_SUB_TYP_CD,
CTL_ELEM_SUB_TYP_NM = B.CTL_ELEM_SUB_TYP_NM,
CTL_ELEM_TYP_CD = B.CTL_ELEM_TYP_CD
FROM TMP_PLCY_UPDATE  B 
       WHERE A.CLM_NO = B.CLM_NO;

-- Added the join condition for BUSN_SEQ_NO on 10/01/2020 for missing  claim_number.
CREATE TEMPORARY TABLE TMP_PLCY_DEL_DEL  AS
select  a.CLM_NO||a.INS_PARTICIPANT||a.PLCY_NO||a.PLCY_AGRE_ID||a.BUSN_SEQ_NO as abc from dw_report.DW_PLCY_PRD_PARTICIPATION b
      inner join ( SELECT * FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY  WHERE CLM_NO IN  (SELECT CLM_NO  FROM 
                                                                                      (SELECT CLM_NO,COUNT(*) 
                                                                                       FROM DW_REPORT.DW_CLAIM_POLICY_HISTORY
                                                                                       WHERE CRNT_PLCY_IND = 'y' GROUP BY 1 HAVING COUNT(*) >1)A)) a
      on a.PLCY_AGRE_ID = b.PLCY_AGRE_ID
     and a.INS_PARTICIPANT = b.cust_id
     and a.BUSN_SEQ_NO = b.BUSN_SEQ_NO
     WHERE PTCP_TYP_CD = 'insrd'
    qualify row_number() over(partition by b.cust_id,a.CLM_NO order by CRNT_PLCY_PRD_PTCP_IND ,B.PLCY_NO,PLCY_PRD_PTCP_EFF_DT DESC,PLCY_PRD_PTCP_END_DT desc ) =1;
    
 delete from DW_REPORT.DW_CLAIM_POLICY_HISTORY  where  CLM_NO||INS_PARTICIPANT||PLCY_NO||PLCY_AGRE_ID||BUSN_SEQ_NO IN ( SELECT ABC FROM TMP_PLCY_DEL_DEL)  ; 


COMMIT;