/* Version #  1		 	:  	Prod Release date 06/20/2017  
   Version #  2		 	:  	Prod Release date 07/25/2017 
*/

/* Table Description 	: 	This table contains case, issue, event, task, and case status details for exam scheduling cases.  
                            There could be multiple rows for a case depending on its referral events.  
							There will be one row per Referral Event ID if it exists, if not there will be one row per case 						
*/	
								

/* Source Tables 	   :PCMP.CASE_RESOLUTION_TYPE
						PCMP.CASE_ISSUE_TYPE 
						PCMP.CASE_STATE_TYPE
						PCMP.CASE_STATUS_TYPE
						PCMP.CASE_STATUS_REASON_TYPE
						PCMP.CASE_DETAIL_EXM_SCH
						PCMP.CASE_EVENT
						PCMP.CASE_EVENT_TYPE
						PCMP.CASE_ISSUE
						PCMP.CASE_PARTICIPANT
						PCMP.CUSTOMER_NAME
						PCMP.CASE_PROV_SPL_TYPE
						PCMP.CASE_STATE_STATUS_HISTORY
						PCMP.CASES
						PCMP.ORGANIZATIONAL_UNIT
						PCMP.TASK
						PCMP.USERS
*/	

/* COMMENTS SP_552: Add filter to SQL of custom exam scheuduling case table:
COALESCE(ERR.ORG_UNT_ID, ERR.USER_ID) = COALESCE(ERR_TASK_ORG_UNT_ID,TASK2.ERR_TASK_USER_ID) added to exam report received portion (ERR) of SQL
Also, add referral create date for the referral event.*/	
												
--\set ON_ERROR_STOP on
TRUNCATE TABLE DW_REPORT.DW_EXAM_SCHDL_CASE;
INSERT /*+DIRECT*/ INTO DW_REPORT.DW_EXAM_SCHDL_CASE(
CASE_ID                                  
,CASE_NO                                  
,CLM_AGRE_ID                              
,CLM_NO                                   
,CASE_NM                                  
,CASE_EFF_DATE                            
,CASE_DUE_DATE                            
,CASE_RSOL_TYP_CD                         
,CASE_RSOL_TYP_NM                         
,CASE_COMP_DATE                           
,EXAM_TYPE_CD                             
,EXAM_TYPE_NM                             
,CASE_STT_EFF_DATE                        
,CASE_STT_TYP_CD                          
,CASE_STT_TYP_NM                          
,CASE_STS_EFF_DATE                        
,CASE_STS_TYP_CD                          
,CASE_STS_TYP_NM                          
,CASE_STS_RSN_EFF_DATE                    
,CASE_STS_RSN_TYP_CD                      
,CASE_STS_RSN_TYP_NM                      
,EXAM_SCHDL_DATE                          
,EXAM_SCHDL_DTM                           
,EXAM_SCHDL_USER_ID                       
,EXAM_SCHDL_USER_LGN_NM                   
,EXAM_SCHDL_USER_NM                       
,EXAM_PHYSC_CUST_ID                       
,EXAM_PHYSC_NAME                          
,EXAM_PHYSC_PTCP_EFF_DATE                 
,EXAM_PHYSC_PTCP_END_DATE                 
,RQSTD_PHYSC_SPCLT_TYP_CD                 
,RQSTD_PHYSC_SPCLT_TYP_NM                 
,SCNDR_RQSTD_PHYSC_SPCLT_TYP_CD           
,SCNDR_RQSTD_PHYSC_SPCLT_TYP_NM           
,EXAM_DATE                                
,EXAM_DTM                                 
,EXAM_TIME                                
,EXAM_RPT_RCPT_DATE                       
,CLMNT_AVLBL_DESCR                        
,CLMNT_AVLBL_SUN_IND                      
,CLMNT_AVLBL_MON_IND                      
,CLMNT_AVLBL_TUE_IND                      
,CLMNT_AVLBL_WED_IND                      
,CLMNT_AVLBL_THU_IND                      
,CLMNT_AVLBL_FRI_IND                      
,CLMNT_AVLBL_SAT_IND                      
,RFRL_EVENT_ID                            
,RFRL_EVENT_TYP_CD                        
,RFRL_EVENT_TYP_NM                        
,RFRL_EVENT_DUE_DATE                      
,RFRL_EVENT_FST_RMND_DATE                 
,RFRL_EVENT_COMP_DATE                     
,RFRL_EVENT_ASGND_USER_ID                 
,RFRL_EVENT_ASGND_USER_LGN_NM             
,RFRL_EVENT_ASGND_USER_NM                 
,RFRL_EVENT_ASGND_ORG_UNT_ID              
,RFRL_EVENT_ASGND_ORG_UNT_NM              
,RFRL_EVENT_ASGND_ORG_UNT_ABRV_NM         
,RFRL_TASK_ASGND_USER_ID                  
,RFRL_TASK_ASGND_USER_LGN_NM              
,RFRL_TASK_ASGND_USER_NM                  
,RFRL_TASK_ASGND_ORG_UNT_ID               
,RFRL_TASK_ASGND_ORG_UNT_NM               
,RFRL_TASK_ASGND_ORG_UNT_ABRV_NM          
,EXAM_RPT_RCPT_EVENT_ID                   
,EXAM_RPT_RCPT_EVENT_DUE_DATE             
,EXAM_RPT_RCPT_EVENT_FST_RMND_DATE        
,EXAM_RPT_RCPT_EVENT_COMP_DATE            
,EXAM_RPT_RCPT_EVENT_ASGND_USER_ID        
,EXAM_RPT_RCPT_EVENT_ASGND_USER_LGN_NM    
,EXAM_RPT_RCPT_EVENT_ASGND_USER_NM        
,EXAM_RPT_RCPT_EVENT_ASGND_ORG_UNT_ID     
,EXAM_RPT_RCPT_EVENT_ASGND_ORG_UNT_NM     
,EXAM_RPT_RCPT_EVENT_ASGND_ORG_UNT_ABRV_NM
,EXAM_RPT_RCPT_TASK_ASGND_USER_ID         
,EXAM_RPT_RCPT_TASK_ASGND_USER_LGN_NM     
,EXAM_RPT_RCPT_TASK_ASGND_USER_NM         
,EXAM_RPT_RCPT_TASK_ASGND_ORG_UNT_ID      
,EXAM_RPT_RCPT_TASK_ASGND_ORG_UNT_NM      
,EXAM_RPT_RCPT_TASK_ASGND_ORG_UNT_ABRV_NM 
,DW_CREATE_DTM                            
,DW_UPDATE_DTM
,RFRL_EVENT_CREA_DTM
,EXAM_LCTN_STR_1
,EXAM_LCTN_STR_2
,EXAM_LCTN_CITY_NAME
,EXAM_LCTN_CNTY_NAME
,EXAM_LCTN_STATE_NAME
,EXAM_LCTN_POST_CODE
,EXAM_ADNDM_RQSTD_IND
,EXAM_RSLT_SPNSN_IND
,EXAM_SCHDL_ASGND_USER_ID
,EXAM_SCHDL_ASGND_USER_LGN_NM
,EXAM_SCHDL_ASGND_USER_NM
,EXAM_SCHDL_ASGND_USER_SUPV_ID
,EXAM_SCHDL_ASGND_USER_SUPV_LGN_NM
,EXAM_SCHDL_ASGND_USER_SUPV_NM
,EXAM_SCHDL_ASGND_USER_FNCT_ROLE_ID
,EXAM_SCHDL_ASGND_USER_FNCT_ROLE_NM
,EXAM_SCHDL_ASGND_USER_ORG_UNT_ID
,EXAM_SCHDL_ASGND_USER_ORG_UNT_ABRV_NM
,EXAM_SCHDL_ASGND_USER_ORG_UNT_NM
,EXAM_SCHDL_CASE_PRFL_CTG_TYP_CD
,EXAM_SCHDL_CASE_PRFL_CTG_TYP_NM
,ADR_CASE_ID 
,ADR_CASE_NO
,ADR_CASE_CREATE_DTM

)
(
SELECT DISTINCT
/*CASES*/
C.CASE_ID                                                 AS   CASE_ID, 
C.CASE_NO                                                 AS   CASE_NO, 
C.CASE_CNTX_ID                                            AS   CLM_AGRE_ID, 
C.CASE_CNTX_NO                                            AS   CLM_NO, 
C.CASE_NM                                                 AS   CASE_NM, 
DATE(C.CASE_EFF_DT)                                       AS   CASE_EFF_DATE, 
DATE(C.CASE_DUE_DT)                                       AS   CASE_DUE_DATE, 
CASE WHEN C.CASE_RSOL_TYP_CD IS NULL THEN '-1' 
     ELSE C.CASE_RSOL_TYP_CD END                          AS   CASE_RSOL_TYP_CD, 
CRT.CASE_RSOL_TYP_NM                                      AS   CASE_RSOL_TYP_NM, 
DATE(C.CASE_COMP_DT)                                      AS   CASE_COMP_DATE,
/*CASE_ISSUE*/                                                 
CASE WHEN CI.CASE_ISS_TYP_CD IS NULL THEN '-1' 
     ELSE CI.CASE_ISS_TYP_CD END                          AS   EXAM_TYPE_CD, 
CIT.CASE_ISS_TYP_NM                                       AS   EXAM_TYPE_NM,
/*CASE_STATE_STATUS*/
DATE(css.CASE_STT_STS_STT_EFF_DT)                         AS   CASE_STT_EFF_DATE, 
CASE WHEN css.CASE_STT_TYP_CD IS NULL THEN '-1' 
     ELSE css.CASE_STT_TYP_CD END                         AS   CASE_STT_TYP_CD, 
CST.CASE_STT_TYP_NM                                       AS   CASE_STT_TYP_NM,
DATE(css.CASE_STT_STS_STS_EFF_DT)                         AS   CASE_STS_EFF_DATE, 
CASE WHEN css.CASE_STS_TYP_CD IS NULL THEN '-1' 
     ELSE css.CASE_STS_TYP_CD END                         AS   CASE_STS_TYP_CD, 
CSTT.CASE_STS_TYP_NM                                      AS   CASE_STS_TYP_NM,
DATE(css.CASE_STT_STS_STS_RSN_EFF_DT)                     AS   CASE_STS_RSN_EFF_DATE, 
CASE WHEN css.CASE_STS_RSN_TYP_CD IS NULL THEN '-1' 
     ELSE css.CASE_STS_RSN_TYP_CD END                     AS   CASE_STS_RSN_TYP_CD, 
CSRT.CASE_STS_RSN_TYP_NM                                  AS   CASE_STS_RSN_TYP_NM,
/*CASE STATUS SPECIAL CONDITION*/
DATE(EXAM_SCHEDULED_DATE)                                 AS   EXAM_SCHDL_DATE, 
EXAM_SCHEDULED_DATE                                       AS   EXAM_SCHDL_DTM, 
EXAM_SCHEDULED_BY                                         AS   EXAM_SCHDL_USER_ID,
U1.USER_LGN_NM                                            AS   EXAM_SCHDL_USER_LGN_NM,
U1.USER_DRV_UPCS_NM                                       AS   EXAM_SCHDL_USER_NM,   
/*CASE_PARTICIPANT*/
CP.CUST_ID                                                AS   EXAM_PHYSC_CUST_ID, 
COALESCE(CP.CASE_PTCP_NM, CN.CUST_NM_DRV_UPCS_NM)         AS   EXAM_PHYSC_NAME, 
DATE(CP.CASE_PTCP_EFF_DT)                                 AS   EXAM_PHYSC_PTCP_EFF_DATE, 
DATE(CP.CASE_PTCP_END_DT)                                 AS   EXAM_PHYSC_PTCP_END_DATE,
/*CASE_DETAIL_EXAM_SCH*/
CASE WHEN CDE.CPS_TYP_CD IS NULL THEN '-1'
     ELSE CDE.CPS_TYP_CD END                              AS   RQSTD_PHYSC_SPCLT_TYP_CD, 
CPS1.CPS_TYP_NM                                           AS   RQSTD_PHYSC_SPCLT_TYP_NM,  
CASE WHEN CDE.CPS_TYP_CD_SCND IS NULL THEN '-1' 
     ELSE CDE.CPS_TYP_CD_SCND END                         AS   SCNDR_RQSTD_PHYSC_SPCLT_TYP_CD, 
CPS2.CPS_TYP_NM                                           AS   SCNDR_RQSTD_PHYSC_SPCLT_TYP_NM, 
DATE(CDE.CDES_EXM_DT)                                     AS   EXAM_DATE, 
CDE.CDES_EXM_DT                                           AS   EXAM_DTM,
TO_CHAR(CDES_EXM_DT, 'HH12:MI:SS AM')                        AS   EXAM_TIME,
DATE(CDE.CDES_EXM_RPT_RECV_DT)                            AS   EXAM_RPT_RCPT_DATE,
CDE.CDES_CLMT_AVL_NAR_DESC                                AS   CLMNT_AVLBL_DESCR, 
CDE.CDES_CLMT_AVL_SUN_IND                                 AS   CLMNT_AVLBL_SUN_IND, 
CDE.CDES_CLMT_AVL_MON_IND                                 AS   CLMNT_AVLBL_MON_IND, 
CDE.CDES_CLMT_AVL_TUE_IND                                 AS   CLMNT_AVLBL_TUE_IND, 
CDE.CDES_CLMT_AVL_WED_IND                                 AS   CLMNT_AVLBL_WED_IND, 
CDE.CDES_CLMT_AVL_THU_IND                                 AS   CLMNT_AVLBL_THU_IND, 
CDE.CDES_CLMT_AVL_FRI_IND                                 AS   CLMNT_AVLBL_FRI_IND, 
CDE.CDES_CLMT_AVL_SAT_IND                                 AS   CLMNT_AVLBL_SAT_IND,
/*ERR*/
REF.CASE_EVNT_ID                                          AS   RFRL_EVENT_ID, 
CASE WHEN REF.CASE_EVNT_TYP_CD IS NULL THEN '-1' 
     ELSE REF.CASE_EVNT_TYP_CD END                        AS   RFRL_EVENT_TYP_CD, 
CET1.CASE_EVNT_TYP_NM                                     AS   RFRL_EVENT_TYP_NM,
DATE(REF.CASE_EVNT_DUE_DT)                                AS   RFRL_EVENT_DUE_DATE, 
DATE(REF.CASE_EVNT_FST_RMND_DT)                           AS   RFRL_EVENT_FST_RMND_DATE, 
DATE(REF.CASE_EVNT_COMP_DT)                               AS   RFRL_EVENT_COMP_DATE, 
REF.USER_ID                                               AS   RFRL_EVENT_ASGND_USER_ID, 
U2.USER_LGN_NM                                            AS   RFRL_EVENT_ASGND_USER_LGN_NM, 
U2.USER_DRV_UPCS_NM                                       AS   RFRL_EVENT_ASGND_USER_NM,                                    
REF.ORG_UNT_ID                                            AS   RFRL_EVENT_ASGND_ORG_UNT_ID,
OU1.ORG_UNT_NM                                            AS   RFRL_EVENT_ASGND_ORG_UNT_NM, 
OU1.ORG_UNT_ABRV_NM                                       AS   RFRL_EVENT_ASGND_ORG_UNT_ABRV_NM,
TASK1.REF_TASK_USER_ID                                    AS   RFRL_TASK_ASGND_USER_ID,
U4.USER_LGN_NM                                            AS   RFRL_TASK_ASGND_USER_LGN_NM, 
U4.USER_DRV_UPCS_NM                                       AS   RFRL_TASK_ASGND_USER_NM,
TASK1.REF_TASK_ORG_UNT_ID                                 AS   RFRL_TASK_ASGND_ORG_UNT_ID,
OU3.ORG_UNT_NM                                            AS   RFRL_TASK_ASGND_ORG_UNT_NM, 
OU3.ORG_UNT_ABRV_NM                                       AS   RFRL_TASK_ASGND_ORG_UNT_ABRV_NM,
/*ERR*/
ERR.CASE_EVNT_ID                                          AS   EXAM_RPT_RCPT_EVENT_ID, 
DATE(ERR.CASE_EVNT_DUE_DT)                                AS   EXAM_RPT_RCPT_EVENT_DUE_DATE, 
DATE(ERR.CASE_EVNT_FST_RMND_DT)                           AS   EXAM_RPT_RCPT_EVENT_FST_RMND_DATE, 
DATE(ERR.CASE_EVNT_COMP_DT)                               AS   EXAM_RPT_RCPT_EVENT_COMP_DATE, 
ERR.USER_ID                                               AS   EXAM_RPT_RCPT_EVENT_ASGND_USER_ID, 
U3.USER_LGN_NM                                            AS   EXAM_RPT_RCPT_EVENT_ASGND_USER_LGN_NM, 
U3.USER_DRV_UPCS_NM                                       AS   EXAM_RPT_RCPT_EVENT_ASGND_USER_NM, 
ERR.ORG_UNT_ID                                            AS   EXAM_RPT_RCPT_EVENT_ASGND_ORG_UNT_ID,
OU2.ORG_UNT_NM                                            AS   EXAM_RPT_RCPT_EVENT_ASGND_ORG_UNT_NM, 
OU2.ORG_UNT_ABRV_NM                                       AS   EXAM_RPT_RCPT_EVENT_ASGND_ORG_UNT_ABRV_NM, 
TASK2.ERR_TASK_USER_ID                                    AS   EXAM_RPT_RCPT_TASK_ASGND_USER_ID, 
U5.USER_LGN_NM                                            AS   EXAM_RPT_RCPT_TASK_ASGND_USER_LGN_NM, 
U5.USER_DRV_UPCS_NM                                       AS   EXAM_RPT_RCPT_TASK_ASGND_USER_NM,
TASK2.ERR_TASK_ORG_UNT_ID                                 AS   EXAM_RPT_RCPT_TASK_ASGND_ORG_UNT_ID,
OU4.ORG_UNT_NM                                            AS   EXAM_RPT_RCPT_TASK_ASGND_ORG_UNT_NM, 
OU4.ORG_UNT_ABRV_NM                                       AS   EXAM_RPT_RCPT_TASK_ASGND_ORG_UNT_ABRV_NM,
CURRENT_DATE                                                   AS   DW_CREATE_DTM,
CURRENT_DATE                                                   AS   DW_UPDATE_DTM,
REF.AUDIT_USER_CREA_DTM                                   AS   RFRL_EVENT_CREA_DTM ,
CASE WHEN CDE.CDES_EXM_ADDR_STR_1 IS NULL AND CDE.CDES_EXM_ADDR_STR_2 IS NULL AND CDE.CDES_EXM_ADDR_CITY_NM IS NULL AND CDE.CDES_EXM_ADDR_CNTY_NM IS NULL AND CDE.CDES_EXM_ADDR_POST_CD IS NULL AND CDE.STT_ID IS NULL
THEN CP.CASE_PTCP_STR_1 ELSE CDE.CDES_EXM_ADDR_STR_1 END AS EXAM_LCTN_STR_1,
CASE WHEN CDE.CDES_EXM_ADDR_STR_1 IS NULL AND CDE.CDES_EXM_ADDR_STR_2 IS NULL AND CDE.CDES_EXM_ADDR_CITY_NM IS NULL AND CDE.CDES_EXM_ADDR_CNTY_NM IS NULL AND CDE.CDES_EXM_ADDR_POST_CD IS NULL AND CDE.STT_ID IS NULL
THEN CP.CASE_PTCP_STR_2 ELSE CDE.CDES_EXM_ADDR_STR_2 END AS EXAM_LCTN_STR_2,
CASE WHEN CDE.CDES_EXM_ADDR_STR_1 IS NULL AND CDE.CDES_EXM_ADDR_STR_2 IS NULL AND CDE.CDES_EXM_ADDR_CITY_NM IS NULL AND CDE.CDES_EXM_ADDR_CNTY_NM IS NULL AND CDE.CDES_EXM_ADDR_POST_CD IS NULL AND CDE.STT_ID IS NULL
THEN CP.CASE_PTCP_CITY ELSE CDE.CDES_EXM_ADDR_CITY_NM END AS EXAM_LCTN_CITY_NAME,
CASE WHEN CDE.CDES_EXM_ADDR_STR_1 IS NULL AND CDE.CDES_EXM_ADDR_STR_2 IS NULL AND CDE.CDES_EXM_ADDR_CITY_NM IS NULL AND CDE.CDES_EXM_ADDR_CNTY_NM IS NULL AND CDE.CDES_EXM_ADDR_POST_CD IS NULL AND CDE.STT_ID IS NULL
THEN CP.CASE_PTCP_CNTY ELSE CDE.CDES_EXM_ADDR_CNTY_NM END AS EXAM_LCTN_CNTY_NAME,
CASE WHEN CDE.CDES_EXM_ADDR_STR_1 IS NULL AND CDE.CDES_EXM_ADDR_STR_2 IS NULL AND CDE.CDES_EXM_ADDR_CITY_NM IS NULL AND CDE.CDES_EXM_ADDR_CNTY_NM IS NULL AND CDE.CDES_EXM_ADDR_POST_CD IS NULL AND CDE.STT_ID IS NULL
THEN CP.CASE_PTCP_STT ELSE ST.STT_NM END AS EXAM_LCTN_STATE_NAME,
CASE WHEN CDE.CDES_EXM_ADDR_STR_1 IS NULL AND CDE.CDES_EXM_ADDR_STR_2 IS NULL AND CDE.CDES_EXM_ADDR_CITY_NM IS NULL AND CDE.CDES_EXM_ADDR_CNTY_NM IS NULL AND CDE.CDES_EXM_ADDR_POST_CD IS NULL AND CDE.STT_ID IS NULL
THEN CP.CASE_PTCP_ZIP ELSE CDE.CDES_EXM_ADDR_POST_CD END AS EXAM_LCTN_POST_CODE,
CDE.CDES_ADNDM_REQS_IND AS EXAM_ADNDM_RQSTD_IND,
CDE.CDES_RSLT_SUSPD_IND AS EXAM_RSLT_SPNSN_IND,
ASNM.USER_ID AS EXAM_SCHDL_ASGND_USER_ID,
US.USER_LGN_NM AS EXAM_SCHDL_ASGND_USER_LGN_NM,
US.USER_DRV_UPCS_NM AS EXAM_SCHDL_ASGND_USER_NM,
US.USER_SUPR_ID AS EXAM_SCHDL_ASGND_USER_SUPV_ID,
SUPV.USER_LGN_NM AS EXAM_SCHDL_ASGND_USER_SUPV_LGN_NM,
SUPV.USER_DRV_UPCS_NM AS EXAM_SCHDL_ASGND_USER_SUPV_NM,
ASNM.FNCT_ROLE_ID AS EXAM_SCHDL_ASGND_USER_FNCT_ROLE_ID,
FR.FNCT_ROLE_NM AS EXAM_SCHDL_ASGND_USER_FNCT_ROLE_NM,
ASNM.ORG_UNT_ID AS EXAM_SCHDL_ASGND_USER_ORG_UNT_ID,
OU.ORG_UNT_ABRV_NM AS EXAM_SCHDL_ASGND_USER_ORG_UNT_ABRV_NM,
OU.ORG_UNT_NM AS EXAM_SCHDL_ASGND_USER_ORG_UNT_NM,
CASE WHEN CASEPR.CASE_PRFL_CTG_TYP_CD IS NULL THEN '-1' ELSE CASEPR.CASE_PRFL_CTG_TYP_CD END AS EXAM_SCHDL_CASE_PRFL_CTG_TYP_CD,
CASEPR.CASE_PRFL_CTG_TYP_NM AS EXAM_SCHDL_CASE_PRFL_CTG_TYP_NM, 
ADRCASE.ADR_CASE_ID  AS ADR_CASE_ID ,
ADRCASE.ADR_CASE_NO  AS  ADR_CASE_NO,
ADRCASE.ADR_CASE_CREATE_DTM AS ADR_CASE_CREATE_DTM
FROM PCMP.CASES C
LEFT JOIN PCMP.CASE_STATE_STATUS CSS on  c.CASE_ID = css.CASE_ID AND CSS.VOID_IND = 'n'
LEFT JOIN PCMP.CASE_ISSUE CI on c.CASE_ID = ci.CASE_ID AND CI.VOID_IND = 'n' AND CI.CASE_ISS_PRI_IND = 'y'
LEFT JOIN PCMP.CASE_RESOLUTION_TYPE CRT ON C.CASE_RSOL_TYP_CD = CRT.CASE_RSOL_TYP_CD
LEFT JOIN PCMP.CASE_ISSUE_TYPE CIT ON CI.CASE_ISS_TYP_CD = CIT.CASE_ISS_TYP_CD 
LEFT JOIN PCMP.CASE_STATE_TYPE CST ON CSS.CASE_STT_TYP_CD = CST.CASE_STT_TYP_CD
LEFT JOIN PCMP.CASE_STATUS_TYPE CSTT ON CSS.CASE_STS_TYP_CD = CSTT.CASE_STS_TYP_CD
LEFT JOIN PCMP.CASE_STATUS_REASON_TYPE CSRT ON CSS.CASE_STS_RSN_TYP_CD = CSRT.CASE_STS_RSN_TYP_CD
LEFT JOIN (
             SELECT 
             CASE_STT_STS_ID, 
             COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) EXAM_SCHEDULED_DATE, 
             COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) EXAM_SCHEDULED_BY
             FROM PCMP.CASE_STATE_STATUS_HISTORY 
             WHERE VOID_IND = 'n'
             AND   (CASE_STT_STS_ID, COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM)) 
                   IN (
                        SELECT 
                        CASE_STT_STS_ID, 
                        max(COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM)) 
                        FROM PCMP.CASE_STATE_STATUS_HISTORY
                        where VOID_IND = 'n'
                        and   CASE_STS_TYP_CD in ('exam_sched_bwc', 'exm_sch_mco', 'exam_sched_vedr') 
                        and   CASE_STS_RSN_TYP_CD = 'await_attend'
                        group by 1
                      )
          ) ES ON CSS.CASE_STT_STS_ID = ES.CASE_STT_STS_ID
LEFT JOIN PCMP.USERS U1 ON ES.EXAM_SCHEDULED_BY = U1.USER_ID
LEFT JOIN PCMP.CASE_PARTICIPANT CP ON C.CASE_ID = CP.CASE_ID 
                                   AND CP.VOID_IND = 'n' 
                                   AND CP.CASE_PTCP_TYP_CD = 'exam_phys' 
                                   AND CP.CASE_PTCP_END_DT IS NULL 
                                   AND CP.CASE_PTCP_PRI_IND = 'y'
LEFT JOIN PCMP.CUSTOMER_NAME CN ON CP.CUST_ID = CN.CUST_ID 
                                AND CN.VOID_IND = 'n'
                                AND CN.CUST_NM_END_DT IS NULL 
                                AND CN.CUST_NM_TYP_CD IN ('busn_legal_nm', 'prsn_nm')
LEFT JOIN PCMP.CASE_DETAIL_EXM_SCH CDE ON C.CASE_ID = CDE.CASE_ID AND CDE.VOID_IND = 'n'
LEFT JOIN PCMP.CASE_PROV_SPL_TYPE CPS1 ON CDE.CPS_TYP_CD = CPS1.CPS_TYP_CD
LEFT JOIN PCMP.CASE_PROV_SPL_TYPE CPS2 ON CDE.CPS_TYP_CD_SCND = CPS2.CPS_TYP_CD
LEFT JOIN (
             SELECT 
             CASE_EVNT_ID, CASE_ID, CASE_EVNT_TYP_CD, CASE_EVNT_DUE_DT, CASE_EVNT_FST_RMND_DT, CASE_EVNT_COMP_DT, USER_ID, ORG_UNT_ID, 
             rank() over (partition by CASE_ID order by CASE_EVNT_COMP_DT desc) RANK, AUDIT_USER_ID_CREA REF_CREATE_USER_ID, AUDIT_USER_CREA_DTM
             from PCMP.CASE_EVENT
             where VOID_IND = 'n' and CASE_EVNT_TYP_CD IN ('ft_exam_sced', 'ft_exam_sced_stat_od') AND CASE_ID IS NOT NULL
          ) REF ON C.CASE_ID = REF.CASE_ID AND (REF.CASE_EVNT_COMP_DT is null or REF.RANK = 1)
LEFT JOIN PCMP.CASE_EVENT_TYPE CET1 ON REF.CASE_EVNT_TYP_CD = CET1.CASE_EVNT_TYP_CD
LEFT JOIN PCMP.USERS U2 ON REF.USER_ID = U2.USER_ID
LEFT JOIN PCMP.ORGANIZATIONAL_UNIT OU1 ON REF.ORG_UNT_ID = OU1.ORG_UNT_ID
LEFT JOIN (
             SELECT 
             CASE_EVNT_ID, CASE_ID, CASE_EVNT_TYP_CD, CASE_EVNT_DUE_DT, CASE_EVNT_FST_RMND_DT, CASE_EVNT_COMP_DT, USER_ID, ORG_UNT_ID, 
             rank() over (partition by CASE_ID order by CASE_EVNT_ID desc) RANK
             from PCMP.CASE_EVENT
             where VOID_IND = 'n' and CASE_EVNT_TYP_CD = 'check_exam_rpt_rec' AND CASE_ID IS NOT NULL
          ) ERR ON C.CASE_ID = ERR.CASE_ID AND ERR.RANK = 1
LEFT JOIN PCMP.USERS U3 ON ERR.USER_ID = U3.USER_ID
LEFT JOIN PCMP.ORGANIZATIONAL_UNIT OU2 ON ERR.ORG_UNT_ID = OU2.ORG_UNT_ID
LEFT JOIN (
              SELECT 
              DISTINCT
              TD.TASK_DATA_VAL_STR, 
              T.USER_ID REF_TASK_USER_ID, 
              T.ORG_UNT_ID REF_TASK_ORG_UNT_ID,
              RANK() OVER (PARTITION BY TD.TASK_DATA_VAL_STR ORDER BY T.AUDIT_USER_CREA_DTM DESC) RANK
              from PCMP.TASK T
              JOIN PCMP.TASK_DATA TD ON T.TASK_ID = TD.TASK_ID AND TD.APP_DATA_TYP_CD = 'case_event_id'
              WHERE T.VOID_IND = 'n'  and t.TASK_STS_TYP_CD <> 20
            ) TASK1 ON REF.CASE_EVNT_ID = TASK1.TASK_DATA_VAL_STR AND TASK1.RANK = 1 AND REF.REF_CREATE_USER_ID <> TASK1.REF_TASK_USER_ID
LEFT JOIN PCMP.USERS U4 ON TASK1.REF_TASK_USER_ID = U4.USER_ID
LEFT JOIN PCMP.ORGANIZATIONAL_UNIT OU3 ON TASK1.REF_TASK_ORG_UNT_ID = OU3.ORG_UNT_ID
LEFT JOIN (
              SELECT 
              DISTINCT
              TD.TASK_DATA_VAL_STR, 
              T.USER_ID ERR_TASK_USER_ID, 
              T.ORG_UNT_ID ERR_TASK_ORG_UNT_ID,
              RANK() OVER (PARTITION BY TD.TASK_DATA_VAL_STR ORDER BY T.AUDIT_USER_CREA_DTM DESC) RANK
              from PCMP.TASK T
              JOIN PCMP.TASK_DATA TD ON T.TASK_ID = TD.TASK_ID AND TD.APP_DATA_TYP_CD = 'case_event_id'
              WHERE T.VOID_IND = 'n'  and t.TASK_STS_TYP_CD <> 20
            ) TASK2 ON ERR.CASE_EVNT_ID = TASK2.TASK_DATA_VAL_STR 
                      AND COALESCE(ERR.ORG_UNT_ID, ERR.USER_ID) = COALESCE(ERR_TASK_ORG_UNT_ID,TASK2.ERR_TASK_USER_ID)
                     AND TASK2.RANK = 1
LEFT JOIN PCMP.USERS U5 ON TASK2.ERR_TASK_USER_ID = U5.USER_ID
LEFT JOIN PCMP.ORGANIZATIONAL_UNIT OU4 ON TASK2.ERR_TASK_ORG_UNT_ID = OU4.ORG_UNT_ID
LEFT JOIN PCMP.STATE ST ON ST.STT_ID = CDE.STT_ID
LEFT JOIN PCMP.ASSIGNMENT ASNM ON ASNM.ASGN_CNTX_ID = C.CASE_ID AND ASNM.ASGN_PRI_OWNR_IND = 'y' AND ASNM.APP_CNTX_TYP_CD = 'case' AND ASNM.ASGN_END_DT IS NULL
LEFT JOIN PCMP.USERS US ON US.USER_ID = ASNM.USER_ID 
LEFT JOIN PCMP.USERS SUPV ON US.USER_SUPR_ID = SUPV.USER_ID 
LEFT JOIN PCMP.FUNCTIONAL_ROLE FR ON FR.FNCT_ROLE_ID = ASNM.FNCT_ROLE_ID
LEFT JOIN PCMP.ORGANIZATIONAL_UNIT OU ON OU.ORG_UNT_ID = ASNM.ORG_UNT_ID
LEFT JOIN (SELECT DISTINCT CP.CASE_ID AS CASE_ID , CP.CASE_PRFL_SEQ_NO , CP.CASE_PRFL_CTG_TYP_CD ,CPCT.CASE_PRFL_CTG_TYP_NM FROM PCMP.CASE_PROFILE CP
                           INNER JOIN (SELECT CASE_ID,MIN(CASE_PRFL_SEQ_NO) AS CASE_PRFL_SEQ_NO  FROM PCMP.CASE_PROFILE WHERE VOID_IND = 'n' GROUP BY CASE_ID) CPMIN
                                  ON CP.CASE_ID = CPMIN.CASE_ID AND CP.CASE_PRFL_SEQ_NO = CPMIN.CASE_PRFL_SEQ_NO 
                           LEFT JOIN PCMP.CASE_PROFILE_CATEGORY_TYPE CPCT 
                                  ON CP.CASE_PRFL_CTG_TYP_CD = CPCT.CASE_PRFL_CTG_TYP_CD where cp.void_ind = 'n'  ) CASEPR ON C.CASE_ID = CASEPR.CASE_ID
LEFT JOIN (  SELECT * FROM 
                           ( SELECT EXAM_SCH_CASE_ID, ADR_CASE_ID, ADR_CASE_NO, ADR_CASE_CREATE_DTM, 
                                    ROW_NUMBER() OVER(PARTITION BY EXAM_SCH_CASE_ID ORDER BY ADR_CASE_CREATE_DTM DESC) RN 
                                           FROM (
                                           SELECT DISTINCT ES.CASE_ID EXAM_SCH_CASE_ID, REL.CASE_RLT_CASE_ID ADR_CASE_ID,
                                           ADR.CASE_NO ADR_CASE_NO, ADR.AUDIT_USER_CREA_DTM ADR_CASE_CREATE_DTM
                                                FROM PCMP.CASES ES
                                         JOIN PCMP.CASE_RELATED REL ON ES.CASE_ID = REL.CASE_ID AND REL.VOID_IND = 'n'
                                         JOIN PCMP.CASES ADR ON REL.CASE_RLT_CASE_ID = ADR.CASE_ID AND ADR.VOID_IND = 'n' 
                             and ADR.CASE_CTG_TYP_CD = 'lgl' and ADR.CASE_TYP_CD = 'othr_lgl' 
                             and ADR.APP_CNTX_TYP_CD = 'claim'
                                  where ES.APP_CNTX_TYP_CD = 'claim' and ES.VOID_IND = 'n' and   ES.CASE_CTG_TYP_CD = 'med'
                                                 and   ES.CASE_TYP_CD = 'exam_schd'
                            ) X
                                  ) Y
                           WHERE RN = 1) ADRCASE ON ADRCASE.EXAM_SCH_CASE_ID = C.CASE_ID
where C.VOID_IND = 'n'
and   C.CASE_CTG_TYP_CD = 'med'
and   C.CASE_TYP_CD = 'exam_schd'
and   C.APP_CNTX_TYP_CD = 'claim'
);

COMMIT;