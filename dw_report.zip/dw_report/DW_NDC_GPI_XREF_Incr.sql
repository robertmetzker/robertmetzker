/* Prod release - September Prod Release date 09/22/2017  */
    
  /* Source Tables 		: PCMP.DRUG_GENERIC_PRODUCT_INDEX
 				  BWCRNP.TEADCVD
				  BWCRNP.TEAMDNV
			 	  BWCRNP.TEAMDPN
				  BWCRNP.TEAMINV
				  BWCRNP.TEAMNMN
				  BWCRNP.TEAMDDI
				  BWCRNP.TEANVMG
				  BWCRNP.TEAMGPC
				  BWCRNP.TEAMNRA
				  BWCRNP.TEAMNDT
			          BWCRNP.TEAMDNO
				  BWCRNP.TEAMNOT
				  BWCRNP.TEAMNDC
				  BWCRNP.TEAMDCT
				  BWCRNP.TEAONPA
			          BWCRNP.TEAOWDA
				  BWCRNP.TEAONLC
				  BWCRNP.TEAMGMD
				  BWCRNP.TEAMPSM	
			  	  BWCRNP.TEAMPDT
			  	  BWCRNP.TEAMDUP           */
								
 
/* L1 Dependency 		: 	NONE */





--\set ON_ERROR_STOP on

CREATE TEMPORARY TABLE DW_NDC_GPI_XREF_TEMP1  AS
SELECT
TRIM(a.FK_NDCL_CODE)                                                                        LBLR_CODE,
TRIM(a.FK_DCPR_CODE)                                                                        PRDCT_CODE,
TRIM(a.FK_NDCP_CODE)                                                                        PCKG_CODE,
TRIM(a.FK_NDCL_CODE)||TRIM(a.FK_DCPR_CODE)||TRIM(a.FK_NDCP_CODE)                          NDC_CMPST_CODE,
TRIM(a.FK_NDCL_CODE)||' '||TRIM(a.FK_DCPR_CODE)||' '||TRIM(a.FK_NDCP_CODE)                NDC_FRMTD_CMPST_CODE,
'03'                                                                                         DRUG_TYPE_CODE,
TRIM(S.DRUG_TYPE_DESC)                                                                      DRUG_TYPE_NAME,
TRIM(C.NAME)                                                                                NDC_PRDCT_NAME,
TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||
TRIM(T.FK_MTDN_CODE)||TRIM(T.FK_MDNE_CODE)||TRIM(T.FK_MDFT_CODE)||TRIM(T.FK_MGGN_CODE)   MDSPN_GPI_CODE,
TRIM(K.DGPI_NM)                                                                             MDSPN_GPI_NAME,
TRIM(T.FK_MTDG_CODE)                                                                        MDSPN_GROUP_CODE,
TRIM(X.DGPI_NM)                                                                             MDSPN_GROUP_NAME,
TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)                                                 MDSPN_CLASS_CODE,
TRIM(Y.DGPI_NM)                                                                             MDSPN_CLASS_NAME,
TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)                          MDSPN_SBCLS_CODE,
TRIM(Z.DGPI_NM)                                                                             MDSPN_SBCLS_NAME,
TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||
TRIM(T.FK_MTDN_CODE)                                                                        MDSPN_DRUG_NAME_CODE,
TRIM(AA.DGPI_NM)                                                                            MDSPN_DRUG_NAME,
TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||
TRIM(T.FK_MTDN_CODE)||TRIM(T.FK_MDNE_CODE)                                                 MDSPN_DRUG_NAME_EXTNS_CODE,
TRIM(AB.DGPI_NM)                                                                            MDSPN_DRUG_NAME_EXTNS_NAME,
TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||
TRIM(T.FK_MTDN_CODE)||TRIM(T.FK_MDNE_CODE)||TRIM(T.FK_MDFT_CODE)                          MDSPN_DRUG_DSG_FORM_CODE,
TRIM(AC.DGPI_NM)                                                                            MDSPN_DRUG_DSG_FORM_NAME,
A.FK_NDCV_NMBR                                                                               NDC_VRSN_NMBR,
B.FK_MDDI_NMBR                                                                               DRUG_DSCRP_ID,
TRIM(G.FK_MGPC_NMBR)                                                                        DRUG_PRDCT_PCKGN_ID,
D.FK_MLBI_NMBR                                                                               NDC_LBLR_ID_NMBR,
TRIM(Q.FK_NDAT_CODE)                                                                        DRUG_ATHRZ_CODE,
TRIM(AD.NDAT_TEXT)                                                                          DRUG_ATHRZ_NAME,                         
LOWER(TRIM(P.IND))                                                                          DRUG_PRIOR_ATHRZ_IND,
TRIM(R.DESCR)                                                                               BWC_DRUG_LMTD_CVRG_DESCR,
TRIM(L.FK_MNOT_CODE)                                                                        DRUG_OTC_CODE,
TRIM(M.NAME)                                                                                DRUG_OTC_NAME,
TRIM(N.FK_MDCT_CODE)                                                                        DEA_CLASS_CODE,
TRIM(O.NAME)                                                                                DEA_CLASS_NAME,
TRIM(F.STRTH_QTY)                                                                           DRUG_STRNG_CODE,
TRIM(F.FK_MNST_CODE)                                                                        DRUG_STR_MSR_CODE,
TRIM(F.FK_MNST_CODE)                                                                        DRUG_STR_MSR_NAME,
TRIM(F.FK_MNRA_CODE)                                                                        DRUG_RT_ADM_CODE,
TRIM(I.NAME)                                                                                DRUG_RT_ADM_NAME,
TRIM(F.FK_MNDT_CODE)                                                                        DRUG_DSG_FORM_CODE,
TRIM(J.NAME)                                                                                DRUG_DSG_FORM_NAME,
TRIM(H.FK_MPSM_CODE)                                                                        NDC_PKG_SIZE_CODE,
TRIM(U.DESCR)                                                                               DRUG_PKG_SIZE_NAME,
TRIM(H.FK_MPDT_CODE)                                                                        DRUG_PKG_TYPE_CODE,
TRIM(V.DESCR)                                                                               DRUG_PKG_TYPE_NAME,
TRIM(H.FK_MDUP_CODE)                                                                        DRUG_PKG_DOSE_CODE,
TRIM(W.DESCR)                                                                               DRUG_PKG_DOSE_NAME,
H.PCKG_SIZE_QTY                                                                              DRUG_PKG_SIZE_QTY,
H.PCKG_QTY                                                                                   DRUG_PKG_QTY,
TRIM(E.NAME)                                                                                DRUG_MNFCT_NAME,
TRIM(E.ABRVD_NAME)                                                                          NDC_MNFCT_ABRVD_NAME,
TRIM(E.LBLR_TYPE_CODE)                                                                      NDC_MNFCT_LBLR_CODE,
CASE WHEN TRIM(E.LBLR_TYPE_CODE) = 'B' THEN 'BRAND'
     WHEN TRIM(E.LBLR_TYPE_CODE) = 'G' THEN 'GENERIC'
     WHEN TRIM(E.LBLR_TYPE_CODE) = 'O' THEN 'EITHER/OR'
END                                                                                          NDC_MNFCT_LBLR_NAME,  
A.BGNG_DATE                                                                                  BGNG_DATE,
A.ENDNG_DATE                                                                                 ENDNG_DATE,
CASE WHEN A.ENDNG_DATE IS NULL OR A.ENDNG_DATE >= CURRENT_DATE THEN 'y' ELSE 'n' END         ACTV_NDC_IND,
CURRENT_DATE                                                                                      DW_CREATE_DTTM,
CURRENT_DATE                                                                                      DW_UPDATE_DTTM,
case
when TRIM(T.FK_MTDG_CODE) = '64' then 'Analgesics'
when TRIM(T.FK_MTDG_CODE) = '57' then 'Anti-Anxiety Agents'
when TRIM(T.FK_MTDG_CODE) = '83' then 'Anticoagulant/Anti-Platelet Agents'
when TRIM(T.FK_MTDG_CODE) = '72' then 'Anticonvulsants'
when TRIM(T.FK_MTDG_CODE) = '58' then 'Antidepressants'
when TRIM(T.FK_MTDG_CODE) = '41' then 'Antihistamines'
when TRIM(T.FK_MTDG_CODE) = '67' then 'Anti-Migraine Agents'
when TRIM(T.FK_MTDG_CODE) = '59' then 'Antipsychotics'
when TRIM(T.FK_MTDG_CODE) = '12' then 'Anti-Viral/Immunosuppressive Agents'
when TRIM(T.FK_MTDG_CODE) = '46' then 'Laxatives'
when TRIM(T.FK_MTDG_CODE) = '75' then 'Muscle Relaxants'
when TRIM(T.FK_MTDG_CODE) = '65' then 'Narcotic Analgesics'
when TRIM(T.FK_MTDG_CODE) = '60' then 'Sedative Hypnotics'
when TRIM(T.FK_MTDG_CODE) = '61' then 'Stimulants'
when TRIM(T.FK_MTDG_CODE) in ('48', '49') then 'Anti-Ulcer Agents'
when TRIM(T.FK_MTDG_CODE) in ('42', '87') then 'Ophthmalmic/Otic/Nasal Agents'
when TRIM(T.FK_MTDG_CODE) in ('90', '92') then 'Topical Agents'
when TRIM(T.FK_MTDG_CODE) in ('77', '78') then 'Vitamins/Minerals'
when TRIM(T.FK_MTDG_CODE) in ('53', '54', '55', '56') then 'Genital-Urinary Agents'
when TRIM(T.FK_MTDG_CODE) in ('22', '23', '24', '25', '26', '27', '28', '29', '30') then 'Steroids/Hormonal Agents'
when TRIM(T.FK_MTDG_CODE) in ('31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '44') then 'Cardio-Pulmonary Agents'
when TRIM(T.FK_MTDG_CODE) in ('01', '02', '03', '04', '05', '07', '08', '09', '11', '13', '14', '15', '16') then 'Antibiotics'
when TRIM(T.FK_MTDG_CODE) in ('17', '18', '19', '20', '21', '43', '47', '50', '51', '52', '62', '68', '69', '70', '73', '74', '76', '80', '81', '84', '88', '93', '94', '95', '96', '97', '98', '99') then 'Miscellaneous'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) = '8515' then 'Anticoagulant/Anti-Platelet Agents'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) = '6699' then 'Narcotic Analgesics'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) = '6610' then 'NSAIDs'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) in ('4500', '4510') then 'Cardio-Pulmonary Agents'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) in ('8910', '8915') then 'Steroids/Hormonal Agents'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) in ('8610', '8620', '8625', '8630', '8633', '8635', '8640', '8650', '8660', '8665', '8670', '8672', '8673', '8675', '8680', '8690') then 'Ophthmalmic/Otic/Nasal Agents'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) in ('7905', '7910', '7920', '7930', '7935', '7940', '7950', '7960', '7970', '7975', '7980', '7985', '7990', '8210', '8220', '8230') then 'Vitamins/Minerals'
when TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) in ('4530', '4550', '4555', '6620', '6625', '6626', '6627', '6628', '6629', '6640', '6645', '6646', '6650', '6660', '6670', '7999', '8240', '8250', '8270', '8280', '8299', '8510', '8520', '8525', '8527', '8530', '8540', '8550', '8555', '8560', '8580', '8582', '8584', '8678', '8920', '8925', '8930', '8940', '8999') then 'Miscellaneous'
end DRUG_GROUP_NAME,
CASE
WHEN TRIM(T.FK_MTDG_CODE) NOT IN ('57', '65') 
     AND TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) <> '6699'         THEN NULL
WHEN TRIM(T.FK_MTDG_CODE) IS NULL               THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% INJ %'          THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% INJ'            THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% IV %'           THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% EPIDURAL %'     THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% IMPLANT %'      THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% POWDER'         THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% PREF SYR%'      THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% KIT%'           THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '%*%'              THEN NULL
WHEN TRIM(AA.DGPI_NM) IN ('BUSPIRONE',
                         'DROPERIDOL',
                         'HALAZEPAM',
                         'HYDROXYZINE',
                         'MEPROBAMATE')     THEN NULL
WHEN TRIM(F.FK_MNST_CODE) = 'MCG/ML-%'         THEN NULL
WHEN TRIM(K.DGPI_NM) = 'METHADONE HCL SOLN 5 MG/5ML'                      THEN 1
WHEN TRIM(K.DGPI_NM) = 'MORPHINE SULFATE ORAL SOLN 100 MG/5ML (20 MG/ML)' THEN 20
WHEN TRIM(K.DGPI_NM) = 'DIAZEPAM ORAL SOLN 1 MG/ML'                       THEN 1
WHEN TRIM(K.DGPI_NM) = 'OXYCODONE HCL SOLN 5 MG/5ML'                      THEN 1
WHEN TRIM(K.DGPI_NM) = 'DIAZEPAM IM SOLUTION AUTO-INJ 10 MG/2ML'          THEN 5
WHEN TRIM(K.DGPI_NM) = 'METHADONE HCL SOLN 10 MG/5ML'                     THEN 2
WHEN TRIM(K.DGPI_NM) = 'MORPHINE SULFATE ORAL SOLN 10 MG/5ML'             THEN 2
WHEN TRIM(K.DGPI_NM) = 'OXYCODONE HCL CONC 100 MG/5ML (20 MG/ML)'         THEN 20
WHEN TRIM(K.DGPI_NM) = 'CODEINE SULFATE ORAL SOLN 30 MG/5ML'              THEN 6
WHEN TRIM(K.DGPI_NM) = 'CODEINE PHOSPHATE SOLN 15 MG/5ML'                 THEN 3
WHEN TRIM(K.DGPI_NM) = 'MORPHINE SULFATE ORAL SOLN 20 MG/5ML'             THEN 4
WHEN TRIM(K.DGPI_NM) = 'MEPERIDINE HCL ORAL SOLN 50 MG/5ML'               THEN 10
WHEN TRIM(F.STRTH_QTY) NOT LIKE '%-%' AND
     TRIM(F.STRTH_QTY) NOT LIKE '%&%' AND
     TRIM(F.STRTH_QTY) NOT LIKE '%X%' AND
     TRIM(F.STRTH_QTY) NOT LIKE '%/%' THEN TRIM(F.STRTH_QTY)::NUMERIC(31,4)
WHEN TRIM(F.STRTH_QTY) = '1200 (600 X 2)' THEN 1200
WHEN TRIM(F.STRTH_QTY) = '1600 (800 X 2)' THEN 1600
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '0.7-0.18'                  THEN 0.7
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '1.4-0.36'                  THEN 1.4
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '2-0.5'                     THEN 2
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '2.1-0.3'                   THEN 2.1
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '2.9-0.71'                  THEN 2.9
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '4-1'                       THEN 4
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '4.2-0.7'                   THEN 4.2
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '5.7-1.4'                   THEN 5.7
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '6.3-1'                     THEN 6.3
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '8-2'                       THEN 8
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '8.6-2.1'                   THEN 8.6
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '11.4-2.9'                  THEN 11.4
WHEN TRIM(AA.DGPI_NM) = 'BUPRENORPHINE'      AND TRIM(F.STRTH_QTY) = '12-3'                      THEN 12
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '% TAB 227-97-32-32-1 MG' THEN 32
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '% CAP 50-200-40-30 MG'   THEN 30
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '% CAP 50-300-40-30 MG'   THEN 30
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '% CAP 50-325-40-30 MG'   THEN 30
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '% 120-12 MG/5ML'         THEN 2.4
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '%-15 MG'                 THEN 15
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '%-30 MG'                 THEN 30
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'        AND TRIM(K.DGPI_NM) LIKE '%-60 MG'                 THEN 60
WHEN TRIM(AA.DGPI_NM) LIKE 'DIHYDROCODEINE%' AND TRIM(K.DGPI_NM) LIKE '%-16 MG'                 THEN 16
WHEN TRIM(AA.DGPI_NM) LIKE 'DIHYDROCODEINE%' AND TRIM(K.DGPI_NM) LIKE '%-32 MG'                 THEN 32
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-200 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-250 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-300 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-325 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-400 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-500 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-650 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-660 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-750 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-200 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-250 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-300 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-325 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-400 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-500 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-650 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-660 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 5-750 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-200 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-250 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-300 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-325 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-400 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-500 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-650 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-660 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-750 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-200 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-250 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-300 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-325 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-400 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-500 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-650 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-660 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-750 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-300 MG/15ML'        THEN 2/3
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-325 MG/15ML'        THEN 2/3
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 10-500 MG/15ML'        THEN 2/3
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-300 MG/15ML'       THEN 0.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-325 MG/15ML'       THEN 0.5
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-500 MG/15ML'       THEN 0.5
WHEN TRIM(AA.DGPI_NM) LIKE 'MEPERIDINE%'     AND TRIM(K.DGPI_NM) LIKE '% 50-25 MG'              THEN 50
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'       AND TRIM(K.DGPI_NM) LIKE '% 20-0.8 MG'             THEN 20
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'       AND TRIM(K.DGPI_NM) LIKE '% 30-1.2 MG'             THEN 30
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'       AND TRIM(K.DGPI_NM) LIKE '% 50-2 MG'               THEN 50
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'       AND TRIM(K.DGPI_NM) LIKE '% 60-2.4 MG'             THEN 60
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'       AND TRIM(K.DGPI_NM) LIKE '% 80-3.2 MG'             THEN 80
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'       AND TRIM(K.DGPI_NM) LIKE '% 100-4 MG'              THEN 100
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 5-325 MG/5ML'          THEN 1
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(F.STRTH_QTY) = '4.8355-325'                THEN 4.8355
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-300 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-325 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-400 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-500 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 2.5-650 MG'            THEN 2.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 5-300 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 5-325 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 5-400 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 5-500 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 5-650 MG'              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-300 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-325 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-400 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-500 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 7.5-650 MG'            THEN 7.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 10-300 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 10-325 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 10-400 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 10-500 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(K.DGPI_NM) LIKE '% 10-650 MG'             THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(F.STRTH_QTY) = '325-2.25-0.19'             THEN 2.25
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(F.STRTH_QTY) = '325-4.5-0.38'              THEN 4.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMB%'    AND TRIM(F.STRTH_QTY) = '4.5-0.38-325'              THEN 4.5
WHEN TRIM(AA.DGPI_NM) LIKE 'PENTAZOCINE%'    AND TRIM(K.DGPI_NM) LIKE '% 12.5-325 MG'           THEN 12.5
WHEN TRIM(AA.DGPI_NM) LIKE 'PENTAZOCINE%'    AND TRIM(K.DGPI_NM) LIKE '% 25-650 MG'             THEN 25
WHEN TRIM(AA.DGPI_NM) LIKE 'PENTAZOCINE%'    AND TRIM(K.DGPI_NM) LIKE '% 50-0.5 MG'             THEN 50
WHEN TRIM(AA.DGPI_NM) LIKE 'PROPOXYPHENE%'   AND TRIM(K.DGPI_NM) LIKE '% 50-325 MG'             THEN 50
WHEN TRIM(AA.DGPI_NM) LIKE 'PROPOXYPHENE%'   AND TRIM(K.DGPI_NM) LIKE '% 65-650 MG'             THEN 65
WHEN TRIM(AA.DGPI_NM) LIKE 'PROPOXYPHENE%'   AND TRIM(K.DGPI_NM) LIKE '% 100-325 MG'            THEN 100
WHEN TRIM(AA.DGPI_NM) LIKE 'PROPOXYPHENE%'   AND TRIM(K.DGPI_NM) LIKE '% 100-500 MG'            THEN 100
WHEN TRIM(AA.DGPI_NM) LIKE 'PROPOXYPHENE%'   AND TRIM(K.DGPI_NM) LIKE '% 100-650 MG'            THEN 100
WHEN TRIM(AA.DGPI_NM) LIKE 'TRAMADOL COMB%'  AND TRIM(K.DGPI_NM) LIKE '% 37.5-325 MG'           THEN 37.5
END  ACTV_DRUG_STRNG_NMBR,
CASE
WHEN TRIM(T.FK_MTDG_CODE) IS NULL                                                      THEN NULL
WHEN TRIM(T.FK_MTDG_CODE) NOT IN ('57', '65') AND TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE) <> '6699'           THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% INJ %'                                                 THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% INJ'                                                   THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% IV %'                                                  THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% EPIDURAL %'                                            THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% IMPLANT %'                                             THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% POWDER'                                                THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% PREF SYR%'                                             THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '% KIT%'                                                  THEN NULL
WHEN TRIM(K.DGPI_NM) LIKE '%*%'                                                     THEN NULL
WHEN TRIM(AA.DGPI_NM) IN ('BUSPIRONE',
                         'DROPERIDOL',
                         'HALAZEPAM',
                         'HYDROXYZINE',
                         'MEPROBAMATE')                                            THEN NULL
WHEN TRIM(AA.DGPI_NM) LIKE 'ALPRAZOLAM%'                                            THEN 10
WHEN TRIM(AA.DGPI_NM) LIKE 'BUPRENORPHINE%' AND TRIM(F.FK_MNST_CODE) = 'MCG/HR'        THEN 12.6
WHEN TRIM(AA.DGPI_NM) LIKE 'BUPRENORPHINE%' AND TRIM(F.FK_MNST_CODE) = 'MCG'           THEN 0.03
WHEN TRIM(AA.DGPI_NM) LIKE 'BUPRENORPHINE%' AND TRIM(F.FK_MNST_CODE) = 'MG'            THEN 30
WHEN TRIM(AA.DGPI_NM) LIKE 'BUTORPHANOL%'                                           THEN 7
WHEN TRIM(AA.DGPI_NM) LIKE 'CHLORDIAZEPOXIDE%'                                      THEN 0.2
WHEN TRIM(AA.DGPI_NM) LIKE 'CLORAZEPATE%'                                           THEN 0.5
WHEN TRIM(AA.DGPI_NM) LIKE 'CODEINE%'                                               THEN 0.15
WHEN TRIM(AA.DGPI_NM) LIKE 'DEZOCINE%'                                              THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'DIAZEPAM%'                                              THEN 1
WHEN TRIM(AA.DGPI_NM) LIKE 'DIHYDROCODEINE%'                                        THEN 0.25
WHEN TRIM(AA.DGPI_NM) LIKE 'FENTANYL%' AND TRIM(F.FK_MNST_CODE) = 'MCG/HR'             THEN 7.2
WHEN TRIM(AA.DGPI_NM) LIKE 'FENTANYL%' AND TRIM(K.DGPI_NM) LIKE '%NASAL SPRAY%'      THEN 0.16
WHEN TRIM(AA.DGPI_NM) LIKE 'FENTANYL%' AND TRIM(K.DGPI_NM) LIKE '%SUBLINGUAL SPRAY%' THEN 0.18
WHEN TRIM(AA.DGPI_NM) LIKE 'FENTANYL%' AND TRIM(K.DGPI_NM) LIKE '%SOLUBLE FILM%'     THEN 0.18
WHEN TRIM(AA.DGPI_NM) LIKE 'FENTANYL%'                                              THEN 0.13
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROCODONE%'                                           THEN 1
WHEN TRIM(AA.DGPI_NM) LIKE 'HYDROMORPHONE%'                                         THEN 4
WHEN TRIM(AA.DGPI_NM) LIKE 'LEVOMETHADYL%'                                          THEN 8
WHEN TRIM(AA.DGPI_NM) LIKE 'LEVORPHANOL%'                                           THEN 11
WHEN TRIM(AA.DGPI_NM) LIKE 'LORAZEPAM%'                                             THEN 5
WHEN TRIM(AA.DGPI_NM) LIKE 'MEPERIDINE%'                                            THEN 0.1
WHEN TRIM(AA.DGPI_NM) LIKE 'METHADONE%'                                             THEN 3
WHEN TRIM(AA.DGPI_NM) LIKE 'MORPHINE%'                                              THEN 1
WHEN TRIM(AA.DGPI_NM) LIKE 'NALBUPHINE%'                                            THEN 1
WHEN TRIM(AA.DGPI_NM) LIKE 'OPIOID COMBINATION - TWO INGREDIENT%'                   THEN 1.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OXAZEPAM%'                                              THEN 0.17
WHEN TRIM(AA.DGPI_NM) LIKE 'OXYCODONE%'                                             THEN 1.5
WHEN TRIM(AA.DGPI_NM) LIKE 'OXYMORPHONE%'                                           THEN 3
WHEN TRIM(AA.DGPI_NM) LIKE 'PENTAZOCINE%'                                           THEN 0.37
WHEN TRIM(AA.DGPI_NM) LIKE 'PROPOXYPHENE%'                                          THEN 0.23
WHEN TRIM(AA.DGPI_NM) LIKE 'TAPENTADOL%'                                            THEN 0.4
WHEN TRIM(AA.DGPI_NM) LIKE 'TRAMADOL%'                                              THEN 0.1
END CNVRS_FCTR_NMBR
FROM
(
  SELECT TRIM(FK_NDCL_CODE) FK_NDCL_CODE, TRIM(FK_DCPR_CODE) FK_DCPR_CODE, TRIM(FK_NDCP_CODE) FK_NDCP_CODE, FK_NDCV_NMBR, BGNG_DATE, ENDNG_DATE, DCVD_CRT_DTTM, DCTVT_DTTM
  FROM BWCRNP.TEADCVD 
  WHERE (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), BGNG_DATE) in
      (SELECT TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), max(BGNG_DATE) BGNG_DATE
       FROM BWCRNP.TEADCVD
       WHERE BGNG_DATE  <= CURRENT_DATE
       AND DCVD_CRT_DTTM <= CURRENT_TIMESTAMP
       AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
       GROUP BY TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE)
      )
) A
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMDNV
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND MDNV_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMDNV
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND MDNV_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) B
ON TRIM(a.FK_NDCL_CODE)  = TRIM(B.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(B.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(B.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = B.FK_NDCV_NMBR
/* MEDISPAN DRUG DESCRIPTOR IDENTIFIER NATIONAL DRUG CODE VERSION describes the valid combination of MEDISPAN DRUG DESCRIPTOR IDENTIFIER and NATIONAL DRUG CODE VERSION. */
LEFT JOIN
  (SELECT *
  FROM bwcrnp.TEAMDPN
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND MDPN_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (FK_MDDI_NMBR, ENDNG_DATE) IN
    (SELECT FK_MDDI_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMDPN
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND MDPN_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY FK_MDDI_NMBR
    )
  ) C
ON B.FK_MDDI_NMBR = C.FK_MDDI_NMBR
/* MEDISPAN PRODUCT NAME describes the product name shown by the manufacturer on the package.*/
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMINV
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND MINV_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMINV
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND MINV_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) D
ON TRIM(a.FK_NDCL_CODE)  = TRIM(D.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(D.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(D.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = D.FK_NDCV_NMBR
/* MEDISPAN IDENTIFIER NATIONAL DRUG CODE VERSION describes the valid combination of MEDISPAN LABELIER IDENTIFIER and NATIONAL DRUG CODE VERSION.*/
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMNMN
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND MNMN_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (FK_MLBI_NMBR, ENDNG_DATE) IN
    (SELECT FK_MLBI_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMNMN
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND MNMN_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY FK_MLBI_NMBR
    )
  ) E
ON D.FK_MLBI_NMBR = E.FK_MLBI_NMBR
/* MEDISPAN MANUFACTURER NAME describes the manufacturer, distributor and or division whose name is included on the label.*/
LEFT JOIN BWCRNP.TEAMDDI F
ON B.FK_MDDI_NMBR = F.MDDI_NMBR
/* MEDISPAN DRUG DESCRIPTOR IDENTIFIER describes a unique combination of 
   MEDISPAN DOSAGE FORM TYPE, MEDISPAN STRENGTH UNIT OF MEASURE TYPE, MEDISPAN ROUTE OF ADMINISTRATION and MEDISPAN PRODUCT NAME. */
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEANVMG
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND NVMG_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEANVMG
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND NVMG_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) G
ON TRIM(a.FK_NDCL_CODE)  = TRIM(G.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(G.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(G.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = G.FK_NDCV_NMBR
LEFT JOIN BWCRNP.TEAMGPC H
ON TRIM(G.FK_MGPC_NMBR) = TRIM(H.MGPC_NMBR)
/* MEDISPAN GENERIC PRODUCT PACKAGING CODE describes a drug product and its packaging. */
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMNRA
  WHERE EFCTV_DATE <= CURRENT_DATE
  AND CRT_DTTM     <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM   >= CURRENT_TIMESTAMP
  AND (TRIM(MNRA_CODE), ENDNG_DATE) IN
    (SELECT TRIM(MNRA_CODE),
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMNRA
    WHERE EFCTV_DATE <= CURRENT_DATE
    AND CRT_DTTM     <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM   >= CURRENT_TIMESTAMP
    GROUP BY TRIM(mnra_code)
    )
  ) I
ON TRIM(F.FK_MNRA_CODE) = TRIM(I.MNRA_CODE)
/* MEDISPAN NATIONAL DRUG CODE ROUTE OF ADMINISTRATION TYPE describes how the NATIONAL DRUG CODE dosage form is administered to the patient.*/
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMNDT
  WHERE EFCTV_DATE <= CURRENT_DATE
  AND CRT_DTTM     <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM   >= CURRENT_TIMESTAMP
  AND (TRIM(mndt_code), ENDNG_DATE) IN
    (SELECT TRIM(mndt_code),
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMNDT
    WHERE EFCTV_DATE <= CURRENT_DATE
    AND CRT_DTTM     <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM   >= CURRENT_TIMESTAMP
    GROUP BY TRIM(MNDT_CODE)
    )
  ) J
ON TRIM(F.FK_MNDT_CODE) = TRIM(J.MNDT_CODE)
/* MEDISPAN NATIONAL DRUG CODE DOSAGE FORM TYPE describes form the NATIONAL DRUG CODE is dispensed.*/
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMDNO
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND MDNO_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMDNO
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND MDNO_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) L
ON TRIM(a.FK_NDCL_CODE)  = TRIM(L.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(L.FK_DCPR_CODE)
AND A.FK_NDCV_NMBR = L.FK_NDCV_NMBR
AND TRIM(a.FK_NDCP_CODE) = TRIM(L.FK_NDCP_CODE)
/* MEDISPAN NATIONAL DRUG CODE OTC describes the valid combination of MEDISPAN OTC TYPE and NATIONAL DRUG CODE VERSION.*/
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAMNOT
  WHERE CRT_DTTM <= CURRENT_TIMESTAMP
  AND EFCTV_DATE <= CURRENT_DATE
  AND DCTVT_DTTM >= CURRENT_TIMESTAMP
  AND (TRIM(MNOT_CODE), ENDNG_DATE) IN
    (SELECT TRIM(MNOT_CODE),
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMNOT
    WHERE CRT_DTTM <= CURRENT_TIMESTAMP
    AND EFCTV_DATE <= CURRENT_DATE
    AND DCTVT_DTTM >= CURRENT_TIMESTAMP
    GROUP BY TRIM(MNOT_CODE)
    )
  ) M
ON TRIM(L.FK_MNOT_CODE) = TRIM(M.MNOT_CODE)
/* MEDISPAN NATIONAL DRUG CODE PERSCRIPTION OVER THE COUNTER TYPE describes if an NATIONAL DRUG CODE requires a perscription.*/
LEFT JOIN
  (SELECT case when FK_MDCT_CODE = ' ' then '-1' else FK_MDCT_CODE end FK_FK_MDCT_CODE , *
  FROM BWCRNP.TEAMNDC
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND MNDC_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMNDC
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND MNDC_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) N
ON TRIM(a.FK_NDCL_CODE)  = TRIM(N.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(N.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(N.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = N.FK_NDCV_NMBR
/* MEDISPAN NATIONAL DRUG CODE DEA CLASS describes the valid combination of MEDISPAN DEA CLASS TYPE and NADTIONAL DRUG CODE VERSION.*/
LEFT JOIN
  (SELECT case when MDCT_CODE = ' ' then '-1' else MDCT_CODE end FK_MDCT_CODE, NAME
  FROM BWCRNP.TEAMDCT
  WHERE EFCTV_DATE <= CURRENT_DATE
  AND CRT_DTTM     <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM   >= CURRENT_TIMESTAMP
  AND (MDCT_CODE, ENDNG_DATE) IN
    (SELECT MDCT_CODE,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAMDCT
    WHERE EFCTV_DATE <= CURRENT_DATE
    AND CRT_DTTM     <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM   >= CURRENT_TIMESTAMP
    GROUP BY MDCT_CODE
    )
  ) O
ON TRIM(N.FK_FK_MDCT_CODE) = O.FK_MDCT_CODE
/* MEDISPAN DRUG ENFORCEMENT ADMINISTRATION CLASS describes federally controlled substances classified by the DEA. */
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAONPA
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND ONPA_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAONPA
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND ONPA_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) P
ON TRIM(a.FK_NDCL_CODE)  = TRIM(P.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(P.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(P.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = P.FK_NDCV_NMBR
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAOWDA
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND OWDA_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAOWDA
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND OWDA_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) Q
ON TRIM(a.FK_NDCL_CODE)  = TRIM(Q.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(Q.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(Q.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = Q.FK_NDCV_NMBR
LEFT JOIN
  (SELECT *
  FROM BWCRNP.TEAONLC
  WHERE EFCTV_DATE  <= CURRENT_DATE
  AND ONLC_CRT_DTTM <= CURRENT_TIMESTAMP
  AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
  AND (TRIM(FK_NDCL_CODE), TRIM(FK_DCPR_CODE), TRIM(FK_NDCP_CODE), FK_NDCV_NMBR, ENDNG_DATE) IN
    (SELECT TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR,
      MAX(ENDNG_DATE) ENDNG_DATE
    FROM BWCRNP.TEAONLC
    WHERE EFCTV_DATE  <= CURRENT_DATE
    AND ONLC_CRT_DTTM <= CURRENT_TIMESTAMP
    AND DCTVT_DTTM    >= CURRENT_TIMESTAMP
    GROUP BY TRIM(FK_NDCL_CODE),
      TRIM(FK_DCPR_CODE),
      TRIM(FK_NDCP_CODE),
      FK_NDCV_NMBR
    )
  ) R
ON TRIM(a.FK_NDCL_CODE)  = TRIM(R.FK_NDCL_CODE)
AND TRIM(a.FK_DCPR_CODE) = TRIM(R.FK_DCPR_CODE)
AND TRIM(a.FK_NDCP_CODE) = TRIM(R.FK_NDCP_CODE)
AND A.FK_NDCV_NMBR = R.FK_NDCV_NMBR
LEFT JOIN BWCODS.TCDDRTY S
ON TRIM(S.DRUG_TYPE_CODE)  = '03'
LEFT JOIN
  (SELECT * 
  FROM BWCRNP.TEAMGMD
  WHERE MGMD_CRT_DTTM <= CURRENT_TIMESTAMP 
  AND EFCTV_DATE      <= CURRENT_DATE 
  AND DCTVT_DTTM      >= CURRENT_DATE
  AND (FK_MDDI_NMBR, ENDNG_DATE) IN
    (SELECT FK_MDDI_NMBR, 
      MAX(ENDNG_DATE) ENDNG_DATE 
    FROM BWCRNP.TEAMGMD
    WHERE MGMD_CRT_DTTM <= CURRENT_TIMESTAMP 
    AND EFCTV_DATE      <= CURRENT_DATE 
    AND DCTVT_DTTM      >= CURRENT_DATE
    GROUP BY FK_MDDI_NMBR
    )
  ) T 
ON B.FK_MDDI_NMBR = T.FK_MDDI_NMBR
/* : MEDISPAN GPI GENERIC NAME MEDISPAN DRUG DESCRIPTOR IDENTIFIER describes the valid combination of MEDISPAN GPI GENERIC NAME and MEDISPAN DRUG DESCRIPTOR IDENTIFIER*/
LEFT JOIN 
  (SELECT * 
  FROM BWCRNP.TEAMPSM
  WHERE CRT_DTTM <= CURRENT_TIMESTAMP 
  AND EFCTV_DATE <= CURRENT_DATE 
  AND DCTVT_DTTM >= CURRENT_DATE
  AND (TRIM(MPSM_CODE), ENDNG_DATE) IN
    (SELECT TRIM(MPSM_CODE), 
      MAX(ENDNG_DATE) ENDNG_DATE 
    FROM BWCRNP.TEAMPSM
    WHERE CRT_DTTM <= CURRENT_TIMESTAMP 
    AND EFCTV_DATE <= CURRENT_DATE 
    AND DCTVT_DTTM >= CURRENT_DATE
    GROUP BY TRIM(MPSM_CODE)
    )
  ) U
ON TRIM(H.FK_MPSM_CODE) = TRIM(U.MPSM_CODE)
/* MEDISPAN PACKAGE SIZE UNIT OF MEASURE describes the unit of measure for the package size of the soilid, liquid or gas as dispensed. */
LEFT JOIN 
  (SELECT * 
  FROM BWCRNP.TEAMPDT
  WHERE CRT_DTTM <= CURRENT_TIMESTAMP 
  AND EFCTV_DATE <= CURRENT_DATE 
  AND DCTVT_DTTM >= CURRENT_DATE
  AND (TRIM(MPDT_CODE), ENDNG_DATE) IN
    (SELECT TRIM(MPDT_CODE), 
      MAX(ENDNG_DATE) ENDNG_DATE 
    FROM BWCRNP.TEAMPDT
    WHERE CRT_DTTM <= CURRENT_TIMESTAMP 
    AND EFCTV_DATE <= CURRENT_DATE 
    AND DCTVT_DTTM >= CURRENT_DATE
    GROUP BY TRIM(MPDT_CODE)
    )
  ) V
ON TRIM(H.FK_MPDT_CODE) = TRIM(V.MPDT_CODE)
/* MEDISPAN PACKAGE DESCRIPTION TYPE describes the container or package used for the drug products.*/
LEFT JOIN 
  (SELECT case when MDUP_CODE = ' ' then '-1' else MDUP_CODE end FK_MDUP_CODE, * 
  FROM BWCRNP.TEAMDUP
  WHERE CRT_DTTM <= CURRENT_TIMESTAMP 
  AND EFCTV_DATE <= CURRENT_DATE 
  AND DCTVT_DTTM >= CURRENT_DATE
  AND (TRIM(MDUP_CODE), ENDNG_DATE) IN
    (SELECT TRIM(MDUP_CODE), 
      MAX(ENDNG_DATE) ENDNG_DATE 
    FROM BWCRNP.TEAMDUP
    WHERE CRT_DTTM <= CURRENT_TIMESTAMP 
    AND EFCTV_DATE <= CURRENT_DATE 
    AND DCTVT_DTTM >= CURRENT_DATE
    GROUP BY TRIM(MDUP_CODE)
    )
  ) W
ON nvl(TRIM(H.FK_MDUP_CODE), '-1') = TRIM(W.FK_MDUP_CODE)
/* MEDISPAN UNIT DOSE UNIT OF USE PACKAGE CODE describes drug products which are packaged as unit dose or unit of use. */
LEFT JOIN BWCODS.TCDNDAT AD ON TRIM(Q.FK_NDAT_CODE) = TRIM(AD.NDAT_CODE)
/* DRUG COVERAGE TYPE CODE TABLE.  Valid values for whether or not a NATIONAL DRUG CODE item is covered by OHIO WORKERS' COMPENSATION.*/
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) K ON (TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||TRIM(T.FK_MTDN_CODE)||TRIM(T.FK_MDNE_CODE)||TRIM(T.FK_MDFT_CODE)||TRIM(T.FK_MGGN_CODE)) = TRIM(K.DGPI_CD)
/* Generic Product Index values for Generic Product Index code */
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) X 
ON TRIM(T.FK_MTDG_CODE) = TRIM(X.DGPI_CD)
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) Y 
ON (TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)) = TRIM(Y.DGPI_CD)  
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) Z ON (TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)) = TRIM(Z.DGPI_CD)
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) AA ON (TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||TRIM(T.FK_MTDN_CODE)) = TRIM(AA.DGPI_CD)
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) AB ON (TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||TRIM(T.FK_MTDN_CODE)||TRIM(T.FK_MDNE_CODE)) = TRIM(AB.DGPI_CD)
LEFT JOIN 
  (SELECT * 
  FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX
  WHERE VOID_IND = 'n' 
  AND (TRIM(DGPI_CD), DGPI_EFF_DT) IN
    (SELECT TRIM(DGPI_CD), 
      MAX(DGPI_EFF_DT) DGPI_EFF_DT 
    FROM PCMP.DRUG_GENERIC_PRODUCT_INDEX 
    WHERE VOID_IND = 'n'
    GROUP BY TRIM(DGPI_CD)
    )
  ) AC ON (TRIM(T.FK_MTDG_CODE)||TRIM(T.FK_MTDC_CODE)||TRIM(T.FK_MTDS_CODE)||TRIM(T.FK_MTDN_CODE)||TRIM(T.FK_MDNE_CODE)||TRIM(T.FK_MDFT_CODE)) = TRIM(AC.DGPI_CD)
WHERE A.BGNG_DATE   <= CURRENT_DATE
AND A.DCVD_CRT_DTTM <= CURRENT_TIMESTAMP
AND A.DCTVT_DTTM    >= CURRENT_TIMESTAMP
;

CREATE TEMPORARY TABLE DW_NDC_GPI_XREF_TEMP2  AS
SELECT *, (ACTV_DRUG_STRNG_NMBR * CNVRS_FCTR_NMBR) MLGRM_EQVLN_NMBR FROM DW_NDC_GPI_XREF_TEMP1;


TRUNCATE TABLE DW_REPORT.DW_NDC_GPI_XREF;

INSERT INTO DW_REPORT.DW_NDC_GPI_XREF
(LBLR_CODE, PRDCT_CODE, PCKG_CODE, NDC_CMPST_CODE, NDC_FRMTD_CMPST_CODE, DRUG_TYPE_CODE, DRUG_TYPE_NAME, NDC_PRDCT_NAME, MDSPN_GPI_CODE, MDSPN_GPI_NAME, MDSPN_GROUP_CODE, MDSPN_GROUP_NAME, MDSPN_CLASS_CODE, MDSPN_CLASS_NAME, MDSPN_SBCLS_CODE, MDSPN_SBCLS_NAME, MDSPN_DRUG_NAME_CODE, MDSPN_DRUG_NAME, MDSPN_DRUG_NAME_EXTNS_CODE, MDSPN_DRUG_NAME_EXTNS_NAME, MDSPN_DRUG_DSG_FORM_CODE, MDSPN_DRUG_DSG_FORM_NAME, NDC_VRSN_NMBR, DRUG_DSCRP_ID, DRUG_PRDCT_PCKGN_ID, NDC_LBLR_ID_NMBR, DRUG_ATHRZ_CODE, DRUG_ATHRZ_NAME, DRUG_PRIOR_ATHRZ_IND, BWC_DRUG_LMTD_CVRG_DESCR, DRUG_OTC_CODE, DRUG_OTC_NAME, DEA_CLASS_CODE, DEA_CLASS_NAME, DRUG_STRNG_CODE, DRUG_STR_MSR_CODE, DRUG_STR_MSR_NAME, DRUG_RT_ADM_CODE, DRUG_RT_ADM_NAME, DRUG_DSG_FORM_CODE, DRUG_DSG_FORM_NAME, NDC_PKG_SIZE_CODE, DRUG_PKG_SIZE_NAME, DRUG_PKG_TYPE_CODE, DRUG_PKG_TYPE_NAME, DRUG_PKG_DOSE_CODE, DRUG_PKG_DOSE_NAME, DRUG_PKG_SIZE_QTY, DRUG_PKG_QTY, DRUG_MNFCT_NAME, NDC_MNFCT_ABRVD_NAME, NDC_MNFCT_LBLR_CODE, NDC_MNFCT_LBLR_NAME, BGNG_DATE, ENDNG_DATE, ACTV_NDC_IND, DW_CREATE_DTTM, DW_UPDATE_DTTM, DRUG_GROUP_NAME, ACTV_DRUG_STRNG_NMBR, CNVRS_FCTR_NMBR, MLGRM_EQVLN_NMBR)
SELECT * FROM DW_NDC_GPI_XREF_TEMP2;

COMMIT;


