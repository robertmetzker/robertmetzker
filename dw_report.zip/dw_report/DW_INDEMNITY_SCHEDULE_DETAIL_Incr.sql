--\set ON_ERROR_STOP on
-- This scripts builds both DW_INDEMNITY_SCHEDULE_DTL AND DW_INDEMNITY_SCHEDULE_DETAIL tables. 
-- The table DW_INDEMNITY_SCHEDULE_DETAIL has build by joining the DW_INDEMNITY_SCHEDULE_AMOUNT_DETAIL.  Hence it has duplicates.
-- The table DW_INDEMNITY_SCHEDULE_DTL is build without joining.
TRUNCATE TABLE DW_REPORT.DW_INDEMNITY_SCHEDULE_DETAIL;
INSERT
     /*+DIRECT*/
     INTO
         DW_REPORT.DW_INDEMNITY_SCHEDULE_DETAIL(
             INDM_SCH_ID,
             INDM_SCH_DTL_PRCS_DT,
             INDM_SCH_DLVR_DT,
             INDM_SCH_DTL_DRV_EFF_DT,
             INDM_SCH_DTL_DRV_END_DT,
             INDM_SCH_DTL_DRV_DD,
             INDM_SCH_DTL_DRV_AMT,
             ISD_INDM_SCH_DTL_STS_TYP_CD,
             ISD_INDM_SCH_DTL_STS_TYP_NM,
             INDM_SCH_DTL_OFST_AMT,
             INDM_SCH_DTL_LMP_RED_AMT,
             INDM_SCH_DTL_OTHR_RED_AMT,
             INDM_SCH_DTL_DRV_NET_AMT,
             INDM_SCH_DTL_FNL_PAY_IND,
             LTE_PAY_RSN_TYP_CD,
             INDM_SCH_DET_VOID_IND,
             INDM_SCH_DET_AMT_VOID_IND,
             CUST_ID,
             CFT_ID,
             CLM_ADJ_ID,
             INDM_SCH_DTL_AMT_TYP_CD,
             INDM_SCH_DTL_AMT_TYP_NM,
             INDM_SCH_DTL_AMT_AMT,
             INDM_SCH_DTL_AMT_CHK_GRP_NO,
             INDM_SCH_DTL_AMT_PRI_IND,
             INDM_SCH_DTL_AMT_MAILTO_IND,
             INDM_SCH_DTL_AMT_RMND_IND,
             CUST_CHLD_SUPT_ID,
             ISDA_INDM_SCH_DTL_STS_TYP_CD,
             ISDA_INDM_SCH_DTL_STS_TYP_NM,
             INDM_SCH_DTL_MSG_TYP_CD,
             INDM_SCH_DTL_MSG_TYP_NM,
             INDM_SCH_DTL_MSG_TYP_DESC,
             ISD_AUDIT_USER_ID_CREA,
             ISD_AUDIT_USER_CREA_DTM,
             ISD_AUDIT_USER_ID_UPDT,
             ISD_AUDIT_USER_UPDT_DTM,
             INDM_SCH_DTL_ID,
             DW_CREATE_DTTM,
             DW_UPDATE_DTTM,
             CLAIM_AUTH_USER_ID
         )(
             SELECT /*+ SYNTACTIC_JOIN,LABEL(L1_INDM_SCH_proj)*/
                 INDM_SCH_ID,
                 INDM_SCH_DTL_PRCS_DT,
                 INDM_SCH_DLVR_DT,
                 INDM_SCH_DTL_DRV_EFF_DT,
                 INDM_SCH_DTL_DRV_END_DT,
                 INDM_SCH_DTL_DRV_DD,
                 INDM_SCH_DTL_DRV_AMT,
                 ISD_INDM_SCH_DTL_STS_TYP_CD,
                 ISD_INDM_SCH_DTL_STS_TYP_NM,
                 INDM_SCH_DTL_OFST_AMT,
                 INDM_SCH_DTL_LMP_RED_AMT,
                 INDM_SCH_DTL_OTHR_RED_AMT,
                 INDM_SCH_DTL_DRV_NET_AMT,
                 INDM_SCH_DTL_FNL_PAY_IND,
                 CASE
                     WHEN LTE_PAY_RSN_TYP_CD IS NULL
                     THEN '-1'
                     ELSE LTE_PAY_RSN_TYP_CD
                 END LTE_PAY_RSN_TYP_CD,
                 INDM_SCH_DET_VOID_IND,
                 INDM_SCH_DET_AMT_VOID_IND,
                 CUST_ID,
                 CFT_ID,
                 CLM_ADJ_ID,
                 CASE
                     WHEN INDM_SCH_DTL_AMT_TYP_CD IS NULL
                     THEN '-1'
                     ELSE INDM_SCH_DTL_AMT_TYP_CD
                 END INDM_SCH_DTL_AMT_TYP_CD,
                 INDM_SCH_DTL_AMT_TYP_NM,
                 INDM_SCH_DTL_AMT_AMT,
                 INDM_SCH_DTL_AMT_CHK_GRP_NO,
                 INDM_SCH_DTL_AMT_PRI_IND,
                 INDM_SCH_DTL_AMT_MAILTO_IND,
                 INDM_SCH_DTL_AMT_RMND_IND,
                 CUST_CHLD_SUPT_ID,
                 CASE
                     WHEN ISDA_INDM_SCH_DTL_STS_TYP_CD IS NULL
                     THEN '-1'
                     ELSE ISDA_INDM_SCH_DTL_STS_TYP_CD
                 END ISDA_INDM_SCH_DTL_STS_TYP_CD,
                 ISDA_INDM_SCH_DTL_STS_TYP_NM,
                 CASE
                     WHEN INDM_SCH_DTL_MSG_TYP_CD IS NULL
                     THEN '-1'
                     ELSE INDM_SCH_DTL_MSG_TYP_CD
                 END INDM_SCH_DTL_MSG_TYP_CD,
                 INDM_SCH_DTL_MSG_TYP_NM,
                 INDM_SCH_DTL_MSG_TYP_DESC,
                 ISD_AUDIT_USER_ID_CREA,
                 ISD_AUDIT_USER_CREA_DTM,
                 ISD_AUDIT_USER_ID_UPDT,
                 ISD_AUDIT_USER_UPDT_DTM,
                 INDM_SCH_DTL_ID,
                 CURRENT_DATE AS DW_CREATE_DTTM,
                 CURRENT_DATE AS DW_UPDATE_DTTM,
                 CLAIM_AUTH_USER_ID
             FROM
                 (
                     SELECT 
                         DISTINCT ISD.INDM_SCH_ID,
                         ISD.INDM_SCH_DTL_PRCS_DT,
                         ISD.INDM_SCH_DLVR_DT,
                         ISD.INDM_SCH_DTL_DRV_EFF_DT,
                         ISD.INDM_SCH_DTL_DRV_END_DT,
                         ISD.INDM_SCH_DTL_DRV_DD,
                         ISD.INDM_SCH_DTL_DRV_AMT,
                         ISD.INDM_SCH_DTL_STS_TYP_CD AS ISD_INDM_SCH_DTL_STS_TYP_CD,
                         ISDST.INDM_SCH_DTL_STS_TYP_NM AS ISD_INDM_SCH_DTL_STS_TYP_NM,
                         ISD.INDM_SCH_DTL_OFST_AMT,
                         ISD.INDM_SCH_DTL_LMP_RED_AMT,
                         ISD.INDM_SCH_DTL_OTHR_RED_AMT,
                         ISD.INDM_SCH_DTL_DRV_NET_AMT,
                         ISD.INDM_SCH_DTL_FNL_PAY_IND,
                         ISD.LTE_PAY_RSN_TYP_CD,
                         ISD.VOID_IND AS INDM_SCH_DET_VOID_IND,
                         ISDA.VOID_IND AS INDM_SCH_DET_AMT_VOID_IND,
                         ISDA.CUST_ID,
                         ISDA.CFT_ID,
                         ISDA.CLM_ADJ_ID,
                         ISDA.INDM_SCH_DTL_AMT_TYP_CD,
                         ISDAT.INDM_SCH_DTL_AMT_TYP_NM,
                         ISDA.INDM_SCH_DTL_AMT_AMT,
                         ISDA.INDM_SCH_DTL_AMT_CHK_GRP_NO,
                         ISDA.INDM_SCH_DTL_AMT_PRI_IND,
                         ISDA.INDM_SCH_DTL_AMT_MAILTO_IND,
                         ISDA.INDM_SCH_DTL_AMT_RMND_IND,
                         ISDCS.CUST_CHLD_SUPT_ID,
                         ISDA.INDM_SCH_DTL_STS_TYP_CD AS ISDA_INDM_SCH_DTL_STS_TYP_CD,
                         ISDST2.INDM_SCH_DTL_STS_TYP_NM AS ISDA_INDM_SCH_DTL_STS_TYP_NM,
                         ISDMT.INDM_SCH_DTL_MSG_TYP_CD,
                         ISDMT.INDM_SCH_DTL_MSG_TYP_NM,
                         ISDMT.INDM_SCH_DTL_MSG_TYP_DESC,
                         ISD.AUDIT_USER_ID_CREA AS ISD_AUDIT_USER_ID_CREA,
                         ISD.AUDIT_USER_CREA_DTM AS ISD_AUDIT_USER_CREA_DTM,
                         ISD.AUDIT_USER_ID_UPDT AS ISD_AUDIT_USER_ID_UPDT,
                         ISD.AUDIT_USER_UPDT_DTM AS ISD_AUDIT_USER_UPDT_DTM,
                         ISD.INDM_SCH_DTL_ID,
                         HIST.CLAIM_AUTH_USER_ID
                     FROM
                         PCMP.INDEMNITY_SCHEDULE_DETAIL ISD /*+projs('PCMP.BWC_INDEMNITY_SCHEDULE_DETAIL_V1_01')*/  LEFT OUTER JOIN /* +JTYPE(FM)*/  PCMP.INDEMNITY_SCHEDULE_DTL_AMT ISDA /*+projs('PCMP.BWC_INDEMNITY_SCHEDULE_DTL_AMT_V1_01 ')*/
                             ON ISDA.INDM_SCH_DTL_ID = ISD.INDM_SCH_DTL_ID LEFT OUTER JOIN PCMP.INDEMNITY_SCH_DTL_STS_TYP ISDST
                             ON ISD.INDM_SCH_DTL_STS_TYP_CD = ISDST.INDM_SCH_DTL_STS_TYP_CD LEFT OUTER JOIN PCMP.INDEMNITY_SCHEDULE_DTL_AMT_TYP ISDAT
                             ON ISDAT.INDM_SCH_DTL_AMT_TYP_CD = ISDA.INDM_SCH_DTL_AMT_TYP_CD LEFT OUTER JOIN PCMP.INDEMNITY_SCHEDULE_DETAIL_MSG ICDM
                             ON ISD.INDM_SCH_DTL_ID = ICDM.INDM_SCH_DTL_ID AND ICDM.VOID_IND = 'n' LEFT OUTER JOIN PCMP.INDEMNITY_SCHEDULE_DTL_MSG_TYP ISDMT
                             ON ISDMT.INDM_SCH_DTL_MSG_TYP_CD = ICDM.INDM_SCH_DTL_MSG_TYP_CD LEFT OUTER JOIN PCMP.INDEMNITY_SCH_DTL_STS_TYP ISDST2
                             ON ISDA.INDM_SCH_DTL_STS_TYP_CD = ISDST2.INDM_SCH_DTL_STS_TYP_CD LEFT OUTER JOIN PCMP.INDM_SCH_DTL_CHLD_SUPT ISDCS
                             ON ISDCS.INDM_SCH_DTL_AMT_ID = ISDA.INDM_SCH_DTL_AMT_ID LEFT OUTER JOIN 
							 (SELECT INDM_SCH_DTL_ID,
								COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) CLAIM_AUTH_USER_ID,  
								ROW_NUMBER() OVER ( PARTITION BY INDM_SCH_DTL_ID ORDER BY INDM_SCH_DTL_STS_TYP_CD DESC, HIST_EFF_DTM DESC) ROWNUM
								FROM PCMP.INDEMNITY_SCHEDULE_DETAIL_HIST 
								WHERE INDM_SCH_DTL_STS_TYP_CD IN ('rel', 'paid') 
								AND   VOID_IND = 'n') HIST           
                                                       ON ISD.INDM_SCH_DTL_ID =HIST.INDM_SCH_DTL_ID AND HIST.ROWNUM = 1) A
         );COMMIT;
		 
TRUNCATE TABLE DW_REPORT.DW_INDEMNITY_SCHEDULE_DTL;
INSERT  /*+DIRECT*/ INTO DW_REPORT.DW_INDEMNITY_SCHEDULE_DTL
 ( INDM_SCH_ID,
     INDM_SCH_DTL_PRCS_DT ,
     INDM_SCH_DLVR_DT ,
     INDM_SCH_DTL_DRV_EFF_DT ,
     INDM_SCH_DTL_DRV_END_DT ,
     INDM_SCH_DTL_DRV_DD ,
     INDM_SCH_DTL_DRV_AMT ,
     ISD_INDM_SCH_DTL_STS_TYP_CD ,
     ISD_INDM_SCH_DTL_STS_TYP_NM ,
     INDM_SCH_DTL_OFST_AMT ,
     INDM_SCH_DTL_LMP_RED_AMT ,
     INDM_SCH_DTL_OTHR_RED_AMT ,
     INDM_SCH_DTL_DRV_NET_AMT ,
     INDM_SCH_DTL_FNL_PAY_IND ,
     LTE_PAY_RSN_TYP_CD ,
     INDM_SCH_DET_VOID_IND ,
     INDM_SCH_DTL_MSG_TYP_CD ,
     INDM_SCH_DTL_MSG_TYP_NM ,
     INDM_SCH_DTL_MSG_TYP_DESC ,
     ISD_AUDIT_USER_ID_CREA ,
     ISD_AUDIT_USER_CREA_DTM ,
     ISD_AUDIT_USER_ID_UPDT ,
     ISD_AUDIT_USER_UPDT_DTM ,
     INDM_SCH_DTL_ID ,
     DW_CREATE_DTTM ,
     DW_UPDATE_DTTM ,
     CLAIM_AUTH_USER_ID )

(SELECT
                          DISTINCT ISD.INDM_SCH_ID,
                          ISD.INDM_SCH_DTL_PRCS_DT,
                          ISD.INDM_SCH_DLVR_DT,
                          ISD.INDM_SCH_DTL_DRV_EFF_DT,
                          ISD.INDM_SCH_DTL_DRV_END_DT,
                          ISD.INDM_SCH_DTL_DRV_DD,
                          ISD.INDM_SCH_DTL_DRV_AMT,
                          ISD.INDM_SCH_DTL_STS_TYP_CD AS ISD_INDM_SCH_DTL_STS_TYP_CD,
                          ISDST.INDM_SCH_DTL_STS_TYP_NM AS ISD_INDM_SCH_DTL_STS_TYP_NM,
                          ISD.INDM_SCH_DTL_OFST_AMT,
                          ISD.INDM_SCH_DTL_LMP_RED_AMT,
                          ISD.INDM_SCH_DTL_OTHR_RED_AMT,
                          ISD.INDM_SCH_DTL_DRV_NET_AMT,
                          ISD.INDM_SCH_DTL_FNL_PAY_IND,
                          ISD.LTE_PAY_RSN_TYP_CD,
                          ISD.VOID_IND AS INDM_SCH_DET_VOID_IND,
                          ISDMT.INDM_SCH_DTL_MSG_TYP_CD,
                          ISDMT.INDM_SCH_DTL_MSG_TYP_NM,
                          ISDMT.INDM_SCH_DTL_MSG_TYP_DESC,
                          ISD.AUDIT_USER_ID_CREA AS ISD_AUDIT_USER_ID_CREA,
                          ISD.AUDIT_USER_CREA_DTM AS ISD_AUDIT_USER_CREA_DTM,
                          ISD.AUDIT_USER_ID_UPDT AS ISD_AUDIT_USER_ID_UPDT,
                          ISD.AUDIT_USER_UPDT_DTM AS ISD_AUDIT_USER_UPDT_DTM,
                          ISD.INDM_SCH_DTL_ID,
                          CURRENT_DATE,
                          CURRENT_DATE,
                          HIST.CLAIM_AUTH_USER_ID
                      FROM
                          PCMP.INDEMNITY_SCHEDULE_DETAIL ISD 
                         LEFT OUTER JOIN PCMP.INDEMNITY_SCH_DTL_STS_TYP ISDST ON ISD.INDM_SCH_DTL_STS_TYP_CD = ISDST.INDM_SCH_DTL_STS_TYP_CD 
						 LEFT OUTER JOIN PCMP.INDEMNITY_SCHEDULE_DETAIL_MSG ICDM ON ISD.INDM_SCH_DTL_ID = ICDM.INDM_SCH_DTL_ID AND ICDM.VOID_IND = 'n' 
                         LEFT OUTER JOIN PCMP.INDEMNITY_SCHEDULE_DTL_MSG_TYP ISDMT ON ISDMT.INDM_SCH_DTL_MSG_TYP_CD = ICDM.INDM_SCH_DTL_MSG_TYP_CD 
                         LEFT OUTER JOIN 
                                (SELECT INDM_SCH_DTL_ID,
								COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) CLAIM_AUTH_USER_ID,  
								ROW_NUMBER() OVER ( PARTITION BY INDM_SCH_DTL_ID ORDER BY INDM_SCH_DTL_STS_TYP_CD DESC, HIST_EFF_DTM DESC) ROWNUM
								FROM PCMP.INDEMNITY_SCHEDULE_DETAIL_HIST 
								WHERE INDM_SCH_DTL_STS_TYP_CD IN ('rel', 'paid') 
								AND   VOID_IND = 'n') HIST           
                                                       ON ISD.INDM_SCH_DTL_ID =HIST.INDM_SCH_DTL_ID AND HIST.ROWNUM = 1);COMMIT;
