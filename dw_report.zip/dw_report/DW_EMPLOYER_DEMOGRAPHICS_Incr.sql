/* Added 3 new columns 1) EMPLR_CUST_NO   2) EMPLR_PRMRY_EMAIL_ADRS  3) MED_ONLY_PRGRM_IND 
    JULY 18TH prod release 
	added join to PCMP.CUSTOMER for CUST_NO
	added join to PCMP.CUSTOMER_INTERACTION_CHANNEL for email address
	added join to PCMP.POLICY_PROFILE for Med Only Program Ind
Added 1 Column for PROD June 29th Release - June 2018: adding 1 column INSRD_CERT_IND (SP #960)

January 2021 - Added additional filter of PLCY_CTL_ELEM_VOID_IND = 'n' to join to DW_POLICY_CONTROL_ELEMENT AA

May 2021 --update: changing logic to require Employer to have Policy Profile AND Policy Control Element. (previously OR from 2019)
	 --addition: adding new column, CRNT_AEO_IND

August 2021 --addition: adding new column, STRT_THRU_PRCS_IND

December 2021 --update: adding filter to remove voided legal name records

 */

--\set ON_ERROR_STOP on

TRUNCATE TABLE DW_REPORT.DW_EMPLOYER_DEMOGRAPHICS ;
INSERT /*+DIRECT*/ INTO  DW_REPORT.DW_EMPLOYER_DEMOGRAPHICS 
(AGRE_ID
,PLCY_NO
,BUSN_SEQ_NO
,EMPLR_CUST_ID
,EMPLR_LEGAL_NAME
,EMPLR_LEGAL_UPRCS_NAME
,EMPLR_DBA_NAME
,PLCY_ORIG_EFF_DT
,CRNT_PLCY_TYPE_CODE
,CRNT_PLCY_TYPE_UPRCS_CODE
,CRNT_PLCY_TYPE_NAME
,CRNT_PRMRY_CLASS_CODE
,CRNT_INDUSTRY_NUMBER
,CRNT_INDUSTRY_DESCR
,BUSN_TYPE_CODE
,BUSN_TYPE_NAME
,CRNT_PLCY_STS_TYPE_CODE
,CRNT_PLCY_STS_TYPE_NAME
,CRNT_PLCY_STS_RSN_TYPE_CODE
,CRNT_PLCY_STS_RSN_TYPE_NAME
,CRNT_PLCY_STS_EFF_DATE
,EMPLR_FEIN_NUMBER
,EMPLR_FRMTD_FEIN_NUMBER
,EMPLR_SSN_NUMBER
,EMPLR_FRMTD_SSN_NUMBER
,EMPLR_MAIL_ADRS_LINE1
,EMPLR_MAIL_ADRS_LINE2
,EMPLR_MAIL_ADRS_CITY_NAME
,EMPLR_MAIL_ADRS_STATE_CODE
,EMPLR_MAIL_ADRS_STATE_NAME
,EMPLR_MAIL_ADRS_POST_CODE
,EMPLR_MAIL_ADRS_COUNTY_NAME
,EMPLR_MAIL_ADRS_COUNTRY_NAME
,EMPLR_MAIL_ADRS_VLDTD_IND
,EMPLR_PHYS_ADRS_LINE1
,EMPLR_PHYS_ADRS_LINE2
,EMPLR_PHYS_ADRS_CITY_NAME
,EMPLR_PHYS_ADRS_STATE_CODE
,EMPLR_PHYS_ADRS_STATE_NAME
,EMPLR_PHYS_ADRS_POST_CODE
,EMPLR_PHYS_ADRS_COUNTY_NAME
,EMPLR_PHYS_ADRS_COUNTRY_NAME
,EMPLR_PHYS_ADRS_VLDTD_IND
,EMPLR_PHONE_NUMBER
,EMPLR_FRMTD_PHONE_NUMBER
,EMPLR_PHONE_EXTNS_NUMBER
,EMPLR_FAX_NUMBER
,EMPLR_FRMTD_FAX_NUMBER
,EMPLR_FAX_EXTNS_NUMBER
,CRNT_ASGN_EFF_DATE
,ASGND_USER_NUMBER
,ASGND_USER_NAME
,SUPERVISOR_NUMBER
,SUPERVISOR_NAME
,ASGND_SRVC_OFFICE
,ASGND_ORG_UNIT
,EMPLR_CNTCT_NAME
,EMPLR_CNTCT_PHONE_NUMBER
,EMPLR_CNTCT_EMAIL_ADDRESS
,LAST_AUDIT_TYPE_CODE
,LAST_AUDIT_TYPE_NAME
,LAST_AUDIT_DUE_DATE
,LAST_AUDIT_COMP_DATE
,AUDITOR_NUMBER
,AUDITOR_NAME
,CRNT_GROW_OHIO_IND
,DW_CREATE_DTTM
,DW_UPDATE_DTTM
,CRNT_PLCY_STS_RSN_EFF_DATE
,CRNT_PLCY_STS_RSN_CHNG_EFF_DATE
,EMPLR_CUST_NO
,EMPLR_PRMRY_EMAIL_ADRS
,MED_ONLY_PRGRM_IND
,MCO_ID_NO
,MCO_NAME
,MCO_PLCY_RLTNS_BGN_DATE
,CRNT_RTNG_GROUP_NMBR
,CRNT_RTNG_GROUP_NAME
,CRNT_PEO_IND
,INSRD_CERT_IND
,CRNT_AEO_IND
,STRT_THRU_PRCS_IND)
(select distinct pp.AGRE_ID 
, pp.PLCY_NO
, ptcp.BUSN_SEQ_NO
, ptcp.CUST_ID as EMPLR_CUST_ID
, cn1.CUST_NM_NM as EMPLR_LEGAL_NAME
, cn1.CUST_NM_DRV_UPCS_NM as EMPLR_LEGAL_UPRCS_NAME
, cn2.CUST_NM_NM as EMPLR_DBA_NAME
, plcy.PLCY_ORIG_DT as PLCY_ORIG_EFF_DT
, pce.CTL_ELEM_SUB_TYP_CD as CRNT_PLCY_TYPE_CODE
, upper(pce.CTL_ELEM_SUB_TYP_CD) as CRNT_PLCY_TYPE_UPRCS_CODE
, pce.CTL_ELEM_SUB_TYP_NM as CRNT_PLCY_TYPE_NAME
, gc.PLCY_PRD_GOVN_CLS_CLS_CD as CRNT_PRMRY_CLASS_CODE
, coalesce(prgo.OVRD_RATE_GRP_NMBR, eprg.DFLT_RATE_GRP_NMBR) as CRNT_INDUSTRY_NUMBER
, coalesce(TRIM(prgo.OVRD_RATE_GRP_DESC), TRIM(eprg.DFLT_RATE_GRP_DESC)) as CRNT_INDUSTRY_DESCR
, co.OWNSHP_TYP_CD as BUSN_TYPE_CODE
, ot.OWNSHP_TYP_NM as BUSN_TYPE_NAME
, psrh.PLCY_STS_TYP_CD as CRNT_PLCY_STS_TYPE_CODE
, sts.STS_TYP_NM as CRNT_PLCY_STS_TYPE_NAME
, psrh.PLCY_STS_RSN_TYP_CD as CRNT_PLCY_STS_RSN_TYPE_CODE
, sts.TRANS_RSN_TYP_NM as CRNT_PLCY_STS_RSN_TYPE_NAME	
, psrh.PLCY_STS_EFF_DT as CRNT_PLCY_STS_EFF_DATE		
, ti.TAX_ID_NO as EMPLR_FEIN_NUMBER	
, left(ti.TAX_ID_NO,2) || '-' || right(ti.TAX_ID_NO,7) as EMPLR_FRMTD_FEIN_NUMBER
, ti2.TAX_ID_NO as EMPLR_SSN_NUMBER	
, left(ti2.TAX_ID_NO,3) || '-' || substr(ti2.TAX_ID_NO,4,2) || '-' || right(ti2.TAX_ID_NO,4) as EMPLR_FRMTD_SSN_NUMBER
, cam.CUST_ADDR_STR_1 as EMPLR_MAIL_ADRS_LINE1
, cam.CUST_ADDR_STR_2 as EMPLR_MAIL_ADRS_LINE2
, cam.CUST_ADDR_CITY_NM as EMPLR_MAIL_ADRS_CITY_NAME
, sttm.STT_ABRV as EMPLR_MAIL_ADRS_STATE_CODE
, sttm.STT_NM as EMPLR_MAIL_ADRS_STATE_NAME
, cam.CUST_ADDR_POST_CD as EMPLR_MAIL_ADRS_POST_CODE
, cam.CUST_ADDR_CNTY_NM as EMPLR_MAIL_ADRS_COUNTY_NAME
, cym.CNTRY_NM as EMPLR_MAIL_ADRS_COUNTRY_NAME
, cam.CUST_ADDR_VLDT_PRFM_IND as EMPLR_MAIL_ADRS_VLDTD_IND
, cap.CUST_ADDR_STR_1 as EMPLR_PHYS_ADRS_LINE1						
, cap.CUST_ADDR_STR_2 as EMPLR_PHYS_ADRS_LINE2
, cap.CUST_ADDR_CITY_NM as EMPLR_PHYS_ADRS_CITY_NAME
, sttp.STT_ABRV as EMPLR_PHYS_ADRS_STATE_CODE
, sttp.STT_NM as EMPLR_PHYS_ADRS_STATE_NAME
, cap.CUST_ADDR_POST_CD as EMPLR_PHYS_ADRS_POST_CODE
, cap.CUST_ADDR_CNTY_NM as EMPLR_PHYS_ADRS_COUNTY_NAME
, cyp.CNTRY_NM as EMPLR_PHYS_ADRS_COUNTRY_NAME
, cap.CUST_ADDR_VLDT_PRFM_IND as EMPLR_PHYS_ADRS_VLDTD_IND
, cic1.CUST_INTRN_CHNL_PHN_NO as EMPLR_PHONE_NUMBER
, case when length(cic1.CUST_INTRN_CHNL_PHN_NO) = 10
	then '(' || left(cic1.CUST_INTRN_CHNL_PHN_NO,3) || ') ' || substr(cic1.CUST_INTRN_CHNL_PHN_NO,4,3) || '-' || right(cic1.CUST_INTRN_CHNL_PHN_NO,4)
	when length(cic1.CUST_INTRN_CHNL_PHN_NO) = 7
	then left(cic1.CUST_INTRN_CHNL_PHN_NO,3) || '-' || right(cic1.CUST_INTRN_CHNL_PHN_NO,4)
	else null end as EMPLR_FRMTD_PHONE_NUMBER
, cic1.CUST_INTRN_CHNL_PHN_NO_EXT as EMPLR_PHONE_EXTNS_NUMBER
, cic2.CUST_INTRN_CHNL_PHN_NO as EMPLR_FAX_NUMBER
, case when length(cic2.CUST_INTRN_CHNL_PHN_NO) = 10
	then '(' || left(cic2.CUST_INTRN_CHNL_PHN_NO,3) || ') ' || substr(cic2.CUST_INTRN_CHNL_PHN_NO,4,3) || '-' || right(cic2.CUST_INTRN_CHNL_PHN_NO,4)
	when length(cic2.CUST_INTRN_CHNL_PHN_NO) = 7
	then left(cic2.CUST_INTRN_CHNL_PHN_NO,3) || '-' || right(cic2.CUST_INTRN_CHNL_PHN_NO,4)
	else null end as EMPLR_FRMTD_FAX_NUMBER
, cic2.CUST_INTRN_CHNL_PHN_NO_EXT as EMPLR_FAX_EXTNS_NUMBER			
, a.ASGN_EFF_DT as CRNT_ASGN_EFF_DATE					
, a.ASGND_USER_NUMBER
, a.ASGND_USER_NAME	
, a.SUPERVISOR_NUMBER
, a.SUPERVISOR_NAME
, a.ORG_UNT_ABRV_NM as ASGND_SRVC_OFFICE
, a.ORG_UNT_NM as ASGND_ORG_UNIT
, cc.CUST_CNTC_NM as EMPLR_CNTCT_NAME
, ccdp.CUST_CNTC_DTL_VAL_1 as EMPLR_CNTCT_PHONE_NUMBER
, ccde.CUST_CNTC_DTL_VAL_1 as EMPLR_CNTCT_EMAIL_ADDRESS				
, audit.LAST_AUDIT_TYPE_CODE
, audit.LAST_AUDIT_TYPE_NAME		
, audit.LAST_AUDIT_DUE_DATE							
, audit.LAST_AUDIT_COMP_DATE
, audit.AUDITOR_NUMBER
, audit.AUDITOR_NAME
, grow_ohio.CRNT_GROW_OHIO_IND
, current_date() AS DW_CREATE_DTTM
, current_date() AS DW_UPDATE_DTTM
, psrh.PLCY_STS_RSN_EFF_DT as CRNT_PLCY_STS_RSN_EFF_DATE
, psrh.PLCY_STS_RSN_CHG_EFF_DT as CRNT_PLCY_STS_RSN_CHNG_EFF_DATE
, ptcp.CUST_NO as EMPLR_CUST_NO
, cice.CUST_INTRN_CHNL_ADDR as EMPLR_PRMRY_EMAIL_ADRS
,case 
    when med_only.PLCY_PRFL_ANSW_TEXT = 'yes' 
       then 'y' 
	   else 'n' 
   end as MED_ONLY_PRGRM_IND 
   , THFMEMP.MCO_ID_NO 		AS MCO_ID_NO
   , TDFNTWD.NTWRK_NAME		AS MCO_NAME
   , DATE(THFMEMP.RLTNS_BGN_DATE) 		AS MCO_PLCY_RLTNS_BGN_DATE
   , PGRERCN.PGRER_GRP_NO		AS CRNT_RTNG_GROUP_NMBR
   , PGRERCN.CUST_NM_NM			AS CRNT_RTNG_GROUP_NAME
   , CASE WHEN PEO.CRNT_PEO_IND = 'y' and PEO2.CRNT_PEO_IND = 'y' THEN 'y' ELSE 'n' END AS CRNT_PEO_IND
   , INSRD_CERT_IND
   , CASE WHEN PEO.CRNT_PEO_IND = 'y' and AEO.CRNT_AEO_IND = 'y' THEN 'y' ELSE 'n' END AS CRNT_AEO_IND
   , plcy.PLCY_WEB_QUOT_IND as STRT_THRU_PRCS_IND
from PCMP.POLICY_PERIOD pp
inner join PCMP.AGREEMENT ag on pp.AGRE_ID = ag.AGRE_ID and ag.AGRE_TYP_CD = 'plcy'
inner join (
	select max_pp.AGRE_ID,
	coalesce(crnt_pp.CRNT_EFF_DT, max_pp.MAX_EFF_DT) as EFF_DT,
	coalesce(crnt_pp.CRNT_END_DT, max_pp.MAX_END_DT) as END_DT
	from (
		select AGRE_ID, max(PLCY_PRD_EFF_DT) as MAX_EFF_DT, max(PLCY_PRD_END_DT) as MAX_END_DT
		from PCMP.POLICY_PERIOD WHERE VOID_IND = 'n' group by AGRE_ID
	) max_pp 
	left outer join (
		select AGRE_ID, PLCY_PRD_EFF_DT as CRNT_EFF_DT, PLCY_PRD_END_DT as CRNT_END_DT
		from PCMP.POLICY_PERIOD where PLCY_PRD_EFF_DT <= current_date() and current_date() < PLCY_PRD_END_DT and VOID_IND = 'n'
	) crnt_pp on max_pp.AGRE_ID = crnt_pp.AGRE_ID
) crnt on pp.AGRE_ID = crnt.AGRE_ID and pp.PLCY_NO is not null
	and pp.PLCY_PRD_EFF_DT = crnt.EFF_DT and pp.PLCY_PRD_END_DT = crnt.END_DT
inner join PCMP.POLICY plcy on pp.AGRE_ID = plcy.AGRE_ID
inner join (
	select distinct p.AGRE_ID, p.CUST_ID, c.CUST_NO, pppi.PLCY_PRD_PTCP_INS_BUSN_SEQ_NO as BUSN_SEQ_NO,PLCY_PRD_PTCP_INS_CERT_IND as INSRD_CERT_IND
	from PCMP.PARTICIPATION p
	inner join PCMP.POLICY_PERIOD_PARTICIPATION ppp on p.PTCP_ID = ppp.PTCP_ID AND PPP.VOID_IND = 'n'
	inner join PCMP.POLICY_PERIOD pp on ppp.PLCY_PRD_ID = pp.PLCY_PRD_ID and PP.VOID_IND = 'n'
	inner join PCMP.POLICY_PERIOD_PTCP_INS pppi on p.PTCP_ID = pppi.PTCP_ID
	inner join PCMP.CUSTOMER c on p.CUST_ID = c.CUST_ID
	where PLCY_PRD_EFF_DT < current_date()
    QUALIFY (ROW_NUMBER() OVER (PARTITION BY p.AGRE_ID, p.CUST_ID, c.CUST_NO, 
    pppi.PLCY_PRD_PTCP_INS_BUSN_SEQ_NO order by PLCY_PRD_EFF_DT desc ) ) = 1
) ptcp on pp.AGRE_ID = ptcp.AGRE_ID
inner join DW_REPORT.DW_POLICY_CONTROL_ELEMENT pce on pp.PLCY_PRD_ID = pce.PLCY_PRD_ID and pce.CTL_ELEM_TYP_CD = 'plcy_typ' and pce.PLCY_CTL_ELEM_VOID_IND = 'n'
inner join PCMP.CUSTOMER_NAME cn1 on ptcp.CUST_ID = cn1.CUST_ID 
	and cn1.CUST_NM_TYP_CD = 'busn_legal_nm' and cn1.CUST_NM_END_DT is null and cn1.VOID_IND = 'n'
left outer join DW_REPORT.DW_POLICY_STATUS_REASON_HISTORY psrh on pp.PLCY_PRD_ID = psrh.PLCY_PRD_ID and psrh.CRNT_IND = 'y'
left outer join DW_REPORT.DW_STATUS sts on psrh.STATUS_ID = sts.STATUS_ID and sts.PLCY_CLM_IND = 'PLCY'
left outer join (
	select dba1.CUST_ID, dba1.CUST_NM_NM from PCMP.CUSTOMER_NAME dba1
	inner join (
		select CUST_ID, max(CUST_NM_EFF_DT) as MAX_EFF_DT, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DT from PCMP.CUSTOMER_NAME 
		where CUST_NM_TYP_CD = 'pri_dba_nm' and VOID_IND = 'n' 
		and CUST_NM_EFF_DT <= current_date() and (CUST_NM_END_DT > current_date()  or CUST_NM_END_DT is null)
		group by CUST_ID
	) dba2 on dba1.CUST_ID = dba2.CUST_ID and dba1.CUST_NM_EFF_DT = dba2.MAX_EFF_DT and dba1.AUDIT_USER_CREA_DTM = dba2.MAX_CRT_DT
	where dba1.CUST_NM_TYP_CD = 'pri_dba_nm' and dba1.VOID_IND = 'n' 
	and dba1.CUST_NM_EFF_DT <= current_date() and (dba1.CUST_NM_END_DT > current_date() or dba1.CUST_NM_END_DT is null) 
) cn2 on ptcp.CUST_ID = cn2.CUST_ID
left outer join (
       select cam1.CUST_ID, cam1.CUST_ADDR_STR_1, cam1.CUST_ADDR_STR_2, cam1.CUST_ADDR_CITY_NM, cam1.STT_ID, 
       cam1.CUST_ADDR_POST_CD, cam1.CUST_ADDR_CNTY_NM, cam1.CNTRY_ID, cam1.CUST_ADDR_VLDT_PRFM_IND
       from PCMP.CUSTOMER_ADDRESS cam1
       inner join (select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DTM, max(CUST_ADDR_EFF_DT) as MAX_EFF_DT
                           from PCMP.CUSTOMER_ADDRESS where CUST_ADDR_TYP_CD = 'mail' and VOID_IND = 'n'
			and CUST_ADDR_EFF_DT <= current_date() and (CUST_ADDR_END_DT > current_date() or CUST_ADDR_END_DT is null) group by CUST_ID
       ) cam2 on cam1.CUST_ID = cam2.CUST_ID and cam1.AUDIT_USER_CREA_DTM = cam2.MAX_CRT_DTM and cam1.CUST_ADDR_EFF_DT = cam2.MAX_EFF_DT
       where cam1.CUST_ADDR_TYP_CD = 'mail' and cam1.VOID_IND = 'n'
       and cam1.CUST_ADDR_EFF_DT <= current_date() and (cam1.CUST_ADDR_END_DT > current_date() or cam1.CUST_ADDR_END_DT is null)
) cam on ptcp.CUST_ID = cam.CUST_ID 
left outer join PCMP.STATE sttm on cam.STT_ID = sttm.STT_ID
left outer join PCMP.COUNTRY cym on cam.CNTRY_ID = cym.CNTRY_ID
left outer join (
       select cap1.CUST_ID, cap1.CUST_ADDR_STR_1, cap1.CUST_ADDR_STR_2, cap1.CUST_ADDR_CITY_NM, cap1.STT_ID, 
       cap1.CUST_ADDR_POST_CD, cap1.CUST_ADDR_CNTY_NM, cap1.CNTRY_ID, cap1.CUST_ADDR_VLDT_PRFM_IND
       from PCMP.CUSTOMER_ADDRESS cap1
       inner join (select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DTM, max(CUST_ADDR_EFF_DT) as MAX_EFF_DT
                        from PCMP.CUSTOMER_ADDRESS where CUST_ADDR_TYP_CD = 'phys' and VOID_IND = 'n'
			and CUST_ADDR_EFF_DT <= current_date() and (CUST_ADDR_END_DT > current_date() or CUST_ADDR_END_DT is null) group by CUST_ID
       ) cap2 on cap1.CUST_ID = cap2.CUST_ID and cap1.AUDIT_USER_CREA_DTM = cap2.MAX_CRT_DTM and cap1.CUST_ADDR_EFF_DT = cap2.MAX_EFF_DT
       where cap1.CUST_ADDR_TYP_CD = 'phys' and cap1.VOID_IND = 'n'
       and cap1.CUST_ADDR_EFF_DT <= current_date() and (cap1.CUST_ADDR_END_DT > current_date() or cap1.CUST_ADDR_END_DT is null)
) cap on ptcp.CUST_ID = cap.CUST_ID
left outer join PCMP.STATE sttp on cap.STT_ID = sttp.STT_ID
left outer join PCMP.COUNTRY cyp on cap.CNTRY_ID = cyp.CNTRY_ID
left outer join (
	select cic1a.CUST_ID, cic1a.CUST_INTRN_CHNL_PHN_NO, cic1a.CUST_INTRN_CHNL_PHN_NO_EXT
	from PCMP.CUSTOMER_INTERACTION_CHANNEL cic1a
	inner join (
		select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CUSTOMER_INTERACTION_CHANNEL 
		where INTRN_CHNL_TYP_CD = 'p' and PHN_NO_TYP_CD = 'b'
		and CUST_INTRN_CHNL_PRI_IND = 'y' and VOID_IND = 'n' group by CUST_ID
	) cic1b on cic1a.CUST_ID = cic1b.CUST_ID and cic1a.AUDIT_USER_CREA_DTM = cic1b.MAX_DT
	where cic1a.INTRN_CHNL_TYP_CD = 'p' and cic1a.PHN_NO_TYP_CD = 'b'
	and cic1a.CUST_INTRN_CHNL_PRI_IND = 'y' and cic1a.VOID_IND = 'n'
) cic1 on ptcp.CUST_ID = cic1.CUST_ID
left outer join (
	select cic2a.CUST_ID, cic2a.CUST_INTRN_CHNL_PHN_NO, cic2a.CUST_INTRN_CHNL_PHN_NO_EXT
	from PCMP.CUSTOMER_INTERACTION_CHANNEL cic2a
	inner join (
		select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CUSTOMER_INTERACTION_CHANNEL 
		where INTRN_CHNL_TYP_CD = 'p' and PHN_NO_TYP_CD = 'f'
		and CUST_INTRN_CHNL_PRI_IND = 'y' and VOID_IND = 'n' group by CUST_ID
	) cic2b on cic2a.CUST_ID = cic2b.CUST_ID and cic2a.AUDIT_USER_CREA_DTM = cic2b.MAX_DT
	where cic2a.INTRN_CHNL_TYP_CD = 'p' and cic2a.PHN_NO_TYP_CD = 'f'
	and cic2a.CUST_INTRN_CHNL_PRI_IND = 'y' and cic2a.VOID_IND = 'n'
) cic2 on ptcp.CUST_ID = cic2.CUST_ID
left outer join (
	select cicea.CUST_ID, cicea.CUST_INTRN_CHNL_ADDR
	from PCMP.CUSTOMER_INTERACTION_CHANNEL cicea
	inner join (
		select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CUSTOMER_INTERACTION_CHANNEL 
		where INTRN_CHNL_TYP_CD = 'e'
		and CUST_INTRN_CHNL_PRI_IND = 'y' and VOID_IND = 'n' group by CUST_ID
	) ciceb on cicea.CUST_ID = ciceb.CUST_ID and cicea.AUDIT_USER_CREA_DTM = ciceb.MAX_DT
	where cicea.INTRN_CHNL_TYP_CD = 'e'
	and cicea.CUST_INTRN_CHNL_PRI_IND = 'y' and cicea.VOID_IND = 'n'
) cice on ptcp.CUST_ID = cice.CUST_ID
left outer join PCMP.POLICY_PERIOD_GOVERNING_CLASS gc on pp.PLCY_PRD_ID = gc.PLCY_PRD_ID 
	and gc.JUR_TYP_CD = 'oh' and gc.VOID_IND = 'n'
left outer join BWCODS.THFEPRG eprg on pp.PLCY_NO = lpad(eprg.PLCY_NO::varchar, 8, '0'::varchar(1)) and eprg.EPRG_END_DATE > current_date()
left outer join BWCODS.THFPRGO prgo on pp.PLCY_NO = lpad(prgo.PLCY_NO::varchar, 8, '0'::varchar(1)) and prgo.PRGO_END_DATE > current_date()
left outer join PCMP.TAX_IDENTIFIER ti on ptcp.CUST_ID = ti.CUST_ID and ti.TAX_ID_TYP_CD = 'fein' 
	and ti.TAX_ID_END_DT is null and ti.VOID_IND = 'n'
left outer join PCMP.TAX_IDENTIFIER ti2 on ptcp.CUST_ID = ti2.CUST_ID and ti2.TAX_ID_TYP_CD = 'ssn' 
	and ti2.TAX_ID_END_DT is null and ti2.VOID_IND = 'n'
left outer join (
	select asgn.ASGN_CNTX_ID, asgn.ASGN_PRI_OWNR_IND, asgn.ASGN_EFF_DT, asgn.ASGN_END_DT, 
	au.USER_ID as ASGND_USER_ID, au.USER_LGN_NM as ASGND_USER_NUMBER, au.USER_DRV_UPCS_NM as ASGND_USER_NAME, 
	su.USER_ID as SUPERVISOR_ID, su.USER_LGN_NM as SUPERVISOR_NUMBER, su.USER_DRV_UPCS_NM as SUPERVISOR_NAME, 
	ou.ORG_UNT_ID, ou.ORG_UNT_ABRV_NM, ou.ORG_UNT_NM 
	from PCMP.ASSIGNMENT asgn
	INNER join (
		select ASGN_CNTX_ID, max(ASGN_ID) as ASGN_ID from PCMP.ASSIGNMENT 
		where APP_CNTX_TYP_CD = 'policy' and ASGN_END_DT is null and ASGN_PRI_OWNR_IND = 'y'
		group by ASGN_CNTX_ID order by ASGN_CNTX_ID
	) max_asgn on asgn.ASGN_ID = max_asgn.ASGN_ID
	LEFT OUTER join PCMP.USERS au on asgn.USER_ID = au.USER_ID
	LEFT OUTER join PCMP.ORGANIZATIONAL_UNIT ou on asgn.ORG_UNT_ID = ou.ORG_UNT_ID
	left outer join PCMP.USERS su on au.USER_SUPR_ID = su.USER_ID
) a on pp.PLCY_PRD_ID = a.ASGN_CNTX_ID
left outer join (
	select cc3.* from PCMP.CUSTOMER_CONTACT cc3
	inner join (
		select cc1.CUST_ID, max(cc1.CUST_CNTC_ID) as MAX_ID from PCMP.CUSTOMER_CONTACT cc1
		inner join (
			select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CUSTOMER_CONTACT
			where CNTC_TYP_CD = 'primary' and CUST_CNTC_END_DT is null and CUST_CNTC_VOID_IND = 'n' group by CUST_ID
		) cc2 on cc1.CUST_ID = cc2.CUST_ID and cc1.AUDIT_USER_CREA_DTM = cc2.MAX_DT
		and cc1.CNTC_TYP_CD = 'primary' and cc1.CUST_CNTC_END_DT is null and cc1.CUST_CNTC_VOID_IND = 'n' group by cc1.CUST_ID
	) cc12 on cc3.CUST_ID = cc12.CUST_ID and cc3.CUST_CNTC_ID = cc12.MAX_ID
	and cc3.CNTC_TYP_CD = 'primary' and cc3.CUST_CNTC_END_DT is null and cc3.CUST_CNTC_VOID_IND = 'n'
) cc on ptcp.CUST_ID = cc.CUST_ID
left outer join (
	select distinct ccd3.CUST_CNTC_ID, ccd3.CUST_CNTC_DTL_VAL_1 from PCMP.CUSTOMER_CONTACT_DETAIL ccd3
	inner join (
		select ccd1.CUST_CNTC_ID, max(ccd1.CUST_CNTC_DTL_ID) as MAX_ID from PCMP.CUSTOMER_CONTACT_DETAIL ccd1
		inner join (
			select CUST_CNTC_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT
			from PCMP.CUSTOMER_CONTACT_DETAIL 
			where CUST_CNTC_DTL_TYP_CD = 'phn' and CUST_CNTC_DTL_SUB_TYP = 'b' and CUST_CNTC_DTL_VOID_IND = 'n'
			group by CUST_CNTC_ID
		) ccd2 on ccd1.CUST_CNTC_ID = ccd2.CUST_CNTC_ID and ccd1.AUDIT_USER_CREA_DTM = ccd2.MAX_DT
		where CUST_CNTC_DTL_TYP_CD = 'phn' and CUST_CNTC_DTL_SUB_TYP = 'b' and CUST_CNTC_DTL_VOID_IND = 'n'
		group by ccd1.CUST_CNTC_ID
	) ccd4 on ccd3.CUST_CNTC_ID = ccd4.CUST_CNTC_ID and ccd3.CUST_CNTC_DTL_ID = ccd4.MAX_ID
	where CUST_CNTC_DTL_TYP_CD = 'phn' and CUST_CNTC_DTL_SUB_TYP = 'b' and CUST_CNTC_DTL_VOID_IND = 'n'
) ccdp on cc.CUST_CNTC_ID = ccdp.CUST_CNTC_ID
left outer join (
	select distinct ccd3.CUST_CNTC_ID, ccd3.CUST_CNTC_DTL_VAL_1 from PCMP.CUSTOMER_CONTACT_DETAIL ccd3
	inner join (
		select ccd1.CUST_CNTC_ID, max(ccd1.CUST_CNTC_DTL_ID) as MAX_ID from PCMP.CUSTOMER_CONTACT_DETAIL ccd1
		inner join (
			select CUST_CNTC_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT
			from PCMP.CUSTOMER_CONTACT_DETAIL 
			where CUST_CNTC_DTL_TYP_CD = 'eml' and CUST_CNTC_DTL_VOID_IND = 'n'
			group by CUST_CNTC_ID
		) ccd2 on ccd1.CUST_CNTC_ID = ccd2.CUST_CNTC_ID and ccd1.AUDIT_USER_CREA_DTM = ccd2.MAX_DT
		where CUST_CNTC_DTL_TYP_CD = 'eml' and CUST_CNTC_DTL_VOID_IND = 'n'
		group by ccd1.CUST_CNTC_ID
	) ccd4 on ccd3.CUST_CNTC_ID = ccd4.CUST_CNTC_ID and ccd3.CUST_CNTC_DTL_ID = ccd4.MAX_ID
	where CUST_CNTC_DTL_TYP_CD = 'eml' and CUST_CNTC_DTL_VOID_IND = 'n'
) ccde on cc.CUST_CNTC_ID = ccde.CUST_CNTC_ID
left outer join PCMP.CUSTOMER_OWNERSHIP co on ptcp.CUST_ID = co.CUST_ID 
	and co.CUST_OWNSHP_END_DT is null and co.VOID_IND = 'n'
left outer join PCMP.OWNERSHIP_TYPE ot on co.OWNSHP_TYP_CD = ot.OWNSHP_TYP_CD
left outer join (
	select pp.AGRE_ID, pp.PLCY_NO, pp.PLCY_PRD_EFF_DT,
	ppad.PLCY_AUDT_TYP_CD as LAST_AUDIT_TYPE_CODE, 
	pat.PLCY_AUDT_TYP_NM as LAST_AUDIT_TYPE_NAME,
	ppad.PLCY_PRD_AUDT_DTL_DUE_DT as LAST_AUDIT_DUE_DATE,
	ppad.PLCY_PRD_AUDT_DTL_COMP_DT as LAST_AUDIT_COMP_DATE, 
	ppad.USER_ID, u.USER_LGN_NM as AUDITOR_NUMBER, u.USER_DRV_UPCS_NM as AUDITOR_NAME,
	ppad.PLCY_PRD_AUDT_DTL_ID, ppad.AUDIT_USER_CREA_DTM, ppad.AUDIT_USER_UPDT_DTM, ppad.VOID_IND
	from PCMP.POLICY_PERIOD_AUDIT_DETAIL ppad
	inner join PCMP.POLICY_PERIOD pp on ppad.PLCY_PRD_ID = pp.PLCY_PRD_ID and  PP.VOID_IND = 'n'
	inner join (
		select b.AGRE_ID, max(a.AUDIT_USER_CREA_DTM) as CRT_DT, max(a.PLCY_PRD_AUDT_DTL_COMP_DT) as AUDIT_COMP_DT
		from PCMP.POLICY_PERIOD_AUDIT_DETAIL a
		inner join PCMP.POLICY_PERIOD b on a.PLCY_PRD_ID = b.PLCY_PRD_ID and a.VOID_IND = 'n' and b.VOID_IND = 'n'
		where a.PLCY_PRD_AUDT_DTL_COMP_DT is not null
		group by AGRE_ID
	) max_audit on pp.AGRE_ID = max_audit.AGRE_ID 
		and ppad.PLCY_PRD_AUDT_DTL_COMP_DT = max_audit.AUDIT_COMP_DT and ppad.AUDIT_USER_CREA_DTM = max_audit.CRT_DT
	inner join PCMP.POLICY_AUDIT_TYPE pat on ppad.PLCY_AUDT_TYP_CD = pat.PLCY_AUDT_TYP_CD
	inner join PCMP.USERS u on ppad.USER_ID = u.USER_ID
) audit on pp.AGRE_ID = audit.AGRE_ID and pp.PLCY_PRD_EFF_DT = audit.PLCY_PRD_EFF_DT
left outer join (
	select PLCY_PRD_ID, max(GROW_OHIO_IND) as CRNT_GROW_OHIO_IND
	from (
	select PLCY_PRD_ID,
	case when RT_ELEM_LMCJ_TYP_ID = 6304000 then 'y' else 'n' end as GROW_OHIO_IND
	from PCMP.POLICY_PERIOD_RATING_ELEMENT
	) ppre group by PLCY_PRD_ID
) grow_ohio on PP.PLCY_PRD_ID = grow_ohio.PLCY_PRD_ID
left outer join (
	select PLCY_PRD_ID, PLCY_PRFL_ANSW_TEXT
	from PCMP.POLICY_PROFILE where PRFL_STMT_ID = 6303027
) med_only on PP.PLCY_PRD_ID = med_only.PLCY_PRD_ID
LEFT OUTER JOIN(
	SELECT PLCY_PRD_ID,
	    ROW_NUMBER() OVER (PARTITION BY PLCY_PRD_ID ORDER BY AUDIT_USER_CREA_DTM) AS RANK, 
		PLCY_PRFL_ANSW_TEXT,
   CASE WHEN PLCY_PRFL_ANSW_TEXT = 'yes' THEN 'y'
		ELSE 'n' 
		END AS CRNT_PEO_IND
	FROM PCMP.POLICY_PROFILE 
	WHERE PRFL_STMT_ID = 6001 AND PLCY_PRFL_VOID_IND = 'n'
) PEO on PP.PLCY_PRD_ID = PEO.PLCY_PRD_ID AND PEO.RANK =1
LEFT OUTER JOIN ( SELECT AA.PLCY_PRD_ID,AA.PLCY_CTL_ELEM_END_DT,NVL(BB.CRNT_PEO_IND,'n') AS CRNT_PEO_IND  FROM DW_REPORT.DW_POLICY_CONTROL_ELEMENT AA
LEFT OUTER JOIN (SELECT CC.PLCY_PRD_ID,MAX(CC.PLCY_CTL_ELEM_END_DT) AS PLCY_CTL_ELEM_END_DT,'y' AS CRNT_PEO_IND
                                         FROM DW_REPORT.DW_POLICY_CONTROL_ELEMENT CC
                                                WHERE CC.CTL_ELEM_TYP_CD = 'emp_ls_plcy_typ' AND CC.PLCY_CTL_ELEM_VOID_IND = 'n' AND CC.CTL_ELEM_SUB_TYP_NM = 'PEO'
                                                       GROUP BY CC.PLCY_PRD_ID)BB
                                                       ON AA.PLCY_PRD_ID = BB.PLCY_PRD_ID AND AA.PLCY_CTL_ELEM_END_DT = BB.PLCY_CTL_ELEM_END_DT
							WHERE AA.PLCY_CTL_ELEM_VOID_IND = 'n' and current_date() between AA.PLCY_CTL_ELEM_EFF_DT and AA.PLCY_CTL_ELEM_END_DT
)PEO2 ON PP.PLCY_PRD_ID = PEO2.PLCY_PRD_ID
LEFT OUTER JOIN BWCODS.THFMEMP THFMEMP ON PP.PLCY_NO::INT = THFMEMP.PLCY_NO AND THFMEMP.MCO_ID_NO LIKE '1%' AND THFMEMP.RLTNS_END_DATE > current_date() AND THFMEMP.CRNT_RLTNS_FLAG ='Y'
LEFT OUTER JOIN BWCODS.TDFNTWD TDFNTWD ON TDFNTWD.MCO_ID_NO = THFMEMP.MCO_ID_NO
LEFT OUTER JOIN (
	select distinct p.AGRE_ID, p.CUST_ID, c.CUST_NO,P.PTCP_ID,PGRER.PGRER_GRP_NO,CN.CUST_NM_NM
	from PCMP.PARTICIPATION p
	inner join PCMP.POLICY_PERIOD_PARTICIPATION ppp on p.PTCP_ID = ppp.PTCP_ID
	inner join PCMP.CUSTOMER c on p.CUST_ID = c.CUST_ID
	left outer JOIN PCMP.PTCP_GRP_RTRO_EXPRN_RT PGRER ON P.PTCP_ID = PGRER.PTCP_ID 
	left outer JOIN PCMP.CUSTOMER_NAME CN ON C.CUST_ID = CN.CUST_ID
	WHERE P.PTCP_TYP_CD IN  ('group_retro', 'grp_exprn_rt') AND PPP.VOID_IND = 'n'
	AND  current_date() > PPP.PLCY_PRD_PTCP_EFF_DT and   current_date() <= PPP.PLCY_PRD_PTCP_END_DT
	AND CN.CUST_NM_TYP_CD = 'busn_legal_nm' AND CN.CUST_NM_END_DT IS NULL AND CN.VOID_IND = 'n'
	) PGRERCN ON PGRERCN.AGRE_ID = PTCP.AGRE_ID	
LEFT OUTER JOIN ( SELECT AA.PLCY_PRD_ID,AA.PLCY_CTL_ELEM_END_DT,NVL(BB.CRNT_AEO_IND,'n') AS CRNT_AEO_IND  FROM DW_REPORT.DW_POLICY_CONTROL_ELEMENT AA
LEFT OUTER JOIN (SELECT CC.PLCY_PRD_ID,MAX(CC.PLCY_CTL_ELEM_END_DT) AS PLCY_CTL_ELEM_END_DT,'y' AS CRNT_AEO_IND
                                         FROM DW_REPORT.DW_POLICY_CONTROL_ELEMENT CC
                                                WHERE CC.CTL_ELEM_TYP_CD = 'emp_ls_plcy_typ' AND CC.PLCY_CTL_ELEM_VOID_IND = 'n' AND CC.CTL_ELEM_SUB_TYP_NM = 'AEO'
                                                       GROUP BY CC.PLCY_PRD_ID)BB
                                                       ON AA.PLCY_PRD_ID = BB.PLCY_PRD_ID AND AA.PLCY_CTL_ELEM_END_DT = BB.PLCY_CTL_ELEM_END_DT
							WHERE AA.PLCY_CTL_ELEM_VOID_IND = 'n' and current_date() between AA.PLCY_CTL_ELEM_EFF_DT and AA.PLCY_CTL_ELEM_END_DT
)AEO ON PP.PLCY_PRD_ID = AEO.PLCY_PRD_ID

WHERE PP.VOID_IND = 'n'
order by pp.PLCY_NO, ptcp.BUSN_SEQ_NO
); commit;