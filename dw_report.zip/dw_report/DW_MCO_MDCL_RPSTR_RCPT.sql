/* Version #  1		: (Prod Release date 04/17/2018 ) */

/* Table Description 	: This table contains Medical Repository Receipt information for MCO Imaging. */	
								

/* Source Tables 	: BWCMISC.MCO_DCMNT_TRANSMISSION
*/	

/* SCHEDULING 		: This table needs to be refreshed daily */


  --\set ON_ERROR_STOP on
 TRUNCATE TABLE DW_REPORT.DW_MCO_MDCL_RPSTR_RCPT;

 INSERT  /*+DIRECT*/  INTO DW_REPORT.DW_MCO_MDCL_RPSTR_RCPT
(MCO_DCMNT_TRNSM_ID,
 MCO_NMBR,
 FAX_ID,
 PAGE_QTY,
 FAX_RCVD_DTM,
 CRT_PRGRM_NAME,
 DW_CREATE_DTM,
 DW_UPDATE_DTM)
(SELECT DCMNT_TRNSM_ID,
        CASE WHEN (TRIM(MCO_NMBR) = ''::VARCHAR) THEN NULL 
             ELSE TRIM(MCO_NMBR) 
             END AS MCO_NMBR,
        CASE WHEN (TRIM(FAX_ID) = ''::VARCHAR) THEN NULL 
             ELSE TRIM(FAX_ID) 
             END AS FAX_ID,
        PAGE_QTY,
        CRT_DTTM,
        CASE WHEN (TRIM(CRT_PRGRM_NAME) = ''::VARCHAR) THEN NULL 
             ELSE TRIM(CRT_PRGRM_NAME) 
             END AS CRT_PRGRM_NAME,
        CURRENT_DATE AS DW_CREATE_DTM,
        CURRENT_DATE AS DW_UPDATE_DTM
   FROM BWCMISC.MCO_DCMNT_TRANSMISSION);
 
 COMMIT;

