--SRC_LAYER
WITH
HIST      as ( select * from {{source( 'DW_REPORT','DW_CLAIM_POLICY_HISTORY') }} )

/*
HIST      as ( select * from DW_REPORT.DW_CLAIM_POLICY_HISTORY )
*/

/* STEP1: correct the DW_CLAIM_POLICY_HISTORY table for input for Mod industry calculation */
select 
     CLM_AGRE_ID, 
     CLM_NO, 
     DATE_TRUNC('DAY', CLM_PLCY_RLTNS_EFF_DT) CLM_PLCY_RLTNS_EFF_DT, 
     case 
          when DATE_TRUNC('DAY', CLM_PLCY_RLTNS_END_DT) = DATE_TRUNC('DAY', lead(CLM_PLCY_RLTNS_EFF_DT) over (partition by CLM_AGRE_ID order by CLM_PLCY_RLTNS_EFF_DT, CLM_PLCY_RLTNS_END_DT))
          then DATEADD(DAY,-1, DATE_TRUNC('DAY', CLM_PLCY_RLTNS_END_DT))
          else CLM_PLCY_RLTNS_END_DT 
     end CLM_PLCY_RLTNS_END_DT, 
     CTL_ELEM_SUB_TYP_CD, 
     CRNT_PLCY_IND
FROM HIST