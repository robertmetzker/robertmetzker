--SRC_LAYER
WITH
C       as ( select * from {{ source('PCMP','CLAIM') }} ),
CAD     as ( select * from {{ source('PCMP','CLAIM_ADDITIONAL_DETAIL') }}  ),
CAN2    as ( select * from {{ source('PCMP','CLAIM_ALIAS_NUMBER') }}  ),
CEMP    as ( select * from {{ source('PCMP','CLAIM_EMPLOYMENT_STATUS_TYPE') }}  ),
CLCT    as ( select * from {{ source('PCMP','CAUSE_OF_LOSS_CATEGORY_TYPE') }}  ),
CLT     as ( select * from {{ source('PCMP','CAUSE_OF_LOSS_TYPE') }}  ),
CS      as ( select * from {{ source('PCMP','CLAIM_CLAIM_STATUS') }}  ),
CT      as ( select * from {{ source('PCMP','CLAIM_CLAIM_TYPE') }}  ),
CTRT    as ( select * from {{ source('PCMP','CLAIM_TRANSITION_REASON_TYPE') }}  ),
CTY     as ( select * from {{ source('PCMP','CLAIM_TYPE') }}  ),
DWS     as ( select * from {{ source('DW_REPORT','DW_STATUS') }}  ),
ELT     as ( select * from {{ source('PCMP','EDUCATION_LEVEL_TYPE') }}  ),
NOI     as ( select * from {{ source('PCMP','NATURE_OF_INJURY_TYPE') }}  ),
NOIT    as ( select * from {{ source('PCMP','NATURE_OF_INJURY_CATEGORY_TYPE') }}  ),
OMT     as ( select * from {{ source('PCMP','OCCURRENCE_MEDIA_TYPE') }}  ),
OST     as ( select * from {{ source('PCMP','OCCURRENCE_SOURCE_TYPE') }}  ),
ST      as ( select * from {{ source('PCMP','STATE') }}  ),
UCT     as ( select * from {{ source('PCMP','UNUSUAL_CLAIM_TYPE') }}  ),

/*
C       as ( select * from PCMP.CLAIM ),
CAD     as ( select * from PCMP.CLAIM_ADDITIONAL_DETAIL ),
CAN2    as ( select * from PCMP.CLAIM_ALIAS_NUMBER ),
CEMP    as ( select * from PCMP.CLAIM_EMPLOYMENT_STATUS_TYPE ),
CLCT    as ( select * from PCMP.CAUSE_OF_LOSS_CATEGORY_TYPE ),
CLT     as ( select * from PCMP.CAUSE_OF_LOSS_TYPE ),
CS      as ( select * from PCMP.CLAIM_CLAIM_STATUS ),
CT      as ( select * from PCMP.CLAIM_CLAIM_TYPE ),
CTRT    as ( select * from PCMP.CLAIM_TRANSITION_REASON_TYPE ),
CTY     as ( select * from PCMP.CLAIM_TYPE ),
DWS     as ( select * from DW_REPORT.DW_STATUS ),
ELT     as ( select * from PCMP.EDUCATION_LEVEL_TYPE ),
NOI     as ( select * from PCMP.NATURE_OF_INJURY_TYPE ),
NOIT    as ( select * from PCMP.NATURE_OF_INJURY_CATEGORY_TYPE ),
OMT     as ( select * from PCMP.OCCURRENCE_MEDIA_TYPE ),
OST     as ( select * from PCMP.OCCURRENCE_SOURCE_TYPE ),
ST      as ( select * from PCMP.STATE ),
UCT     as ( select * from PCMP.UNUSUAL_CLAIM_TYPE ),
*/

--BUSINESS LAYER/LOGIC LAYER
--CREATE TEMP TABLE 
CLAIM_TEMP_TBL  AS 
(
    SELECT  C.AGRE_ID
    ,C.CLM_NO
    ,C.CLM_OCCR_DTM
    ,to_date(to_char(C.CLM_OCCR_RPT_DT,'YYYY-MM-DD'),'YYYY-MM-DD') AS CLM_OCCR_RPT_DT
    ,NULL::TIMESTAMP AS CLM_OCCR_RPT_TIME
    ,C.CAUS_OF_LOSS_CTG_TYP_CD
    ,C.CAUS_OF_LOSS_TYP_CD
    ,C.CLM_LOSS_TYP_CD
    ,C.CLM_OCCR_LOC_CITY_NM
    ,C.CLM_OCCR_LOC_CNTY_NM
    ,C.CLM_OCCR_LOC_NM
    ,C.CLM_OCCR_LOC_POST_CD
    ,C.CLM_OCCR_LOC_STR_1
    ,C.CLM_OCCR_LOC_STR_2
    ,S.STATUS_ID
    ,CS.CLM_CLM_STS_EFF_DT
    ,CS.CLM_CLM_STS_END_DT
    ,C.CLM_LOSS_DESC
    ,C.CLM_MULTI_OCCR_IND
    ,C.CNTRY_ID
    ,C.CTRPH_CD
    ,C.CTRPH_INJR_TYP_CD
    ,C.CLM_CTRPH_INJR_CMT
    ,C.CLM_CTRPH_INJR_IND
    ,C.CLM_CLMT_JOB_TTL
    ,C.CLM_CLMT_HIRE_DT
    ,C.STT_ID
    ,C.CLM_FST_DCSN_DT
    ,C.AUDIT_USER_ID_CREA
    ,C.AUDIT_USER_CREA_DTM
    ,C.AUDIT_USER_ID_UPDT
    ,C.AUDIT_USER_UPDT_DTM
    ,C.CLM_CLMT_LST_WK_DT
    ,C.CLM_RCVR_TYP_CD
    ,C.CLM_CLMT_FATL_IND
    ,C.NOI_TYP_CD
    ,C.NOI_CTG_TYP_CD
    ,C.OCCR_MEDA_TYP_CD
    ,C.OCCR_SRC_TYP_CD
    ,C.CLM_REL_SNPSHT_IND
    ,CS.CLM_TRANS_RSN_TYP_CD
    ,C.CLM_ADMN_NTF_DT
    ,C.JUR_TYP_CD
    ,C.CLM_CLMT_SHFT_BGN_TIME
    ,C.UNSL_CLM_TYP_CD
    ,C.EDUC_LVL_TYP_CD
    ,C.CLM_EMPL_STS_TYP_CD
    ,C.CLM_ALCH_INVD_IND
    ,C.CLM_DRUG_INVD_IND
    ,C.CLM_NOTE_IND
    FROM C
    INNER JOIN 
        (
            SELECT * FROM CS ORDER BY AGRE_ID
        )  CS 
            ON C.AGRE_ID = CS.AGRE_ID 
    INNER JOIN 
        (
            SELECT * FROM DWS 
            ORDER BY STS_TYP_CD, STT_TYP_CD, TRANS_RSN_TYP_CD, PLCY_CLM_IND
        ) S 
        ON CS.CLM_STS_TYP_CD = S.STS_TYP_CD 
            AND CS.CLM_STT_TYP_CD = S.STT_TYP_CD 
        AND CS.CLM_TRANS_RSN_TYP_CD = S.TRANS_RSN_TYP_CD 
        AND S.PLCY_CLM_IND = 'CLM'
    WHERE C.CLM_REL_SNPSHT_IND = 'n'
    ORDER BY C.AGRE_ID,C.CLM_NO
)

--TRUNCATE AND INSERT INTO CLAIM TABLE
SELECT
    C.AGRE_ID AS CLM_AGRE_ID,
    C.CLM_NO,
    C.CLM_OCCR_DTM,
    C.CLM_OCCR_RPT_DT,
    C.CLM_OCCR_RPT_TIME,
    CASE
        WHEN C.CAUS_OF_LOSS_CTG_TYP_CD IS NULL
        THEN '-1'
        ELSE C.CAUS_OF_LOSS_CTG_TYP_CD
    END CAUS_OF_LOSS_CTG_TYP_CD,
    CLCT.CAUS_OF_LOSS_CTG_TYP_NM,
    CASE
        WHEN C.CAUS_OF_LOSS_TYP_CD IS NULL
        THEN '-1'
        ELSE C.CAUS_OF_LOSS_TYP_CD
    END CAUS_OF_LOSS_TYP_CD,
    CLT.CAUS_OF_LOSS_TYP_NM,
    CASE
        WHEN C.CLM_LOSS_TYP_CD IS NULL
        THEN '-1'
        ELSE C.CLM_LOSS_TYP_CD
    END CLM_LOSS_TYP_CD,
    C.CLM_OCCR_LOC_CITY_NM,
    C.CLM_OCCR_LOC_CNTY_NM,
    C.CLM_OCCR_LOC_NM,
    CASE
        WHEN C.CLM_OCCR_LOC_POST_CD IS NULL
        THEN '-1'
        ELSE C.CLM_OCCR_LOC_POST_CD
    END CLM_OCCR_LOC_POST_CD,
    C.CLM_OCCR_LOC_STR_1,
    C.CLM_OCCR_LOC_STR_2,
    CASE
        WHEN CT.CLM_TYP_CD IS NULL
        THEN '-1'
        ELSE CT.CLM_TYP_CD
    END CLM_TYP_CD,
    CTY.CLM_TYP_NM,
    CT.CLM_CLM_TYP_EFF_DT,
    CT.CLM_CLM_TYP_END_DT,
    C.STATUS_ID,
    C.CLM_CLM_STS_EFF_DT,
    C.CLM_CLM_STS_END_DT,
    CASE
        WHEN CTRT.CLM_TRANS_RSN_TYP_CD IS NULL
        THEN '-1'
        ELSE CTRT.CLM_TRANS_RSN_TYP_CD
    END CLM_TRANS_RSN_TYP_CD,
    CTRT.CLM_TRANS_RSN_TYP_NM,
    C.CLM_LOSS_DESC,
    C.CLM_MULTI_OCCR_IND,
    C.CNTRY_ID,
    CASE
        WHEN C.CTRPH_CD IS NULL
        THEN '-1'
        ELSE C.CTRPH_CD
    END CTRPH_CD,
    CASE
        WHEN C.CTRPH_INJR_TYP_CD IS NULL
        THEN '-1'
        ELSE C.CTRPH_INJR_TYP_CD
    END CTRPH_INJR_TYP_CD,
    C.CLM_CTRPH_INJR_CMT,
    C.CLM_CTRPH_INJR_IND,
    C.CLM_CLMT_JOB_TTL,
    C.CLM_CLMT_HIRE_DT,
    C.STT_ID,
    ST.STT_NM,
    C.CLM_FST_DCSN_DT,
    C.AUDIT_USER_ID_CREA,
    C.AUDIT_USER_CREA_DTM,
    C.AUDIT_USER_ID_UPDT,
    C.AUDIT_USER_UPDT_DTM,
    CAD.CLM_STATU_LMT_DT,
    C.CLM_CLMT_LST_WK_DT,
    CASE
        WHEN C.CLM_RCVR_TYP_CD IS NULL
        THEN '-1'
        ELSE C.CLM_RCVR_TYP_CD
    END CLM_RCVR_TYP_CD,
    C.CLM_CLMT_FATL_IND,
    CASE
        WHEN C.NOI_TYP_CD IS NULL
        THEN '-1'
        ELSE C.NOI_TYP_CD
    END NOI_TYP_CD,
    NOI.NOI_TYP_NM,
    CASE
        WHEN C.NOI_CTG_TYP_CD IS NULL
        THEN '-1'
        ELSE C.NOI_CTG_TYP_CD
    END NOI_CTG_TYP_CD,
    NOIT.NOI_CTG_TYP_NM,
    CASE
        WHEN C.OCCR_MEDA_TYP_CD IS NULL
        THEN '-1'
        ELSE C.OCCR_MEDA_TYP_CD
    END OCCR_MEDA_TYP_CD,
    OMT.OCCR_MEDA_TYP_NM,
    CASE
        WHEN C.OCCR_SRC_TYP_CD IS NULL
        THEN '-1'
        ELSE C.OCCR_SRC_TYP_CD
    END OCCR_SRC_TYP_CD,
    OST.OCCR_SRC_TYP_NM,
    CASE
        WHEN C.CLM_TRANS_RSN_TYP_CD = 'dup'
        AND CAN2.AGRE_ID IS NOT NULL
        THEN 'y'
        ELSE 'n'
    END AS CLAIM_CMBND_IND,
    C.CLM_REL_SNPSHT_IND,
    C.CLM_ADMN_NTF_DT,
    CASE
        WHEN C.JUR_TYP_CD IS NULL
        THEN '-1'
        ELSE C.JUR_TYP_CD
    END UR_TYP_CD,
    C.CLM_CLMT_SHFT_BGN_TIME,
    DATE(C.CLM_OCCR_DTM) AS CLM_OCCR_DATE,
    CAST(TO_CHAR(CLM_OCCR_DTM,'hh:mi:ss') AS TIME(6)) AS CLM_OCCR_TIME,
    CURRENT_DATE AS DW_CREATE_DTTM,
    CURRENT_DATE AS DW_UPDATE_DTTM,
    CT.AUDIT_USER_CREA_DTM CCT_AUDIT_USER_CREA_DTM,
    CT.AUDIT_USER_UPDT_DTM CCT_AUDIT_USER_UPDT_DTM,
    COALESCE(C.UNSL_CLM_TYP_CD, '-1') as UNSL_CLM_TYP_CD,
    UCT.UNSL_CLM_TYP_NM,
    COALESCE(C.EDUC_LVL_TYP_CD, '-1') as EDUC_LVL_TYP_CD,
    ELT.EDUC_LVL_TYP_NM,
    COALESCE(C.CLM_EMPL_STS_TYP_CD, '-1') as CLM_EMPLR_STS_TYP_CD,
    CEMP.CLM_EMPL_STS_TYP_NM,
    C.CLM_ALCH_INVD_IND,
    C.CLM_DRUG_INVD_IND,
    C.CLM_NOTE_IND
FROM
    CLAIM_TEMP_TBL C 
    LEFT JOIN CT 
        ON C.AGRE_ID = CT.AGRE_ID 
    LEFT JOIN ST 
        ON C.STT_ID = ST.STT_ID
        AND ST.STT_VOID_IND = 'n' 
    LEFT JOIN CTRT
        ON C.CLM_TRANS_RSN_TYP_CD = CTRT.CLM_TRANS_RSN_TYP_CD 
    LEFT JOIN CAD
        ON C.AGRE_ID = CAD.AGRE_ID AND CAD.VOID_IND = 'n' 
    LEFT JOIN CLT
        ON C.CAUS_OF_LOSS_TYP_CD = CLT.CAUS_OF_LOSS_TYP_CD AND CLT.VOID_IND = 'n' 
    LEFT JOIN CLCT
        ON C.CAUS_OF_LOSS_CTG_TYP_CD = CLCT.CAUS_OF_LOSS_CTG_TYP_CD AND CLCT.VOID_IND = 'n' 
    LEFT JOIN OMT
        ON C.OCCR_MEDA_TYP_CD = OMT.OCCR_MEDA_TYP_CD AND OMT.VOID_IND = 'n' 
    LEFT JOIN OST
        ON C.OCCR_SRC_TYP_CD = OST.OCCR_SRC_TYP_CD AND OST.VOID_IND = 'n' 
    LEFT JOIN CAN2 
        ON CAN2.CLM_ALIAS_NO_NO = C.CLM_NO
        AND CAN2.CLM_ALIAS_NO_TYP_CD = 'dupexprdclm' AND CAN2.VOID_IND = 'n' 
    LEFT JOIN NOI 
        ON C.NOI_TYP_CD = NOI.NOI_TYP_CD AND NOI.VOID_IND = 'n' 
    LEFT JOIN NOIT
        ON C.NOI_CTG_TYP_CD = NOIT.NOI_CTG_TYP_CD AND NOIT.VOID_IND = 'n' 
    LEFT JOIN CTY 
        ON CT.CLM_TYP_CD = CTY.CLM_TYP_CD
    LEFT JOIN UCT 
        on C.UNSL_CLM_TYP_CD = UCT.UNSL_CLM_TYP_CD
    LEFT JOIN ELT 
        on C.EDUC_LVL_TYP_CD = ELT.EDUC_LVL_TYP_CD
    LEFT JOIN CEMP 
        on C.CLM_EMPL_STS_TYP_CD = CEMP.CLM_EMPL_STS_TYP_CD
        AND CTY.VOID_IND = 'n'