--SRC LAYER
WITH
CFTA  	as ( select * from  {{ source('PCMP','CLAIM_FINANCIAL_TRAN_APP') }} ),
FTAT  	as ( select * from  {{ source('PCMP','FINANCIAL_TRANSACTION_APP_TYP') }} ),
FTATT	as ( select * from  {{ source('PCMP','FINANCIAL_TRAN_APP_TRAN_TYP') }} ),
FTTFR  	as ( select * from  {{ source('PCMP','FINANCIAL_TRANSACTION_TYPE') }} ),
AT		as ( select * from  {{ source('PCMP','AGREEMENT_TYPE') }} ),
UCREA   as ( select * from  {{ source('PCMP','USERS') }} ),
UUPDT	as ( select * from  {{ source('PCMP','USERS') }} )

/*
CFTA  	as ( select * from  PCMP.CLAIM_FINANCIAL_TRAN_APP ),
FTAT  	as ( select * from  PCMP.FINANCIAL_TRANSACTION_APP_TYP ),
FTATT	as ( select * from  PCMP.FINANCIAL_TRAN_APP_TRAN_TYP ),
FTTFR  	as ( select * from  PCMP.FINANCIAL_TRANSACTION_TYPE ),
AT		as ( select * from  PCMP.AGREEMENT_TYPE ),
UCREA   as ( select * from  PCMP.USERS ),
UUPDT	as ( select * from  PCMP.USERS )
*/
-- BUSINESS LOGIC/LOGIC LAYER
/* Version #  1		 	:  	(Prod Release date 06/13/2017 ) */

/* Table Description 		: 	This new table is a replacement for the Existing View (DW_REPORT.V_DW_CLAIM_FINANCIAL_TRAN_APP). 
					The performance of the query be always below par from the View due to large volume of the data. 
					There are no changes to the Existing fields, however Create/Update Users Login name, agreement type, 
					Financial Transaction type  and Financial application Transactions table fields has been added to the table. .*/

/* Source Tables 		:   	PCMP.CLAIM_FINANCIAL_TRAN_APP
					PCMP.FINANCIAL_TRANSACTION_APP_TYP
				 	PCMP.FINANCIAL_TRAN_APP_TRAN_TYP
					PCMP.FINANCIAL_TRANSACTION_TYPE
					PCMP.AGREEMENT_TYPE
					PCMP.USERS*/						
SELECT 
       CFTA.CFTA_ID                      AS CFTA_ID
,      CFTA.CFTA_AMT                     AS CFTA_AMT
,      CFTA.CFTA_DT                      AS CFTA_DT
,      DATE(CFTA.CFTA_DT)				 AS CFTA_DATE
,      CFTA.CFT_ID_APLD_FR               AS CFT_ID_APLD_FR
,      CFTA.CFT_ID_APLD_TO               AS CFT_ID_APLD_TO
,      CFTA.CFT_ID_RVRS              	 AS CFT_ID_RVRS
,      CFTA.FTAT_ID                      AS FTAT_ID
,      CASE WHEN FTAT.FTAT_CD IS NULL THEN '-1' ELSE FTAT.FTAT_CD END    AS FTAT_CD
,      FTAT.FTAT_NM                      AS FTAT_NM
,      FTTFR.FNCL_TRAN_TYP_ID            AS FNCL_TRAN_TYP_ID_FR
,      CASE WHEN FTTFR.FNCL_TRAN_TYP_CD IS NULL THEN '-1' ELSE FTTFR.FNCL_TRAN_TYP_CD END AS FNCL_TRAN_TYP_CD_FR
,      FTTFR.FNCL_TRAN_TYP_NM            AS FNCL_TRAN_TYP_NM_FR
,      FTTTO.FNCL_TRAN_TYP_ID            AS FNCL_TRAN_TYP_ID_TO
,      CASE WHEN FTTTO.FNCL_TRAN_TYP_CD IS NULL THEN '-1' ELSE  FTTTO.FNCL_TRAN_TYP_CD END  AS FNCL_TRAN_TYP_CD_TO
,      FTTTO.FNCL_TRAN_TYP_NM            AS FNCL_TRAN_TYP_NM_TO
,	   CFTA.CFTA_SENT_DT 				 AS CFTA_SENT_DT
,      CFTA.CFTA_GNRL_LDGR_SENT_IND		AS CFTA_GNRL_LDGR_SENT_IND
,	   CFTA.CFTA_ORIG_APP_IND			AS CFTA_ORIG_APP_IND
,  		CASE WHEN FTAT.AGRE_TYP_CD IS NULL THEN '-1' ELSE  FTAT.AGRE_TYP_CD END AS FTAT_AGRE_TYP_CD
, 		AT.AGRE_TYP_NM					AS FTAT_AGRE_TYP_NM
,  		FTAT.FTAT_GNRL_LDGR_IND			AS FTAT_GNRL_LDGR_IND
,		FTTFR.FNCL_TRAN_TYP_GNRL_LDGR_IND				AS FNCL_TRAN_TYP_GNRL_LDGR_IND_FR 
, 		FTTTO.FNCL_TRAN_TYP_GNRL_LDGR_IND				AS FNCL_TRAN_TYP_GNRL_LDGR_IND_TO 
, 		CFTA.AUDIT_USER_ID_CREA							AS AUDIT_USER_ID_CREA
, 		UCREA.USER_LGN_NM							AS AUDIT_CREATE_USER_LOGIN_NAME
,		CFTA.AUDIT_USER_CREA_DTM				AS AUDIT_USER_CREA_DTM
,		CFTA.AUDIT_USER_ID_UPDT					AS AUDIT_USER_ID_UPDT
,		UUPDT.USER_LGN_NM						AS AUDIT_UPDATE_USER_LOGIN_NAME
,		CFTA.AUDIT_USER_UPDT_DTM				AS AUDIT_USER_UPDT_DTM
,		CURRENT_DATE									AS DW_CREATE_DTM
,		CURRENT_DATE									AS DW_UPDATE_DTM
FROM 	CFTA
LEFT JOIN FTAT 				ON CFTA.FTAT_ID = FTAT.FTAT_ID AND FTAT.VOID_IND = 'n' AND FTAT.AGRE_TYP_CD = 'clm'   /*( Added filter 10/03/2017 prod release) */ 
LEFT JOIN FTATT 			ON FTAT.FTAT_ID = FTATT.FTAT_ID AND FTATT.VOID_IND = 'n' AND FTATT.AGRE_TYP_CD = 'clm' /*( Added filter 10/03/2017 prod release) */ 
LEFT JOIN FTTFR 			ON FTATT.FNCL_TRAN_TYP_ID_APLD_FR = FTTFR.FNCL_TRAN_TYP_ID /*AND FTTFR.VOID_IND = 'n' (Commented  filter 10/03/2017 prod release) */ 
LEFT JOIN FTTFR as  FTTTO 	ON FTATT.FNCL_TRAN_TYP_ID_APLD_TO = FTTTO.FNCL_TRAN_TYP_ID /*AND FTTTO.VOID_IND = 'n' (Commented  filter 10/03/2017 prod release)*/ 
LEFT JOIN  AT 	 			ON FTAT.AGRE_TYP_CD = AT.AGRE_TYP_CD AND AT.AGRE_TYP_VOID_IND = 'n'
LEFT JOIN  UCREA 			ON CFTA.AUDIT_USER_ID_CREA = UCREA.USER_ID
LEFT JOIN  UUPDT 			ON CFTA.AUDIT_USER_ID_UPDT = UUPDT.USER_ID
