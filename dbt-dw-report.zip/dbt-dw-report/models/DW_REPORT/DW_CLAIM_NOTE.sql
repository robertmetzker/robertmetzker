--SRC_LAYER
WITH
ADL         as (select * from {{ source('PCMP','APPLICATION_DETAIL_LEVEL') }} ),
CLAIM       as (select * from {{ source('PCMP','CLAIM') }} ),
DRMTD       as (select * from {{ source('DW_REPORT','DW_REPORT_MSTR_TYPCODE_DIM') }} ),
NADL        as (select * from {{ source('PCMP','NOTE_APPLICATION_DETAIL_LEVEL') }} ),
NCAT        as (select * from {{ source('PCMP','NOTE_CALL_TYPE') }} ),
NCFT        as (select * from {{ source('PCMP','NOTE_CALL_FROM_TYPE') }} ),
NOTE        as (select * from {{ source('PCMP','NOTE') }} ),
NT          as (select * from {{ source('PCMP','NOTE_TEXT') }} ),
NTP         as (select * from {{ source('PCMP','NOTE_TYPE') }} )

/*
ADL         as (select * from PCMP.APPLICATION_DETAIL_LEVEL),
CLAIM       as (select * from PCMP.CLAIM),
DRMTD       as (select * from DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM),
NADL        as (select * from PCMP.NOTE_APPLICATION_DETAIL_LEVEL),
NCAT        as (select * from PCMP.NOTE_CALL_TYPE),
NCFT        as (select * from PCMP.NOTE_CALL_FROM_TYPE),
NOTE        as (select * from PCMP.NOTE),
NT          as (select * from PCMP.NOTE_TEXT),
NTP         as (select * from PCMP.NOTE_TYPE)

*/

--BUSINESS/LOGIC LAYER
/* Prod release Prod Release date 09/22/2017  */
/* Added phone note details for SP#1251 8/2019 */
    
  /* Source Tables 		: 
          PCMP.NOTE
 				  PCMP.NOTE_APPLICATION_DETAIL_LEVEL
				  PCMP.CLAIM
				  PCMP.APPLICATION_DETAIL_LEVEL
				  PCMP.NOTE_TEXT
				  PCMP.NOTE_TYPE
				  PCMP.NOTE_CALL_TYPE
				  PCMP.NOTE_CALL_FROM_TYPE
    */
								 
/* L1 Dependency 		: 	DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM */
  SELECT 
       NOTE.NOTE_ID                      AS NOTE_ID
,      NADL.AGRE_ID_DRV              AS CLM_AGRE_ID
,      CLAIM.CLM_NO                      AS CLM_NO
,      CASE WHEN NOTE.NOTE_CTG_TYP_CD IS NULL THEN '-1' ELSE NOTE.NOTE_CTG_TYP_CD END    AS NOTE_CTG_TYP_CD
,      NCT.SRC_CODE_TEXT                 AS  NOTE_CTG_TYP_NM  
,      NOTE.NOTE_SBJ_TEXT                AS  NOTE_SBJ_TEXT
,      NOTE.NOTE_HI_PRTY_IND             AS     NOTE_HI_PRTY_IND
,      NOTE.NOTE_NO_PRNT_IND             AS     NOTE_NO_PRNT_IND
,      NOTE.NOTE_PUB_IND                 AS  NOTE_PUB_IND
,      NOTE.NOTE_CNFDTL_IND       AS     NOTE_CNFDTL_IND
,      NOTE.NOTE_EDI_REF_NO       AS     NOTE_EDI_REF_NO
,      NOTE.AUDIT_USER_ID_CREA           AS     NOTE_AUDIT_USER_ID_CREA
,      NOTE.AUDIT_USER_CREA_DTM   AS     NOTE_AUDIT_USER_CREA_DTM
,      NOTE.AUDIT_USER_ID_UPDT           AS     NOTE_AUDIT_USER_ID_UPDT
,      NOTE.AUDIT_USER_UPDT_DTM   AS     NOTE_AUDIT_USER_UPDT_DTM
,      NADL.NOTE_APP_DTL_LVL_ID   AS     NOTE_APP_DTL_LVL_ID
,      CASE WHEN NADL.APP_DTL_LVL_CD IS NULL THEN '-1' ELSE NADL.APP_DTL_LVL_CD END      AS        APP_DTL_LVL_CD
,      ADL.APP_DTL_LVL_NM                          AS APP_DTL_LVL_NM
,      NADL.NOTE_APP_DTL_LVL_DISP_TXT    AS NOTE_APP_DTL_LVL_DISP_TXT
,      NT.NOTE_TEXT_ID                                 AS NOTE_TEXT_ID
,      NT.NOTE_TEXT_NO                                 AS NOTE_TEXT_NO
,      NT.NOTE_TEXT_TEXT                        AS NOTE_TEXT_TEXT
,      NT.AUDIT_USER_ID_CREA                    AS TEXT_AUDIT_USER_ID_CREA
,      NT.AUDIT_USER_CREA_DTM                   AS TEXT_AUDIT_USER_CREA_DTM
,      NT.AUDIT_USER_ID_UPDT                    AS TEXT_AUDIT_USER_ID_UPDT
,      NT.AUDIT_USER_UPDT_DTM                   AS TEXT_AUDIT_USER_UPDT_DTM
,      CURRENT_DATE                                         AS DW_CREATE_DTM
,      CURRENT_DATE                                                AS DW_UPDATE_DTM
,      CASE WHEN NOTE.NOTE_TYP_CD IS NULL THEN '-1' ELSE NOTE.NOTE_TYP_CD 	END AS 	NOTE_TYP_CD
,      NTP.NOTE_TYP_NM 	AS 	NOTE_TYP_NM
,      CASE WHEN NOTE.NOTE_CALL_TYP_CD IS NULL THEN '-1' ELSE NOTE.NOTE_CALL_TYP_CD	END AS	NOTE_CALL_TYP_CD
,      NCAT.NOTE_CALL_TYP_NM	AS	NOTE_CALL_TYP_NM
,      CASE WHEN NOTE.NOTE_CALL_FR_TYP_CD IS NULL THEN '-1' ELSE NOTE.NOTE_CALL_FR_TYP_CD	END AS	NOTE_CALL_FR_TYP_CD
,      NCFT.NOTE_CALL_FR_TYP_NM	AS	NOTE_CALL_FR_TYP_NM
,      NOTE.NOTE_CLLR_PRSN_NM	AS	NOTE_CLLR_PRSN_NM
FROM NOTE 
JOIN NADL 
  ON NOTE.NOTE_ID = NADL.NOTE_ID
LEFT JOIN CLAIM 
  ON CLAIM.AGRE_ID = NADL.AGRE_ID_DRV
LEFT  JOIN (SELECT * FROM DRMTD  WHERE SRC_TBL_NAME = 'NOTE_CATEGORY_TYPE') NCT 
  ON NOTE.NOTE_CTG_TYP_CD = NCT.SRC_CODE
LEFT  JOIN ADL  
  ON NADL.APP_DTL_LVL_CD = ADL.APP_DTL_LVL_CD
LEFT  JOIN  NT  
  ON NOTE.NOTE_ID = NT.NOTE_ID AND NT.NOTE_TEXT_NO = 1 AND NT.NOTE_TEXT_VOID_IND = 'n'
LEFT  JOIN NTP  
  ON NOTE.NOTE_TYP_CD = NTP.NOTE_TYP_CD AND NTP.NOTE_TYP_VOID_IND = 'n'
LEFT  JOIN NCAT 
  ON NOTE.NOTE_CALL_TYP_CD = NCAT.NOTE_CALL_TYP_CD AND NCAT.NOTE_CALL_TYP_VOID_IND = 'n'
LEFT  JOIN NCFT 
  ON NOTE.NOTE_CALL_FR_TYP_CD = NCFT.NOTE_CALL_FR_TYP_CD AND NCFT.NOTE_CALL_FR_TYP_VOID_IND = 'n'
WHERE NOTE.APP_DTL_LVL_CD LIKE '%Claim%'
  AND   NOTE.NOTE_VOID_IND = 'n'
  AND   NADL.NOTE_APP_DTL_LVL_VOID_IND = 'n'
  AND   CLAIM.CLM_REL_SNPSHT_IND = 'n'
  AND   ADL.APP_DTL_LVL_VOID_IND = 'n'