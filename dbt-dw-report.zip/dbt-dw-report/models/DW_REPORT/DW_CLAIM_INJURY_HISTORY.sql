--SRC_LAYER
WITH
C      as (select * from {{ source('PCMP','CLAIM') }} ),
CSH    as (select * from {{ source('PCMP','CLAIM_ICD_STATUS_HISTORY') }} ), 
ICD    as (select * from {{ source('PCMP','ICD') }} ),
IR     as (select * from {{ source('DW_REPORT','DW_ICD_REFERENCE') }} ), 
ILT    as (select * from {{ source('PCMP','ICD_LOCATION_TYPE') }} ), 
IST    as (select * from {{ source('PCMP','ICD_STATUS_TYPE') }} ), 
IT     as (select * from {{ source('PCMP','ICD_SITE_TYPE') }} ), 
OI     as (select * from {{ source('BWCODS','TDDOIFM') }} ), 
BLI    as (select * from {{ source('BWCODS','TDDOBLI') }} ),
SCRBD  as (select * from {{ source('BWCODS','THFIJDT_SCRBD') }} ),


/*
C      as (select * from PCMP.CLAIM ),
CSH    as (select * from PCMP.CLAIM_ICD_STATUS_HISTORY ), 
ICD    as (select * from PCMP.ICD ),
IR     as (select * from DW_REPORT.DW_ICD_REFERENCE ), 
ILT    as (select * from PCMP.ICD_LOCATION_TYPE ), 
IST    as (select * from PCMP.ICD_STATUS_TYPE ), 
IT     as (select * from PCMP.ICD_SITE_TYPE ), 
OI     as (select * from BWCODS.TDDOIFM ), 
BLI    as (select * from BWCODS.TDDOBLI ),
SCRBD  as (select * from BWCODS.THFIJDT_SCRBD ),
*/


--BUSINESS RULES/LOGIC LAYER
/* Prod release:  Prod Release date May 2019 
 06_17_2019 - Below changes are made as per Prod Issue raised by Arnold.
               1.  ICD_CODE - For both PS and DB2 rows.
               2.  ICD_LOC_TYP_CD - For both PS and DB2 rows.
               3.  ICD_SITE_TYP_CD - For both PS and DB2 rows.
               4.  ICD_STS_TYP_CD - For both PS and DB2 rows.
               5.  ICD_LOC_TYP_NM - For PS rows only.
               6.  OBLC_BDY_LCTN_CODE - For both PS and DB2 rows.
               7.  OBLC_BDY_LCTN_TEXT - For both PS and DB2 rows.
               8   THFIJDT.BODY_LCTN_IND - For Db2 rows only.
  */
    
/* Source Tables : PCMP.CLAIM 
                                  PCMP.CLAIM_ICD_STATUS_HISTORY
                                  PCMP.ICD
                                  PCMP.ICD_LOCATION_TYPE
                                  PCMP.ICD_STATUS_TYPE
                                  PCMP.ICD_SITE_TYPE
                                  BWCODS.TDDOIFM
                                  BWCODS.TDDOBLI
                                  BWCODS.THFIJDT_SCRBD */
                                                       

/* L1 Dependency           :      DW_REPORT.DW_ICD_REFERENCE */


-- SELECT DISTINCT OBLC_BDY_LCTN_TEXT FROM  DW_REPORT.DW_CLAIM_INJURY_HISTORY;

-- Step 1: Temp Table for Powersuite rows only
CLAIM_INJURY_HISTORY_PS  AS 
(
SELECT distinct 
       C.CLM_NO
       ,CSH.AGRE_ID
       ,CSH.CLM_ICD_STS_ID
       ,CSH.CLM_ICD_STS_PRI_IND
       ,IR.ICD_CODE
       ,CASE WHEN OI.ICDC_MPD_CODE IS NULL THEN IR.ICD_CODE ELSE TRIM(OI.ICDC_MPD_CODE) END ICDC_MPD_CODE
       ,IR.ICDV_CODE
       ,IR.ICD_VER_NO
       ,'ICD-9' ICDV_MPD_VRSN_CODE
       ,IR.ICD_DESC
       ,CSH.CLM_ICD_DESC
       ,CASE WHEN UPPER(SUBSTR(CSH.ICD_LOC_TYP_CD , 1,1))='C' THEN NULL ELSE UPPER(SUBSTR(CSH.ICD_LOC_TYP_CD , 1,1)) END ICD_LOC_TYP_IND
       ,CSH.ICD_LOC_TYP_CD
       ,CASE WHEN ILT.ICD_LOC_TYP_NM ='' THEN NULL ELSE ILT.ICD_LOC_TYP_NM END AS ICD_LOC_TYP_NM
       ,CSH.ICD_SITE_TYP_CD
       ,IT.ICD_SITE_TYP_NM
       ,CSH.ICD_STS_TYP_CD
       ,IST.ICD_STS_TYP_NM
       ,CSH.HIST_EFF_DTM
       ,CSH.HIST_END_DTM
       ,IR.ICD_CTRPH_IND
       ,IR.PSYCH_ICD_FLAG
       ,IR.ICD_PSC_FLAG
       ,'PS' AS SOURCE
       ,CURRENT_DATE AS DW_CREATE_DTTM
       ,CURRENT_DATE AS DW_UPDATE_DTTM
       ,CASE WHEN CSH.HIST_END_DTM IS NULL THEN 'y' else 'n' end CRNT_CLAIM_INJURY_FLAG
       ,CSH.HIST_ID
       ,CSH.AUDIT_USER_ID_CREA
       ,CSH.AUDIT_USER_CREA_DTM
       ,CSH.AUDIT_USER_ID_UPDT
       ,CSH.AUDIT_USER_UPDT_DTM
       ,CSH.VOID_IND
       ,CASE WHEN TRIM(OB.OBLC_BDY_LCTN_CODE) = '' THEN NULL ELSE TRIM(OB.OBLC_BDY_LCTN_CODE) END OBLC_BDY_LCTN_CODE
       ,CASE WHEN TRIM(OB.OBLC_BDY_LCTN_TEXT) = ' ' THEN NULL ELSE TRIM(OB.OBLC_BDY_LCTN_TEXT) END OBLC_BDY_LCTN_TEXT
FROM  C
       JOIN  CSH 
              ON C.AGRE_ID = CSH.AGRE_ID 
       JOIN  ICD 
              on CSH.ICD_ID = ICD.ICD_ID
       JOIN IR 
              ON ICD.ICD_CD = IR.ICD_CODE AND ICD.ICD_VER_CD = IR.ICD_VER_NO
       LEFT JOIN ILT 
              ON CSH.ICD_LOC_TYP_CD = ILT.ICD_LOC_TYP_CD
       LEFT JOIN IST 
              ON CSH.ICD_STS_TYP_CD = IST.ICD_STS_TYP_CD 
       LEFT JOIN IT 
              ON CSH.ICD_SITE_TYP_CD = IT.ICD_SITE_TYP_CD
       LEFT JOIN OI 
              ON TRIM(OI.ICDC_PRMRY_CODE) = TRIM(IR.ICD_CODE) and OI.OIFM_CRNT_MAX_FLAG = 'Y'
       LEFT JOIN (select distinct trim(ICDC_CODE) as ICDC_CODE,  NULL as OBLC_BDY_LCTN_CODE, NULL as OBLC_BDY_LCTN_TEXT
                            from BLI   where ICDC_CODE  in 
                                   (
                                          select ICDC_CODE
                                           from BLI 
                                           WHERE OBLI_VRSN_END_DATE > CURRENT_DATE 
                                           group by ICDC_CODE 
                                           having count(distinct OBLC_BDY_LCTN_CODE) > 1
                                   )
                            UNION ALL
                            select distinct trim(ICDC_CODE) as ICDC_CODE, OBLC_BDY_LCTN_CODE, OBLC_BDY_LCTN_TEXT
                            from BLI  
                            where ICDC_CODE  in 
                                   (
                                          select ICDC_CODE from BLI  
                                          WHERE OBLI_VRSN_END_DATE > CURRENT_DATE 
                                          group by ICDC_CODE 
                                          having count(distinct OBLC_BDY_LCTN_CODE) = 1
                                   )
       ) OB 
              ON TRIM(IR.ICD_CODE) = TRIM(OB.ICDC_CODE)
       WHERE C.CLM_REL_SNPSHT_IND = 'n'
), 

-- Step 2: Temp Table for NON - Powersuite rows only. The source for this temp table is BWCODS.THFIJDT_SCRBD ,this table is already loaded in Production and is Frozen.
CLAIM_INJURY_HISTORY_DB2  AS 
(
   SELECT 
       THFIJDT.CLAIM_NO  AS CLM_NO
       ,  THFIJDT.CLAIM_AGRE_ID AS AGRE_ID
       ,  THFIJDT.PS_CLM_ICD_STS_ID AS CLM_ICD_STS_ID
       ,  NULL AS CLM_ICD_STS_PRI_IND
       ,  THFIJDT.ICD_CODE AS ICD_CODE
       ,  THFIJDT.ICDC_MPD_CODE AS ICDC_MPD_CODE
       ,  THFIJDT.ICDV_CODE  AS ICDV_CODE
       ,  SUBSTRING(   THFIJDT.ICDV_CODE,5,2) AS ICD_VER_NO
       ,  THFIJDT.ICDV_MPD_CODE AS ICDV_MPD_VRSN_CODE
       ,  THFIJDT.ICD_DESC AS ICD_DESC
       ,  THFIJDT.ICD_DESC AS CLM_ICD_DESC
       ,  CASE WHEN THFIJDT.BODY_LCTN_IND = '' THEN NULL ELSE THFIJDT.BODY_LCTN_IND END  AS ICD_LOC_TYP_IND
       ,   CASE     WHEN  THFIJDT.BODY_LCTN_IND = 'L' THEN 'left'
                            WHEN  THFIJDT.BODY_LCTN_IND = 'R' THEN 'right'
                            WHEN  THFIJDT.BODY_LCTN_IND = 'l' THEN 'bilateral'
                            ELSE '-1'
              END AS ICD_LOC_TYP_CD
       ,  CASE      WHEN  THFIJDT.BODY_LCTN_IND = 'L' THEN 'Left'
                            WHEN  THFIJDT.BODY_LCTN_IND = 'R' THEN 'Right'
                            WHEN  THFIJDT.BODY_LCTN_IND = 'l' THEN 'Bilateral'
                            ELSE NULL
              END AS ICD_LOC_TYP_NM
       ,  THFIJDT.PS_ICD_SITE_TYPE_CODE AS ICD_SITE_TYP_CD
       ,  THFIJDT.PS_ICD_SITE_TYPE_NAME AS ICD_SITE_TYP_NM
       ,  THFIJDT.PS_ICD_STS_TYPE_CODE AS ICD_STS_TYP_CD
       ,  THFIJDT.PS_ICD_STS_TYPE_NAME AS ICD_STS_TYP_NM
       ,  THFIJDT.INJRY_DTL_BGN_DATE AS HIST_EFF_DTM
       ,  THFIJDT.INJRY_DTL_END_DATE AS HIST_END_DTM
       ,  LOWER(THFIJDT.CTSTR_FLAG) AS ICD_CTRPH_IND
       ,  LOWER(THFIJDT.PSYCH_FLAG) AS PSYCH_ICD_FLAG
       ,  LOWER(THFIJDT.ICD_PSC_FLAG) AS ICD_PSC_FLAG
       ,  'DB2'     AS SOURCE
       ,      CURRENT_DATE AS DW_CREATE_DTTM
       ,      CURRENT_DATE AS DW_UPDATE_DTTM
       ,   'n' AS CRNT_CLAIM_INJURY_FLAG
       ,      0     AS HIST_ID
       ,      -1 AS AUDIT_USER_ID_CREA
       ,    NULL::date AS AUDIT_USER_CREA_DTM
       ,      -1 AS AUDIT_USER_ID_UPDT
       ,      NULL::date AS AUDIT_USER_UPDT_DTM
       ,      'n' AS VOID_IND
       ,   TDDOBLI.OBLC_BDY_LCTN_CODE AS OBLC_BDY_LCTN_CODE
       ,   TDDOBLI.OBLC_BDY_LCTN_TEXT AS OBLC_BDY_LCTN_TEXT
FROM SCRBD THFIJDT
       LEFT OUTER JOIN 
              (
                     select distinct trim(ICDC_CODE) AS ICDC_CODE, trim(ICDV_CODE), NULL as OBLC_BDY_LCTN_CODE, NULL as OBLC_BDY_LCTN_TEXT 
                     from BLI
                     where ICDC_CODE  in 
                            (
                                   select ICDC_CODE 
                                   from BLI 
                                   where OBLI_CRNT_MAX_FLAG = 'Y' 
                                   group by ICDC_CODE 
                                   having count(distinct OBLC_BDY_LCTN_CODE) > 1
                            )
                     UNION ALL
                     select distinct trim(ICDC_CODE) AS ICDC_CODE, trim(ICDV_CODE), OBLC_BDY_LCTN_CODE, OBLC_BDY_LCTN_TEXT 
                     from BLI
                     where ICDC_CODE  in 
                            (
                                   select ICDC_CODE 
                                   from BLI 
                                   where OBLI_CRNT_MAX_FLAG = 'Y'
                                   group by ICDC_CODE 
                                   having count(distinct OBLC_BDY_LCTN_CODE) = 1
                            )         
              ) TDDOBLI
              ON THFIJDT.ICD_CODE = TRIM(TDDOBLI.ICDC_CODE)
              WHERE CRNT_STS_FLAG = 'N'
),

-- Step 3: Combining both PS and DB2 rows.
CLAIM_INJURY_HISTORY_UNIONALL  AS       
(
SELECT CLM_NO,
       AGRE_ID,
       CLM_ICD_STS_ID,
       CLM_ICD_STS_PRI_IND,
       CASE WHEN ICD_CODE IS NULL THEN '-1' ELSE ICD_CODE END AS ICD_CODE,
       ICDC_MPD_CODE,
       ICDV_CODE,
       ICD_VER_NO,
       ICDV_MPD_VRSN_CODE,
       ICD_DESC,
       CLM_ICD_DESC,
       ICD_LOC_TYP_IND,
       CASE WHEN ICD_LOC_TYP_CD IS NULL THEN '-1' ELSE ICD_LOC_TYP_CD END AS ICD_LOC_TYP_CD ,
       ICD_LOC_TYP_NM,
       CASE WHEN ICD_SITE_TYP_CD IS NULL THEN '-1' ELSE ICD_SITE_TYP_CD END AS ICD_SITE_TYP_CD ,
       ICD_SITE_TYP_NM,
       CASE WHEN ICD_STS_TYP_CD IS NULL THEN '-1' ELSE ICD_STS_TYP_CD END AS ICD_STS_TYP_CD,
       ICD_STS_TYP_NM,
       HIST_EFF_DTM,
       HIST_END_DTM,
       ICD_CTRPH_IND,
       PSYCH_ICD_FLAG,
       ICD_PSC_FLAG,
       SOURCE,
       DW_CREATE_DTTM,
       DW_UPDATE_DTTM,
       CRNT_CLAIM_INJURY_FLAG,
       HIST_ID,
       AUDIT_USER_ID_CREA,
       AUDIT_USER_CREA_DTM,
       AUDIT_USER_ID_UPDT,
       AUDIT_USER_UPDT_DTM,
       VOID_IND,
       CASE WHEN (CASE WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND THEN ICD_LOC_TYP_IND
                WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND 
                WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND ELSE TRIM(OBLC_BDY_LCTN_CODE) END) = '' THEN NULL 
                    ELSE (CASE WHEN ICD_VER_NO = 10 AND TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND  THEN ICD_LOC_TYP_IND
                    WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND 
                    WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND ELSE TRIM(OBLC_BDY_LCTN_CODE) END) 
       END  OBLC_BDY_LCTN_CODE,
       CASE WHEN (CASE WHEN ICD_VER_NO = 10 AND TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND  THEN UPPER(ICD_LOC_TYP_NM) 
             WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) 
             WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) ELSE TRIM(OBLC_BDY_LCTN_TEXT) END) = '' THEN NULL 
                    ELSE (CASE WHEN ICD_VER_NO = 10 AND TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND  THEN UPPER(ICD_LOC_TYP_NM)  
                    WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) 
                    WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) ELSE TRIM(OBLC_BDY_LCTN_TEXT) END) 
       END OBLC_BDY_LCTN_TEXT 
FROM  CLAIM_INJURY_HISTORY_PS
UNION ALL
SELECT CLM_NO,
       AGRE_ID,
       CLM_ICD_STS_ID,
       CLM_ICD_STS_PRI_IND,
       CASE WHEN ICD_CODE IS NULL THEN '-1' ELSE ICD_CODE END AS ICD_CODE,
       ICDC_MPD_CODE,
       ICDV_CODE,
       ICD_VER_NO,
       ICDV_MPD_VRSN_CODE,
       ICD_DESC,
       CLM_ICD_DESC,
       ICD_LOC_TYP_IND,
       CASE WHEN ICD_LOC_TYP_CD IS NULL THEN '-1' ELSE ICD_LOC_TYP_CD END AS ICD_LOC_TYP_CD,
       ICD_LOC_TYP_NM,
       CASE WHEN ICD_SITE_TYP_CD IS NULL THEN '-1' ELSE ICD_SITE_TYP_CD END AS ICD_SITE_TYP_CD ,
       ICD_SITE_TYP_NM,
       CASE WHEN ICD_STS_TYP_CD IS NULL THEN '-1' ELSE ICD_STS_TYP_CD END AS ICD_STS_TYP_CD ,
       ICD_STS_TYP_NM,
       HIST_EFF_DTM,
       HIST_END_DTM,
       ICD_CTRPH_IND,
       PSYCH_ICD_FLAG,
       ICD_PSC_FLAG,
       SOURCE,
       DW_CREATE_DTTM,
       DW_UPDATE_DTTM,
       CRNT_CLAIM_INJURY_FLAG,
       HIST_ID,
       AUDIT_USER_ID_CREA,
       AUDIT_USER_CREA_DTM,
       AUDIT_USER_ID_UPDT,
       AUDIT_USER_UPDT_DTM,
       VOID_IND,
       CASE WHEN (CASE WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND THEN ICD_LOC_TYP_IND
              WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND 
              WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND ELSE TRIM(OBLC_BDY_LCTN_CODE) END) = '' THEN NULL 
              ELSE (CASE WHEN ICD_VER_NO = 10 AND TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND  THEN ICD_LOC_TYP_IND
              WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND 
              WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN ICD_LOC_TYP_IND ELSE TRIM(OBLC_BDY_LCTN_CODE) END) 
       END  OBLC_BDY_LCTN_CODE,
       CASE WHEN (CASE WHEN ICD_VER_NO = 10 AND TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND  THEN UPPER(ICD_LOC_TYP_NM) 
              WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) 
              WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) ELSE TRIM(OBLC_BDY_LCTN_TEXT) END) = '' THEN NULL 
              ELSE (CASE WHEN ICD_VER_NO = 10 AND TRIM(OBLC_BDY_LCTN_CODE) <> ICD_LOC_TYP_IND  THEN UPPER(ICD_LOC_TYP_NM)  
              WHEN ICD_VER_NO = 10 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) 
              WHEN ICD_VER_NO = 9 AND  TRIM(OBLC_BDY_LCTN_CODE) IS NULL THEN UPPER(ICD_LOC_TYP_NM) ELSE TRIM(OBLC_BDY_LCTN_TEXT) END) 
       END OBLC_BDY_LCTN_TEXT 
FROM CLAIM_INJURY_HISTORY_DB2
)       

--Step 3: Union of PowerSuite and Non Powersuite rows and Inserting into main table.
select  CLM_NO,
       AGRE_ID,
       CLM_ICD_STS_ID,
       CLM_ICD_STS_PRI_IND,
       ICD_CODE,
       ICDC_MPD_CODE,
       ICDV_CODE,
       ICD_VER_NO,
       ICDV_MPD_VRSN_CODE,
       ICD_DESC,
       CLM_ICD_DESC,
       ICD_LOC_TYP_IND,
       ICD_LOC_TYP_CD ,
       ICD_LOC_TYP_NM,
       ICD_SITE_TYP_CD,
       ICD_SITE_TYP_NM,
       ICD_STS_TYP_CD,
       ICD_STS_TYP_NM,
       HIST_EFF_DTM,
       HIST_END_DTM,
       ICD_CTRPH_IND,
       PSYCH_ICD_FLAG,
       ICD_PSC_FLAG,
       SOURCE,
       DW_CREATE_DTTM,
       DW_UPDATE_DTTM,
       CRNT_CLAIM_INJURY_FLAG,
       HIST_ID,
       AUDIT_USER_ID_CREA,
       AUDIT_USER_CREA_DTM,
       AUDIT_USER_ID_UPDT,
       AUDIT_USER_UPDT_DTM,
       VOID_IND,
       OBLC_BDY_LCTN_CODE,
       CASE WHEN OBLC_BDY_LCTN_TEXT = ' ' THEN NULL 
              WHEN OBLC_BDY_LCTN_CODE = 'B' THEN 'BILATERAL'	
              ELSE OBLC_BDY_LCTN_TEXT 
       END AS OBLC_BDY_LCTN_TEXT
FROM CLAIM_INJURY_HISTORY_UNIONALL