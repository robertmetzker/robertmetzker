--SRC_LAYER
WITH
HIST    as (select * from {{ source('DW_REPORT','DW_CLAIM_INSRD_PARTICIPATION_HISTORY') }} ) 

/*
HIST    as (select * from DW_REPORT.DW_CLAIM_INSRD_PARTICIPATION_HISTORY ) 
*/

--BUSINESS LAYER/LGOIC LAYER
/* 
Version #  1		 	: (Prod Release date 04/02/2019) 
*/
/* Source Tables 		: DW_REPORT.DW_CLAIM_INSRD_PARTICIPATION_HISTORY			          
 */
/* L1 Dependency 		: 	NONE */

--\set ON_ERROR_STOP on

SELECT 
    CLM_AGRE_ID,
    CLM_NO ,
    CASE WHEN INSRD_CUST_ID = '1000042034' AND LAG(INSRD_CUST_ID) OVER (PARTITION BY CLM_AGRE_ID ORDER BY INSRD_PTCP_EFF_DATE,INSRD_PTCP_END_DATE) <> '1000042034'  THEN LAG(INSRD_CUST_ID) OVER (PARTITION BY CLM_AGRE_ID ORDER BY INSRD_PTCP_EFF_DATE,INSRD_PTCP_END_DATE)
        WHEN INSRD_CUST_ID = '1000042034' AND LEAD(INSRD_CUST_ID) OVER (PARTITION BY CLM_AGRE_ID ORDER BY INSRD_PTCP_EFF_DATE,INSRD_PTCP_END_DATE) <> '1000042034'  THEN LEAD(INSRD_CUST_ID) OVER (PARTITION BY CLM_AGRE_ID ORDER BY INSRD_PTCP_EFF_DATE,INSRD_PTCP_END_DATE)      
        ELSE INSRD_CUST_ID 
    END AS INSRD_CUST_ID ,
    CLM_OCCR_DATE ,
    CLM_PTCP_EFF_DATE ,
    CLM_ENTRY_DATE ,
    SRC_PTCP_EFF_DTM ,
    SRC_PTCP_END_DTM ,
    INSRD_PTCP_EFF_DATE ,
    INSRD_PTCP_END_DATE ,
    CRNT_INSRD_PTCP_IND ,
    DW_CREATE_DTM ,
    DW_UPDATE_DTM ,
    CASE WHEN INSRD_CUST_ID = '1000042034' THEN 'y' ELSE 'n' 
    END AS  DUMMY_IND ,
    PSD_PLCY_NO
FROM HIST 
WHERE CLM_NO NOT IN 
    (
            SELECT CLM_NO 
            FROM HIST
            WHERE CLM_NO IN 
            (
                SELECT A.CLM_NO FROM 
                    (
                        select CLM_NO,count(*) 
                        from HIST 
                        group by 1 having count(*) = 1
                    ) A
            ) 
            AND INSRD_CUST_ID = '1000042034')
UNION
SELECT 
    CLM_AGRE_ID,
    CLM_NO ,
    INSRD_CUST_ID ,
    CLM_OCCR_DATE ,
    CLM_PTCP_EFF_DATE ,
    CLM_ENTRY_DATE ,
    SRC_PTCP_EFF_DTM ,
    SRC_PTCP_END_DTM ,
    INSRD_PTCP_EFF_DATE ,
    INSRD_PTCP_END_DATE ,
    CRNT_INSRD_PTCP_IND ,
    DW_CREATE_DTM ,  
    DW_UPDATE_DTM ,
    'n'  AS  DUMMY_IND ,
    PSD_PLCY_NO
FROM HIST  
WHERE CLM_NO IN 
    (
        SELECT A.CLM_NO FROM 
            (
                select CLM_NO,count(*) 
                from HIST 
                group by 1 
                having count(*) = 1
            ) A
    ) 
AND INSRD_CUST_ID = '1000042034'
ORDER BY INSRD_PTCP_EFF_DATE,INSRD_PTCP_END_DATE
