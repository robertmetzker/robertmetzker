--SRC_LAYER
WITH
C       as (select * from {{ source('PCMP','CLAIM') }} ), 
CT      as (select * from {{ source('PCMP','CLAIM_CLAIM_TYPE') }} ), 
WC      as (select * from {{ source('PCMP','WC_CLAIM') }} ),  
I       as (select * from {{ source('PCMP','INJURY_TYPE') }} )

/*
C       as (select * from PCMP.CLAIM ), 
CT      as (select * from PCMP.CLAIM_CLAIM_TYPE ), 
WC      as (select * from PCMP.WC_CLAIM ),  
I       as (select * from PCMP.INJURY_TYPE )
*/

--BUSINESS LAYER/LOGIC LAYER
-- TRUNCATE AND INSERT ROWS

SELECT
    ROW_NUMBER() OVER( order by c.AGRE_ID ) AS INJURY_TYPE_ID,
    C.AGRE_ID,
    CASE
        WHEN CT.CLM_TYP_CD IS NULL THEN '-1' ELSE CT.CLM_TYP_CD END CLM_TYP_CD,
    CASE WHEN WC.INJR_TYP_CD IS NULL THEN '-1' ELSE WC.INJR_TYP_CD END INJR_TYP_CD,
    I.INJR_TYP_NM,
    I.INJR_TYP_SEV,
    CASE WHEN I.JUR_TYP_CD IS NULL THEN '-1' ELSE I.JUR_TYP_CD END JUR_TYP_CD,
    I.NCCI_INJR_TYP_ID,
    CASE WHEN I.WCSTAT_INJR_TYP_CD IS NULL THEN '-1' ELSE I.WCSTAT_INJR_TYP_CD END WCSTAT_INJR_TYP_CD,
    CURRENT_DATE AS DW_CREATE_DTTM,
    CURRENT_DATE AS DW_UPDATE_DTTM
FROM
    C 
    LEFT JOIN CT 
        ON C.AGRE_ID = CT.AGRE_ID 
    left JOIN  WC 
        ON C.AGRE_ID = WC.AGRE_ID 
    LEFT JOIN  I  
        ON WC.INJR_TYP_CD = I.INJR_TYP_CD 
        AND I.VOID_IND = 'n'
WHERE C.CLM_REL_SNPSHT_IND = 'n' 
