--SRC_LAYER
WITH
CPP     as ( select * from {{ source('PCMP','CLAIM_PARTICIPATION_PAYEE') }} ),
PAYT    as ( select * from {{ source('PCMP','PAYMENT_TYPE') }} ),
PAYST   as ( select * from {{ source('PCMP','PAYMENT_STATUS_TYPE') }} )

/*
CPP     as ( select * from PCMP.CLAIM_PARTICIPATION_PAYEE ),
PAYT    as ( select * from PCMP.PAYMENT_TYPE ),
PAYST   as ( select * from PCMP.PAYMENT_STATUS_TYPE )
*/

--\set ON_ERROR_STOP on
SELECT
    CPP.CLM_PTCP_PAYE_ID,
    CPP.CLM_PTCP_ID,
    CPP.CLM_PTCP_PAYE_EFF_DT,
    CPP.CLM_PTCP_PAYE_END_DT,
    CASE
        WHEN CPP.PAY_TYP_CD IS NULL
        THEN '-1'
        ELSE CPP.PAY_TYP_CD
    END PAY_TYP_CD,
    PAYT.PAY_TYP_NM,
    CASE
        WHEN CPP.PAY_STS_TYP_CD IS NULL
        THEN '-1'
        ELSE CPP.PAY_STS_TYP_CD
    END PAY_STS_TYP_CD,
    PAYST.PAY_STS_TYP_NM,
    CASE WHEN CPP.CLM_PTCP_PAYE_END_DT IS NULL 
            THEN 'y' 
            ELSE 'n'
    END  CRNT_IND,
    CURRENT_DATE DW_CREATE_DTTM,
    CURRENT_DATE DW_UPDATE_DTTM
FROM
    CPP 
    LEFT JOIN  PAYT
        ON CPP.PAY_TYP_CD = PAYT.PAY_TYP_CD 
    LEFT JOIN PAYST
        ON CPP.PAY_STS_TYP_CD = PAYST.PAY_STS_TYP_CD
WHERE
    CPP.VOID_IND = 'n'