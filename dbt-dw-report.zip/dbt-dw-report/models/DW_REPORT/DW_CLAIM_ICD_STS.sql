-- SRC_LAYER
WITH
CIS     as ( select * from {{ source('PCMP','CLAIM_ICD_STATUS') }} ),
ICD     as ( select * from {{ source('PCMP','ICD') }} ),
IT      as ( select * from {{ source('PCMP','ICD_TYPE') }} ),
IVT     as ( select * from {{ source('PCMP','ICD_VALIDITY_TYPE') }} ),
IST     as ( select * from {{ source('PCMP','ICD_STATUS_TYPE') }} ),
ILT     as ( select * from {{ source('PCMP','ICD_LOCATION_TYPE') }} ),
ISIT    as ( select * from {{ source('PCMP','ICD_SITE_TYPE') }} ),
IACP    as ( select * from {{ source('PCMP','ICD_ACP_ELIG_RANGE') }} )

/*
CIS     as ( select * from PCMP.CLAIM_ICD_STATUS ),
ICD     as ( select * from PCMP.ICD ),
IT      as ( select * from PCMP.ICD_TYPE ),
IVT     as ( select * from PCMP.ICD_VALIDITY_TYPE ),
IST     as ( select * from PCMP.ICD_STATUS_TYPE ),
ILT     as ( select * from PCMP.ICD_LOCATION_TYPE ),
ISIT    as ( select * from PCMP.ICD_SITE_TYPE ),
IACP    as ( select * from PCMP.ICD_ACP_ELIG_RANGE )

*/


--BUSINESS LAYER/LOGIC LAYER
SELECT
        CIS.CLM_ICD_STS_ID,
        CIS.AGRE_ID,
        CIS.ICD_ID,
        I.ICD_CD,
        CASE
            WHEN I.ICD_TYP_CD IS NULL
            THEN '-1'
            ELSE I.ICD_TYP_CD
        END ICD_TYP_CD,
        IT.ICD_TYP_NM,
        CASE
            WHEN I.ICD_VLD_TYP_CD IS NULL
            THEN '-1'
            ELSE I.ICD_VLD_TYP_CD
        END ICD_VLD_TYP_CD,
        IVT.ICD_VLD_TYP_NM,
        I.ICD_EFF_DT,
        I.ICD_END_DT,
        I.ICD_SHR_DESC,
        I.ICD_LNG_DESC,
        I.ICD_FULL_DESC,
        CASE
            WHEN CIS.ICD_STS_TYP_CD IS NULL
            THEN '-1'
            ELSE CIS.ICD_STS_TYP_CD
        END ICD_STS_TYP_CD,
        IST.ICD_STS_TYP_NM,
        CIS.CLM_ICD_STS_PRI_IND,
        CIS.ICD_STS_DT,
        CASE
            WHEN CIS.ICD_LOC_TYP_CD IS NULL
            THEN '-1'
            ELSE CIS.ICD_LOC_TYP_CD
        END ICD_LOC_TYP_CD,
        ILT.ICD_LOC_TYP_NM,
        CASE
            WHEN CIS.ICD_SITE_TYP_CD IS NULL
            THEN '-1'
            ELSE CIS.ICD_SITE_TYP_CD
        END ICD_SITE_TYP_CD,
        ISIT.ICD_SITE_TYP_NM,
        CIS.CLM_ICD_DESC,
        CIS.VOID_IND AS CLM_ICD_VOID_IND,
        I.VOID_IND AS ICD_VOID_IND,
        IACP.ICD_ACP_ELIG_RNG_STR_NO,
        IACP.ICD_ACP_ELIG_RNG_END_NO,
        IACP.ICD_ACP_ELIG_RNG_ID,
        CIS.AUDIT_USER_ID_CREA,
        CIS.AUDIT_USER_CREA_DTM,
        CIS.AUDIT_USER_ID_UPDT,
        CIS.AUDIT_USER_UPDT_DTM,
        CURRENT_DATE AS DW_CREATE_DTTM,
        CURRENT_DATE AS DW_UPDATE_DTTM,
        CASE
            WHEN I.ICD_VER_CD IS NULL
            THEN '-1'
            ELSE I.ICD_VER_CD
        END ICD_VER_CD
FROM
    CIS 
    LEFT JOIN ICD I
        ON CIS.ICD_ID = I.ICD_ID
            AND I.VOID_IND = 'n' 
    LEFT JOIN IT
        ON I.ICD_TYP_CD = IT.ICD_TYP_CD 
    LEFT JOIN IVT
        ON I.ICD_VLD_TYP_CD = IVT.ICD_VLD_TYP_CD 
    LEFT JOIN IST
        ON IST.ICD_STS_TYP_CD = CIS.ICD_STS_TYP_CD 
    LEFT JOIN ILT
        ON ILT.ICD_LOC_TYP_CD = CIS.ICD_LOC_TYP_CD 
    LEFT JOIN ISIT
        ON ISIT.ICD_SITE_TYP_CD = CIS.ICD_SITE_TYP_CD 
    LEFT JOIN IACP
        ON I.ICD_ID = IACP.ICD_ACP_ELIG_RNG_ID
WHERE   CIS.VOID_IND = 'n'