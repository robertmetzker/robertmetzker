{{ config(materialized='table', transient=false ) }}

-- SRC_LAYER
WITH
CRAG    as ( select * from {{ source('PCMP','CALCULATION_RESULT_ATTR_GRP') }} ), 
CRAGT   as ( select * from {{ source('PCMP','CALCULATION_RSLT_ATTR_GRP_TYP') }} ),
CRA     as ( select * from {{ source('PCMP','CALCULATION_RESULT_ATTRIBUTE') }} ),
CRAT    as ( select * from {{ source('PCMP','CALCULATION_RESULT_ATTR_TYP') }} ),
CRT     as ( select * from {{ source('PCMP','CALCULATION_RESULT_TYPE') }} )

/* 
CRAG    as ( select * from PCMP.CALCULATION_RESULT_ATTR_GRP ), 
CRAGT   as ( select * from PCMP.CALCULATION_RSLT_ATTR_GRP_TYP ),
CRA     as ( select * from PCMP.CALCULATION_RESULT_ATTRIBUTE CRA ),
CRAT    as ( select * from PCMP.CALCULATION_RESULT_ATTR_TYP ),
CRT     as ( select * from PCMP.CALCULATION_RESULT_TYPE )
*/

-- LOGIC_LAYER
SELECT  DISTINCT 
        CRAG.CALC_RSLT_ATTR_GRP_ID,
        CRAG.CALC_RSLT_ATTR_GRP_SEQ_NO,
        CRAG.CALC_RSLT_ID,
        CASE
            WHEN CRT.CALC_RSLT_TYP_CD IS NULL
            THEN '-1'
            ELSE CRT.CALC_RSLT_TYP_CD
        END CALC_RSLT_TYP_CD,
        CRT.CALC_RSLT_TYP_NM,
        CASE
            WHEN CRAG.CALC_RSLT_ATTR_GRP_TYP_CD IS NULL
            THEN '-1'
            ELSE CRAG.CALC_RSLT_ATTR_GRP_TYP_CD
        END CALC_RSLT_ATTR_GRP_TYP_CD,
        CRAGT.CALC_RSLT_ATTR_GRP_TYP_NM,
        CRA.CALC_RSLT_ATTR_TEXT_VAL,
        CASE
            WHEN CRA.CALC_RSLT_ATTR_TYP_CD IS NULL
            THEN '-1'
            ELSE CRA.CALC_RSLT_ATTR_TYP_CD
        END CALC_RSLT_ATTR_TYP_CD,
        CRAT.CALC_RSLT_ATTR_TYP_NM,
        CURRENT_DATE DW_CREATE_DTTM,
        CURRENT_DATE DW_UPDATE_DTTM
      FROM
          CRAG 
        LEFT OUTER JOIN CRAGT
              ON CRAG.CALC_RSLT_ATTR_GRP_TYP_CD = CRAGT.CALC_RSLT_ATTR_GRP_TYP_CD
              AND CRAGT.VOID_IND = 'n' 
        LEFT OUTER JOIN CRA
              ON CRAG.CALC_RSLT_ATTR_GRP_ID = CRA.CALC_RSLT_ATTR_GRP_ID
              AND CRAG.CALC_RSLT_ATTR_GRP_SEQ_NO = CRA.CALC_RSLT_ATTR_GRP_SEQ_NO 
        LEFT OUTER JOIN CRAT
              ON CRA.CALC_RSLT_ATTR_TYP_CD = CRAT.CALC_RSLT_ATTR_TYP_CD
              AND CRAT.VOID_IND = 'n' 
        LEFT OUTER JOIN CRT
              ON CRT.CALC_RSLT_TYP_CD = CRAGT.CALC_RSLT_TYP_CD
            AND CRT.VOID_IND = 'n'