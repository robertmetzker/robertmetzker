{{ config(materialized='table', transient=false ) }}

-- SRC_LAYER
WITH
ACT     as (select * from {{ source('PCMP','APPLICATION_CONTEXT_TYPE') }} ),		
ADT     as (select * from {{ source('PCMP','APPLICATION_DATA_TYPE') }}  ),			
AST     as (select * from {{ source('PCMP','APPLICATION_SUB_CONTEXT_TYPE') }}  ),		
C		as (select * from {{ source('PCMP','CASES') }} ),
CCT     as (select * from {{ source('PCMP','CASE_CATEGORY_TYPE') }}  ),		
CDERT   as (select * from {{ source('PCMP','CASE_DETAIL_EXM_REQS_TYPE') }}  ),			
CDES    as (select * from {{ source('PCMP','CASE_DETAIL_EXM_SCH') }}  ),		
CDFR    as (select * from {{ source('PCMP','CASE_DETAIL_FILE_RVW') }}  ),			
CDMM    as (select * from {{ source('PCMP','CASE_DETAIL_MEDICAL_MANAGEMENT') }}  ),
CDRT    as (select * from {{ source('PCMP','CASE_DETAIL_ADNDM_REQS_TYPE') }}  ),			
CL      as (select * from {{ source('PCMP','CASE_DETAIL_LEGAL') }}  ),
CPST    as (select * from {{ source('PCMP','CASE_PROV_SPL_TYPE') }}  ), 			
CPT     as (select * from {{ source('PCMP','CASE_PRIORITY_TYPE') }} ),	 			
CRT     as (select * from {{ source('PCMP','CASE_RESOLUTION_TYPE') }} ),
CSS		as (select * from {{ source('PCMP','CASE_STATE_STATUS') }} ),
CST     as (select * from {{ source('PCMP','CASE_SOURCE_TYPE') }}  ),		
CT		as (select * from {{ source('PCMP','CASE_TYPE') }} ),
CVL     as (select * from {{ source('PCMP','CASE_VENUE_LOCATION_TYPE') }}  ),			
CVT     as (select * from {{ source('PCMP','CASE_VENUE_TYPE') }}  ),
JT      as (select * from {{ source('PCMP','JURISDICTION_TYPE') }} ),
S		as (select * from {{ source('DW_REPORT','DW_STATUS') }} ),

/*
ACT     as (select * from PCMP.APPLICATION_CONTEXT_TYPE ),		
ADT     as (select * from PCMP.APPLICATION_DATA_TYPE  ),			
AST     as (select * from PCMP.APPLICATION_SUB_CONTEXT_TYPE  ),		
C		as (select * from PCMP.CASES ),
CCT     as (select * from PCMP.CASE_CATEGORY_TYPE  ),		
CDERT   as (select * from PCMP.CASE_DETAIL_EXM_REQS_TYPE  ),			
CDES    as (select * from PCMP.CASE_DETAIL_EXM_SCH  ),		
CDFR    as (select * from PCMP.CASE_DETAIL_FILE_RVW  ),			
CDMM    as (select * from PCMP.CASE_DETAIL_MEDICAL_MANAGEMENT  ),
CDRT    as (select * from PCMP.CASE_DETAIL_ADNDM_REQS_TYPE  ),			
CL      as (select * from PCMP.CASE_DETAIL_LEGAL  ),
CPST    as (select * from PCMP.CASE_PROV_SPL_TYPE  ), 			
CPT     as (select * from PCMP.CASE_PRIORITY_TYPE ),	 			
CRT     as (select * from PCMP.CASE_RESOLUTION_TYPE ),
CSS		as (select * from PCMP.CASE_STATE_STATUS ),
CST     as (select * from PCMP.CASE_SOURCE_TYPE  ),		
CT		as (select * from PCMP.CASE_TYPE ),
CVL     as (select * from PCMP.CASE_VENUE_LOCATION_TYPE  ),			
CVT     as (select * from PCMP.CASE_VENUE_TYPE  ),
JT      as (select * from PCMP.JURISDICTION_TYPE ),
S		as (select * from DW_REPORT.DW_STATUS ),
*/

--BUSINESS LOGIC/LOGIC LAYER
/*----------------------------------------------------------------------------------------------------------------------------------------------|
NOTE :: Updated on 11/9/2016 																													|
The column CASE_ACTN_PLN_TXT is CLOB in source (Powersuite). Since vertica doesn't support CLOB, team has decided (after discussing with		|
business) to change the data type to VARCHAR(35000) in EL1 process (that's while copying from oracle PCMP to vertica PCMP).  In DW_REPORT		|
this column has been restricted to VARCHAR(4000).  Hence in this L1 script the column has been truncated by SUBSTRING  of 4000.					|
Apart from SUBSTRING we were forced to CAST the column  as CASE_ACTN_PLN_TXT::varchar(4000) while inserting into the dw_report table. Because,	|
though it was restricted to 4000 while building the temp table, the column length was having more than 4000 and job used to fail.   
Added  4 Columns CASE_VENU_TYP_CD,CASE_VENU_TYP_NM,CDL_NTC_APL_DUE_DT,CDL_NTC_APL_FILE_DT For release 5/22/2018.
			|
------------------------------------------------------------------------------------------------------------------------------------------------*/
-- STEP1: CREATE TEMP1 TABLE TO JOIN CASES WITH SOME OF TYPE CODE TABLES 

DW_CASES_TEMP1  AS			
(
SELECT DISTINCT C.CASE_ID			
         ,C.CASE_NO			
         ,C.CASE_CNTX_ID			
         ,C.CASE_CNTX_NO			
		 ,S.STATUS_ID	
         ,C.APP_CNTX_TYP_CD			
         ,C.CASE_SRC_TYP_CD			
         ,C.CASE_CTG_TYP_CD			
         ,C.CASE_TYP_CD			
         ,C.CASE_NM			
         ,C.CASE_EXTRNL_NO			
         ,C.CASE_INT_DT			
         ,C.CASE_EFF_DT			
         ,C.CASE_DUE_DT			
         ,C.CASE_COMP_DT			
         ,C.CASE_RSN_SUM_TXT			
         ,C.USER_ID			
         ,C.CASE_PRTY_TYP_CD			
         ,C.CASE_RSOL_TYP_CD			
         ,SUBSTRING(TRIM(C.CASE_ACTN_PLN_TXT),1,4000) AS CASE_ACTN_PLN_TXT			
         ,C.AUDIT_USER_CREA_DTM 			
         ,C.AUDIT_USER_ID_CREA 			
         ,C.AUDIT_USER_ID_UPDT			
         ,C.AUDIT_USER_UPDT_DTM			
FROM  C			
	INNER JOIN   CSS ON C.CASE_ID = CSS.CASE_ID			
	INNER JOIN   S 			
		ON TRIM(CSS.CASE_STS_TYP_CD) = S.STS_TYP_CD 			
		AND TRIM(CSS.CASE_STT_TYP_CD) = S.STT_TYP_CD 			
		AND TRIM(CSS.CASE_STS_RSN_TYP_CD) = S.TRANS_RSN_TYP_CD 			
		AND S.PLCY_CLM_IND = 'CASE'			
	WHERE C.VOID_IND = 'n'
),

-- STEP2: CREATE TEMP2 TABLE TO JOIN WITH ALL TYPE CODE, CASE DETAIL AND MEDICAL MANAGEMENT TABLES 
DW_CASES_TEMP2  AS 			
(
 SELECT  DISTINCT C.CASE_ID			
         ,C.CASE_NO			
         ,C.CASE_CNTX_ID			
         ,C.CASE_CNTX_NO			
		 ,C.STATUS_ID	
         ,C.APP_CNTX_TYP_CD	
         ,ACT.APP_CNTX_TYP_NM			
         ,ACT.APP_CNTX_TYP_EXT_IND		 
         ,C.CASE_SRC_TYP_CD	
         ,CST.CASE_SRC_TYP_NM		 
         ,C.CASE_CTG_TYP_CD			
         ,CCT.CASE_CTG_TYP_NM			
         ,C.CASE_TYP_CD			
         ,CT.CASE_TYP_NM
		 ,CT.APP_DATA_TYP_CD
         ,ADT.APP_DATA_TYP_NM			
         ,ADT.APP_SUB_CNTX_TYP_CD			
         ,AST.APP_SUB_CNTX_TYP_NM
         ,C.CASE_NM			
         ,C.CASE_EXTRNL_NO			
         ,C.CASE_INT_DT			
         ,C.CASE_EFF_DT			
         ,C.CASE_DUE_DT			
         ,C.CASE_COMP_DT			
         ,C.CASE_RSN_SUM_TXT			
         ,C.USER_ID			
         ,C.CASE_PRTY_TYP_CD			
         ,CPT.CASE_PRTY_TYP_NM			
         ,CPT.CASE_PRTY_TYP_DFLT_IND
         ,C.CASE_RSOL_TYP_CD
		 ,CRT.CASE_RSOL_TYP_NM		
         ,C.CASE_ACTN_PLN_TXT			
		 ,CDFR.CDFR_RVW_RPT_RECV_DT	
		 ,CDFR.CDFR_PHYS_IMPR_RT	
		 ,CDFR.CDFR_FNL_IMPR_RT	
		 ,CDFR.CDFR_ADNDM_REQS_IND	
		 ,CDFR.CDFR_EXM_REQS_IND	
		 ,CDFR.CD_ADNDM_REQS_TYP_CD	
		 ,CDRT.CD_ADNDM_REQS_TYP_NM	
		 ,CL.CDL_ID	
		 ,CL.CASE_JUR_TYP_CD	
		 ,JT.JUR_TYP_NM	
		 ,CL.CASE_VENU_LOC_TYP_CD	
		 ,CVL.CASE_VENU_LOC_TYP_NM	
		 ,CL.CDL_NTC_HEAR_ISS_DT	
		 ,CL.CDL_NTC_HEAR_RECV_DT	
		 ,CDES.CD_EXM_REQS_TYP_CD	
		 ,CDERT.CD_EXM_REQS_TYP_NM	
		 ,CDES.CPS_TYP_CD	
		 ,CPST.CPS_TYP_NM	
		 ,CDES.CDES_ADR_TRT_REQSTR	
		 ,CDES.CDES_ADR_TRT_DSP	
         ,CDES.CDES_EXM_DT			
		 ,CDES.CDES_EXM_RPT_RECV_DT	
		 ,CDES.CDES_ADR_NO	
		 ,CDES.CDES_ADR_TYP	
		 ,CDMM.CDMM_RVW_REQS_DT	
		 ,CDMM.CDMM_RVW_REQS_BY_NM
		 ,CASE WHEN C.APP_CNTX_TYP_CD = 'claim' 	THEN C.CASE_CNTX_NO ELSE NULL END AS CASE_CLM_NO 		
		 ,CASE WHEN C.APP_CNTX_TYP_CD = 'policy' 	THEN C.CASE_CNTX_NO ELSE NULL END AS CASE_PLCY_NO 		
		 ,CASE WHEN C.APP_CNTX_TYP_CD = 'customer'  THEN C.CASE_CNTX_NO ELSE NULL END AS CASE_CUST_NO 			 
         ,C.AUDIT_USER_ID_CREA
		 ,C.AUDIT_USER_CREA_DTM 	
         ,C.AUDIT_USER_ID_UPDT			
         ,C.AUDIT_USER_UPDT_DTM			
         ,CL.AUDIT_USER_ID_CREA 	AS CL_AUDIT_USER_ID_CREA 		
		 ,CL.AUDIT_USER_CREA_DTM 	AS CL_AUDIT_USER_CREA_DTM 
         ,CL.AUDIT_USER_ID_UPDT 	AS CL_AUDIT_USER_ID_UPDT		
         ,CL.AUDIT_USER_UPDT_DTM 	AS CL_AUDIT_USER_UPDT_DTM		
		 ,CDMM.AUDIT_USER_ID_CREA  	AS CDMM_AUDIT_USER_ID_CREA 
		 ,CDMM.AUDIT_USER_CREA_DTM 	AS CDMM_AUDIT_USER_CREA_DTM 
		 ,CDMM.AUDIT_USER_ID_UPDT  	AS CDMM_AUDIT_USER_ID_UPDT
		 ,CDMM.AUDIT_USER_UPDT_DTM 	AS CDMM_AUDIT_USER_UPDT_DTM
		 ,CDFR.AUDIT_USER_ID_CREA  	AS CDFR_AUDIT_USER_ID_CREA 
		 ,CDFR.AUDIT_USER_CREA_DTM 	AS CDFR_AUDIT_USER_CREA_DTM 
		 ,CDFR.AUDIT_USER_ID_UPDT  	AS CDFR_AUDIT_USER_ID_UPDT
		 ,CDFR.AUDIT_USER_UPDT_DTM 	AS CDFR_AUDIT_USER_UPDT_DTM
         ,CDES.AUDIT_USER_ID_CREA 	AS CDES_AUDIT_USER_ID_CREA		
         ,CDES.AUDIT_USER_CREA_DTM 	AS CDES_AUDIT_USER_CREA_DTM 		
         ,CDES.AUDIT_USER_ID_UPDT 	AS CDES_AUDIT_USER_ID_UPDT		
         ,CDES.AUDIT_USER_UPDT_DTM 	AS CDES_AUDIT_USER_UPDT_DTM	
         ,CASE WHEN CL.CASE_VENU_TYP_CD IS NULL THEN '-1' ELSE CL.CASE_VENU_TYP_CD END AS CASE_VENU_TYP_CD
         ,CVT.CASE_VENU_TYP_NM 		AS CASE_VENU_TYP_NM
         , DATE(CDL_NTC_APL_DUE_DT)	AS CDL_NTC_APL_DUE_DATE
         , DATE(CDL_NTC_APL_FILE_DT) AS CDL_NTC_APL_FILE_DATE 
FROM DW_CASES_TEMP1 C			
	INNER JOIN  CT ON C.CASE_TYP_CD = CT.CASE_TYP_CD			
	LEFT OUTER JOIN   ACT ON C.APP_CNTX_TYP_CD = ACT.APP_CNTX_TYP_CD			
	LEFT OUTER JOIN   CST ON C.CASE_SRC_TYP_CD = CST.CASE_SRC_TYP_CD			
	LEFT OUTER JOIN   CCT ON C.CASE_CTG_TYP_CD = CCT.CASE_CTG_TYP_CD			
	LEFT OUTER JOIN   ADT ON CT.APP_DATA_TYP_CD = ADT.APP_DATA_TYP_CD			
	LEFT OUTER JOIN   AST ON ADT.APP_SUB_CNTX_TYP_CD = AST.APP_SUB_CNTX_TYP_CD			
	LEFT OUTER JOIN   CPT ON C.CASE_PRTY_TYP_CD = CPT.CASE_PRTY_TYP_CD 	 			
	LEFT OUTER JOIN    CL ON C.CASE_ID = CL.CASE_ID AND CL.VOID_IND = 'n'
	LEFT OUTER JOIN   CRT ON CRT.CASE_RSOL_TYP_CD = C.CASE_RSOL_TYP_CD
	LEFT OUTER JOIN    JT ON CL.CASE_JUR_TYP_CD = JT.JUR_TYP_CD 			
	LEFT OUTER JOIN   CVL ON CL.CASE_VENU_LOC_TYP_CD = CVL.CASE_VENU_LOC_TYP_CD 			
	LEFT OUTER JOIN  CDFR ON C.CASE_ID = CDFR.CASE_ID  AND CDFR.VOID_IND = 'n'			
	LEFT OUTER JOIN  CDRT ON CDFR.CD_ADNDM_REQS_TYP_CD = CDRT.CD_ADNDM_REQS_TYP_CD 			
	LEFT OUTER JOIN  CDES ON CDES.CASE_ID = C.CASE_ID AND CDES.VOID_IND = 'n'			
	LEFT OUTER JOIN  CDERT ON CDES.CD_EXM_REQS_TYP_CD = CDERT.CD_EXM_REQS_TYP_CD			
	LEFT OUTER JOIN  CPST ON CDES.CPS_TYP_CD = CPST.CPS_TYP_CD 			
	LEFT OUTER JOIN  CDMM ON C.CASE_ID = CDMM.CASE_ID AND CDMM.VOID_IND = 'n'
	LEFT OUTER JOIN   CVT ON CL.CASE_VENU_TYP_CD = CVT.CASE_VENU_TYP_CD AND CVT.VOID_IND = 'n'
)

-- STEP4: TRUNCATE THE TARGET TABLE AND INSERT THE ROWS THAT BUILT IN TEMP3 TABLE
SELECT  CASE_ID			
         ,CASE_NO			
         ,CASE_CNTX_ID			
         ,CASE_CNTX_NO			
		 ,STATUS_ID	
         ,NVL(APP_CNTX_TYP_CD,'-1') AS 	APP_CNTX_TYP_CD
         ,APP_CNTX_TYP_NM			
         ,APP_CNTX_TYP_EXT_IND		 
         ,NVL(CASE_SRC_TYP_CD,'-1') AS 	CASE_SRC_TYP_CD	
         ,CASE_SRC_TYP_NM		 
         ,NVL(CASE_CTG_TYP_CD,'-1') AS 	CASE_CTG_TYP_CD			
         ,CASE_CTG_TYP_NM			
         ,NVL(CASE_TYP_CD,'-1') AS 	CASE_TYP_CD		
         ,CASE_TYP_NM
		 ,NVL(APP_DATA_TYP_CD,'-1') AS 	APP_DATA_TYP_CD
         ,APP_DATA_TYP_NM			
         ,NVL(APP_SUB_CNTX_TYP_CD,'-1') AS 	APP_SUB_CNTX_TYP_CD		
         ,APP_SUB_CNTX_TYP_NM
         ,CASE_NM			
         ,CASE_EXTRNL_NO			
         ,CASE_INT_DT			
         ,CASE_EFF_DT			
         ,CASE_DUE_DT			
         ,CASE_COMP_DT			
         ,CASE_RSN_SUM_TXT			
         ,USER_ID			
         ,NVL(CASE_PRTY_TYP_CD,'-1') AS CASE_PRTY_TYP_CD				
         ,CASE_PRTY_TYP_NM			
         ,CASE_PRTY_TYP_DFLT_IND
         ,NVL(CASE_RSOL_TYP_CD,'-1') AS CASE_RSOL_TYP_CD	
		 ,CASE_RSOL_TYP_NM		
         ,CASE_ACTN_PLN_TXT::varchar(4000)		as CASE_ACTN_PLN_TXT
		 ,CDFR_RVW_RPT_RECV_DT	
		 ,CDFR_PHYS_IMPR_RT	
		 ,CDFR_FNL_IMPR_RT	
		 ,CDFR_ADNDM_REQS_IND	
		 ,CDFR_EXM_REQS_IND	
		 ,NVL(CD_ADNDM_REQS_TYP_CD,'-1') AS CD_ADNDM_REQS_TYP_CD		
		 ,CD_ADNDM_REQS_TYP_NM	
		 ,CDL_ID	
		 ,NVL(CASE_JUR_TYP_CD,'-1') AS 	CASE_JUR_TYP_CD
		 ,JUR_TYP_NM	
		 ,NVL(CASE_VENU_LOC_TYP_CD,'-1') AS CASE_VENU_LOC_TYP_CD		
		 ,CASE_VENU_LOC_TYP_NM	
		 ,CDL_NTC_HEAR_ISS_DT	
		 ,CDL_NTC_HEAR_RECV_DT	
		 ,NVL(CD_EXM_REQS_TYP_CD,'-1') AS CD_EXM_REQS_TYP_CD 		
		 ,CD_EXM_REQS_TYP_NM	
		 ,NVL(CPS_TYP_CD,'-1') AS CPS_TYP_CD		
		 ,CPS_TYP_NM	
		 ,CDES_ADR_TRT_REQSTR	
		 ,CDES_ADR_TRT_DSP	
         ,CDES_EXM_DT			
		 ,CDES_EXM_RPT_RECV_DT	
		 ,CDES_ADR_NO	
		 ,CDES_ADR_TYP	
		 ,CDMM_RVW_REQS_DT	
		 ,CDMM_RVW_REQS_BY_NM
		 ,CASE_CLM_NO 		
		 ,CASE_PLCY_NO 		
		 ,CASE_CUST_NO 			 
		 ,AUDIT_USER_ID_CREA
		 ,AUDIT_USER_CREA_DTM
		 ,AUDIT_USER_ID_UPDT
		 ,AUDIT_USER_UPDT_DTM
		 ,CL_AUDIT_USER_ID_CREA
		 ,CL_AUDIT_USER_CREA_DTM
		 ,CL_AUDIT_USER_ID_UPDT
		 ,CL_AUDIT_USER_UPDT_DTM
		 ,CDMM_AUDIT_USER_ID_CREA
		 ,CDMM_AUDIT_USER_CREA_DTM
		 ,CDMM_AUDIT_USER_ID_UPDT
		 ,CDMM_AUDIT_USER_UPDT_DTM
		 ,CDFR_AUDIT_USER_ID_CREA
		 ,CDFR_AUDIT_USER_CREA_DTM
		 ,CDFR_AUDIT_USER_ID_UPDT
		 ,CDFR_AUDIT_USER_UPDT_DTM
		 ,CDES_AUDIT_USER_ID_CREA
		 ,CDES_AUDIT_USER_CREA_DTM
		 ,CDES_AUDIT_USER_ID_UPDT
		 ,CDES_AUDIT_USER_UPDT_DTM	
		 ,CURRENT_DATE AS DW_CREATE_DTTM			
		 ,CURRENT_DATE AS DW_UPDATE_DTTM	
		 ,CASE_VENU_TYP_CD
		 ,CASE_VENU_TYP_NM
		 ,CDL_NTC_APL_DUE_DATE
         ,CDL_NTC_APL_FILE_DATE
FROM DW_CASES_TEMP2