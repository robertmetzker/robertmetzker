{{ config(materialized='table', transient=false ) }}

-- SRC LAYER
WITH
CASES  as ( select * from {{ source('PCMP','CASES') }} ),
REL    as ( select * from {{ source('PCMP','CASE_RELATED') }} ),
CSS   as ( select * from {{ source('PCMP','CASE_STATE_STATUS') }} ),
CSSH  as ( select * from {{ source('PCMP','CASE_STATE_STATUS_HISTORY') }} ),
USRS as ( select * from {{ source('PCMP','USERS') }} ),
ASGN  as ( select * from {{ source('PCMP','ASSIGNMENT') }} ), 
FR   as ( select * from {{ source('PCMP','FUNCTIONAL_ROLE') }} ),
OU   as ( select * from {{ source('PCMP','ORGANIZATIONAL_UNIT') }} ),
AST  as ( select * from {{ source('PCMP','ASSIGNMENT_STATUS_TYPE') }} ), 
LD   as ( select * from {{ source('PCMP','ASSIGNMENT_LOAD_BAL_RL_TYP') }} ),

CD   as ( select * from {{ source('PCMP','CASE_DETAIL_LEGAL') }} ), 
CD1  as ( select * from {{ source('PCMP','CASE_SOURCE_TYPE') }} ), 
CD2  as ( select * from {{ source('PCMP','CASE_CATEGORY_TYPE') }} ), 
CD3  as ( select * from {{ source('PCMP','CASE_TYPE') }} ),
CD4  as ( select * from {{ source('PCMP','CASE_PRIORITY_TYPE') }} ),
CD5  as ( select * from {{ source('PCMP','CASE_RESOLUTION_TYPE') }} ),

JT   as ( select * from {{ source('PCMP','JURISDICTION_TYPE') }} ),
LP   as ( select * from {{ source('PCMP','LEGAL_PROCEEDING') }} ),
CVT  as ( select * from {{ source('PCMP','CASE_VENUE_TYPE') }} ),
CVLT as ( select * from {{ source('PCMP','CASE_VENUE_LOCATION_TYPE') }} ),
CSTT as ( select * from {{ source('PCMP','CASE_STATE_TYPE') }} ),
CSTST as ( select * from {{ source('PCMP','CASE_STATUS_TYPE') }} ),
CSRT  as ( select * from {{ source('PCMP','CASE_STATUS_REASON_TYPE') }} ),
DOC   as ( select * from {{ source('PCMP','DOCUMENT') }} ),
DEV   as ( select * from {{ source('PCMP','DOCUMENT_ELEMENT_VALUE') }} ),
DST   as ( select * from {{ source('PCMP','DOCUMENT_STATUS_TYPE') }} ),
DT    as ( select * from {{ source('PCMP','DOCUMENT_TYPE') }} ),
DTV   as ( select * from {{ source('PCMP','DOCUMENT_TYPE_VERSION') }} ),
DOCX  as ( select * from {{ source('PCMP','CLAIM_DOCUMENT_XREF') }} ),

-- BUSINESS RULES/LOGIC
/* Version # 1 		 	:(Prod Release DATE 11/30/2017 */
/* Table Description	: 	This table contains case, case status, assignment, most recent legal proceeding (DHO, SHO, COMMISSION, DEPUTY), most recent ADR Order document details from Claim Documents for Alternative Dispute Resolution (ADR) cases and the most recent case id of the exam scheduling case related to ADR case.  There will be only one row per ADR Case Id.
 */
 /* L1 Dependency 		: 	NA */
						
--\set ON_ERROR_STOP on
ADR  as
(
       select
       a.CASE_ID                               ADR_CASE_ID,
       a.CASE_NO                               ADR_CASE_NO,
       a.CASE_CNTX_ID                          CLM_AGRE_ID, 
       a.CASE_CNTX_NO                          CLM_NO,
       a.CASE_SRC_TYP_CD                       CASE_SRC_TYP_CD,
       cd1.CASE_SRC_TYP_NM                     CASE_SRC_TYP_NM,
       a.CASE_EXTRNL_NO                        CASE_EXTRNL_NO,
       DATE(a.CASE_INT_DT)                     CASE_INT_DATE,
       a.CASE_NM                               CASE_NAME,
       DATE(a.CASE_EFF_DT)                     CASE_EFF_DATE,
       DATE(a.CASE_DUE_DT)                     CASE_DUE_DATE,
       a.CASE_PRTY_TYP_CD                      CASE_PRTY_TYP_CD,
       cd4.CASE_PRTY_TYP_NM                    CASE_PRTY_TYP_NM,
       a.CASE_RSOL_TYP_CD                      CASE_RSOL_TYP_CD,
       cd5.CASE_RSOL_TYP_NM                    CASE_RSOL_TYP_NM,
       DATE(a.CASE_COMP_DT)                    CASE_COMP_DATE,
       a.CASE_RSN_SUM_TXT                      CASE_RSN_SUM_TXT,
       b.CASE_STT_TYP_CD                       CASE_STT_TYP_CD,
       CSTT.CASE_STT_TYP_NM                    CASE_STT_TYP_NM,
       DATE(b.CASE_STT_STS_STT_EFF_DT)         CASE_STT_EFF_DATE,
       b.CASE_STS_TYP_CD                       CASE_STS_TYP_CD,
       CSTST.CASE_STS_TYP_NM                   CASE_STS_TYP_NM,
       DATE(b.CASE_STT_STS_STS_EFF_DT)         CASE_STS_EFF_DATE,
       b.CASE_STS_RSN_TYP_CD                   CASE_STS_RSN_TYP_CD,
       CSRT.CASE_STS_RSN_TYP_NM                CASE_STS_RSN_TYP_NM,
       DATE(b.CASE_STT_STS_STS_RSN_EFF_DT)     CASE_STS_RSN_EFF_DATE,
       b.AUDIT_USER_ID_CREA                    CASE_STS_CREA_USER_ID, 
       STS_CREATE.USER_LGN_NM                  CASE_STS_CREA_USER_LGN_NM,
       sts_create.USER_DRV_UPCS_NM             CASE_STS_CREA_USER_NM,
       DATE(b.AUDIT_USER_CREA_DTM)             CASE_STS_CREA_DATE, 
       b.AUDIT_USER_CREA_DTM                   CASE_STS_CREA_DTM, 
       b.AUDIT_USER_ID_UPDT                    CASE_STS_UPDT_USER_ID, 
       sts_updt.USER_LGN_NM                    CASE_STS_UPDT_USER_LGN_NM,
       sts_updt.USER_DRV_UPCS_NM               CASE_STS_UPDT_USER_NM,
       DATE(b.AUDIT_USER_UPDT_DTM)             CASE_STS_UPDT_DATE,
       b.AUDIT_USER_UPDT_DTM                   CASE_STS_UPDT_DTM,
       b.CASE_STT_STS_COMT_TXT                 CASE_STT_STS_COMT_TXT,
       c.FNCT_ROLE_ID          	            ADR_CASE_ASGND_FNCT_ROLE_ID,
       fr.FNCT_ROLE_NM         	            ADR_CASE_ASGND_FNCT_ROLE_NM,
       c.ORG_UNT_ID            	            ADR_CASE_ASGND_ORG_UNT_ID,
       ou.ORG_UNT_NM           	            ADR_CASE_ASGND_ORG_UNT_NM,
       ou.ORG_UNT_ABRV_NM      	            ADR_CASE_ASGND_ORG_UNT_ABRV_NM,
       c.USER_ID               	            ADR_CASE_ASGND_USER_ID,
       U.USER_LGN_NM           	            ADR_CASE_ASGND_USER_LGN_NM,
       u.USER_DRV_UPCS_NM      	            ADR_CASE_ASGND_USER_NM,
       u.USER_PH_NO            	            ADR_CASE_ASGND_USER_PHONE_NMBR, 
       u.USER_PH_EXT_NO        	            ADR_CASE_ASGND_USER_PHONE_EXTNS,
       u.USER_EMAIL            	            ADR_CASE_ASGND_USER_EMAIL_ADRS,
       u.USER_TTL              	            ADR_CASE_ASGND_USER_TITLE, 
       U.USER_SUPR_ID          	            ADR_CASE_ASGND_USER_SUPV_ID,
       S.USER_LGN_NM           	            ADR_CASE_ASGND_USER_SUPV_LGN_NM,
       s.USER_DRV_UPCS_NM      	            ADR_CASE_ASGND_USER_SUPV_NM,
       s.USER_PH_NO            	            ADR_CASE_ASGND_USER_SUPV_PHONE_NMBR,
       DATE(c.ASGN_EFF_DT)        	            ADR_CASE_ASGND_EFF_DATE,
       DATE(c.ASGN_END_DT)       	            ADR_CASE_ASGND_END_DATE,
       c.ASGN_OVRRD_IND        	            ADR_CASE_ASGND_OVRRD_IND,
       c.ASGN_OVRRD_COMT       	            ADR_CASE_ASGND_OVRRD_COMT,
       c.ASGN_STS_TYP_CD       	            ADR_CASE_ASGND_STS_TYP_CD,
       ast.ASGN_STS_TYP_NM     	            ADR_CASE_ASGND_STS_TYP_NM,
       c.ASGN_LD_BAL_RL_TYP_CD 	            ADR_CASE_ASGND_LD_BAL_RL_TYP_CD,
       ld.ASGN_LD_BAL_RL_TYP_NM                ADR_CASE_ASGND_LD_BAL_RL_TYP_NM,
       d.CDL_ID                                CDL_ID,
       d.CASE_JUR_TYP_CD                       CASE_JUR_TYP_CD,
       JT.JUR_TYP_NM                           CASE_JUR_TYP_NM,
       d.CASE_VENU_TYP_CD                      CASE_VENU_TYP_CD,
       CVT.CASE_VENU_TYP_NM                    CASE_VENU_TYP_NM,
       d.CASE_VENU_LOC_TYP_CD                  CASE_VENU_LOC_TYP_CD,
       CVLT.CASE_VENU_LOC_TYP_NM               CASE_VENU_LOC_TYP_NM,
       DATE(d.CDL_NTC_HEAR_ISS_DT)             CDL_NTC_HEAR_ISS_DATE,
       d.CDL_NTC_HEAR_ISS_DT                   CDL_NTC_HEAR_ISS_DTM,
       DATE(d.CDL_NTC_HEAR_RECV_DT)            CDL_NTC_HEAR_RECV_DATE,
       DATE(d.CDL_NTC_APL_DUE_DT)              CDL_NTC_APL_DUE_DATE,
       DATE(d.CDL_NTC_APL_FILE_DT)             CDL_NTC_APL_FILE_DATE
       from      CASES a
       left join CSS   b           on a.CASE_ID = b.CASE_ID and b.VOID_IND = 'n'
       left join USRS  sts_create  on b.AUDIT_USER_ID_CREA = sts_create.USER_ID
       left join USRS  sts_updt    on b.AUDIT_USER_ID_UPDT = sts_updt.USER_ID 
       left join ASGN  c           on a.CASE_ID = c.ASGN_CNTX_ID and c.APP_CNTX_TYP_CD = 'case' and c.ASGN_END_DT is null and c.ASGN_PRI_OWNR_IND = 'y'
       left join USRS  u           on c.USER_ID = u.USER_ID
       left join USRS  s           on u.USER_SUPR_ID = s.USER_ID
       left join FR                on c.FNCT_ROLE_ID = fr.FNCT_ROLE_ID
       left join OU                on c.ORG_UNT_ID = ou.ORG_UNT_ID
       left join AST               on c.ASGN_STS_TYP_CD = ast.ASGN_STS_TYP_CD
       left join ld                ON c.ASGN_LD_BAL_RL_TYP_CD = ld.ASGN_LD_BAL_RL_TYP_CD
       left join cd    d           ON a.CASE_ID = d.CASE_ID and d.VOID_IND = 'n'
       left join CD1               on a.CASE_SRC_TYP_CD = cd1.CASE_SRC_TYP_CD
       left join CD2               on a.CASE_CTG_TYP_CD = cd2.CASE_CTG_TYP_CD
       left join CD3               on a.CASE_TYP_CD = cd3.CASE_TYP_CD
       left join CD4               on a.CASE_PRTY_TYP_CD = cd4.CASE_PRTY_TYP_CD
       left join CD5               on a.CASE_RSOL_TYP_CD = cd5.CASE_RSOL_TYP_CD
       LEFT JOIN JT                ON D.CASE_JUR_TYP_CD = JT.JUR_TYP_CD
       LEFT JOIN CVT               ON D.CASE_VENU_TYP_CD = CVT.CASE_VENU_TYP_CD
       LEFT JOIN CVLT              ON D.CASE_VENU_LOC_TYP_CD = CVLT.CASE_VENU_LOC_TYP_CD
       LEFT JOIN CSTT              ON B.CASE_STT_TYP_CD = CSTT.CASE_STT_TYP_CD 
       LEFT JOIN CSTST             ON B.CASE_STS_TYP_CD = CSTST.CASE_STS_TYP_CD
       LEFT JOIN CSRT              ON B.CASE_STS_RSN_TYP_CD = CSRT.CASE_STS_RSN_TYP_CD
       where a.APP_CNTX_TYP_CD = 'claim'
       and   a.VOID_IND = 'n'
       and   a.CASE_CTG_TYP_CD = 'lgl'
       and   a.CASE_TYP_CD = 'othr_lgl'
),

/*Exam cases related to ADR cases -- Bringing in most recently created Exam case id if there are more than 1 exam case related to ADR cases*/
ADR_EXAM_CASES  AS
(
       select DISTINCT 
              ADR.CASE_ID ADR_CASE_ID, 
              REL.CASE_RLT_CASE_ID EXAM_SCHDL_CASE_ID, 
              EXAM.CASE_NO EXAM_SCHDL_CASE_NO,
              EXAM.AUDIT_USER_CREA_DTM EXAM_SCHDL_CREATE_DTM
       from CASES ADR
              JOIN  REL        ON ADR.CASE_ID = REL.CASE_ID AND REL.VOID_IND = 'n'
              JOIN  CASES EXAM ON REL.CASE_RLT_CASE_ID = EXAM.CASE_ID 
                     AND EXAM.VOID_IND = 'n' and EXAM.CASE_CTG_TYP_CD = 'med' 
                     and EXAM.CASE_TYP_CD = 'exam_schd' 
                     and EXAM.APP_CNTX_TYP_CD = 'claim'
       where ADR.APP_CNTX_TYP_CD = 'claim'
              and   ADR.VOID_IND = 'n'
              and   ADR.CASE_CTG_TYP_CD = 'lgl'
              and   ADR.CASE_TYP_CD = 'othr_lgl'
              AND   (ADR.CASE_ID, EXAM.AUDIT_USER_CREA_DTM)
                IN (
                     SELECT ADR_CASE_ID, MAX(EXAM_CREATE_DTM) RECENT_EXAM_CREATE FROM 
                     (
                     select DISTINCT ADR.CASE_ID ADR_CASE_ID, REL.CASE_RLT_CASE_ID EXAM_CASE_ID, EXAM.AUDIT_USER_CREA_DTM EXAM_CREATE_DTM
                            from CASES ADR
                            JOIN REL        ON ADR.CASE_ID = REL.CASE_ID AND REL.VOID_IND = 'n'
                            JOIN CASES EXAM ON REL.CASE_RLT_CASE_ID = EXAM.CASE_ID 
                                   AND EXAM.VOID_IND = 'n'
                                   and EXAM.CASE_CTG_TYP_CD = 'med' 
                                   and EXAM.CASE_TYP_CD = 'exam_schd' 
                                   and EXAM.APP_CNTX_TYP_CD = 'claim'
                            where ADR.APP_CNTX_TYP_CD = 'claim'
                                   and   ADR.VOID_IND = 'n'
                                   and   ADR.CASE_CTG_TYP_CD = 'lgl'
                                   and   ADR.CASE_TYP_CD = 'othr_lgl'
                     ) X
       GROUP BY 1)
),

/*LEGAL PROCEEDINGS*/
LP1  as
(
       select * from LP xyz
       where ( CDL_ID, CASE_PRCD_TYP_CD, AUDIT_USER_CREA_DTM, LGL_PRCD_DTM) in
              (
              select abc.CDL_ID, abc.CASE_PRCD_TYP_CD, MAX_AUDIT.AUDIT_USER_CREA_DTM, max(abc.LGL_PRCD_DTM) LGL_PRCD_DTM
              from LP abc
              join (	select CDL_ID, MAX(AUDIT_USER_CREA_DTM) AUDIT_USER_CREA_DTM
                     from LP
                     where CASE_PRCD_TYP_CD = 'sh_officer'
                     and VOID_IND = 'n'
                     group by 1
                   ) MAX_AUDIT 
              on abc.CDL_ID = MAX_AUDIT.CDL_ID 
                     and abc.AUDIT_USER_CREA_DTM = MAX_AUDIT.AUDIT_USER_CREA_DTM
       where CASE_PRCD_TYP_CD = 'sh_officer'
              and VOID_IND = 'n'
       group by 1,2,3)
),

LP2  as
(
       select * from LP xyz
       where (CDL_ID, CASE_PRCD_TYP_CD, AUDIT_USER_CREA_DTM, LGL_PRCD_DTM) in
       (
              select abc.CDL_ID, abc.CASE_PRCD_TYP_CD, MAX_AUDIT.AUDIT_USER_CREA_DTM, max(abc.LGL_PRCD_DTM) LGL_PRCD_DTM
              from LP abc
              join (	select CDL_ID, MAX(AUDIT_USER_CREA_DTM) AUDIT_USER_CREA_DTM
                     from LP
                     where CASE_PRCD_TYP_CD = 'dh_officer'
                     and VOID_IND = 'n'
                     group by 1
              ) MAX_AUDIT 
              on abc.CDL_ID = MAX_AUDIT.CDL_ID 
                     and abc.AUDIT_USER_CREA_DTM = MAX_AUDIT.AUDIT_USER_CREA_DTM
       where CASE_PRCD_TYP_CD = 'dh_officer'
             and VOID_IND = 'n'
       group by 1,2,3)
),

LP3  as
(
       select * from LP xyz
       where (CDL_ID, CASE_PRCD_TYP_CD, AUDIT_USER_CREA_DTM, LGL_PRCD_DTM) in
       (
              select abc.CDL_ID, abc.CASE_PRCD_TYP_CD, MAX_AUDIT.AUDIT_USER_CREA_DTM, max(abc.LGL_PRCD_DTM) LGL_PRCD_DTM
              from LP abc
              join (	select CDL_ID, MAX(AUDIT_USER_CREA_DTM) AUDIT_USER_CREA_DTM
                     from LP
                     where CASE_PRCD_TYP_CD = 'comm'
                     and VOID_IND = 'n'
              group by 1
       ) MAX_AUDIT 
       on abc.CDL_ID = MAX_AUDIT.CDL_ID 
              and abc.AUDIT_USER_CREA_DTM = MAX_AUDIT.AUDIT_USER_CREA_DTM
       where CASE_PRCD_TYP_CD = 'comm'
              and VOID_IND = 'n'
       group by 1,2,3)
),

LP4  as
(
       select * from LP xyz
       where (CDL_ID, CASE_PRCD_TYP_CD, AUDIT_USER_CREA_DTM, LGL_PRCD_DTM) in
       (
       select abc.CDL_ID, abc.CASE_PRCD_TYP_CD, MAX_AUDIT.AUDIT_USER_CREA_DTM, max(abc.LGL_PRCD_DTM) LGL_PRCD_DTM
       from LP abc
       join (	select CDL_ID, MAX(AUDIT_USER_CREA_DTM) AUDIT_USER_CREA_DTM
              from LP
              where CASE_PRCD_TYP_CD = 'dpty'
                     and VOID_IND = 'n'
              group by 1
              ) MAX_AUDIT 
       on abc.CDL_ID = MAX_AUDIT.CDL_ID 
              and abc.AUDIT_USER_CREA_DTM = MAX_AUDIT.AUDIT_USER_CREA_DTM
       where CASE_PRCD_TYP_CD = 'dpty'
       and VOID_IND = 'n'
       group by 1,2,3)
),

/********************************************LEVEL CASE STATUS FROM HIST TABLE**********************************************************************/

LEVEL_STS_1  as
(
       select a.CASE_ID, b.CASE_STS_RSN_TYP_CD, b.HIST_EFF_DTM,
       RANK () OVER 
              (PARTITION BY a.case_id, 
                            case 
                                   when b.CASE_STS_RSN_TYP_CD like 'bwc%' then 1
                                   when b.CASE_STS_RSN_TYP_CD like 'c9%'  then 2
                                   when b.CASE_STS_RSN_TYP_CD like 'dho%' then 3
                                   when b.CASE_STS_RSN_TYP_CD like 'mco%' then 4
                                   when b.CASE_STS_RSN_TYP_CD like 'sho%' then 5
                                   end  
                     order by b.HIST_EFF_DTM desc) RANK
       from CASES a
              join CSSH  b on a.CASE_ID = b.CASE_ID and b.VOID_IND = 'n'
              join CSRT  c on b.CASE_STS_RSN_TYP_CD = c.CASE_STS_RSN_TYP_CD
       where a.APP_CNTX_TYP_CD = 'claim'
              and   a.VOID_IND = 'n'
              and   a.CASE_CTG_TYP_CD = 'lgl'
              and   a.CASE_TYP_CD = 'othr_lgl'
),

LEVEL_STS_2  as
(
       select *, 
       case when CASE_STS_RSN_TYP_CD like 'bwc%' then 1
              when CASE_STS_RSN_TYP_CD like 'c9%'  then 2
              when CASE_STS_RSN_TYP_CD like 'dho%' then 3
              when CASE_STS_RSN_TYP_CD like 'mco%' then 4
              when CASE_STS_RSN_TYP_CD like 'sho%' then 5
       else 0
       end RSN_ID
       from LEVEL_STS_1
       where rank = 1
),

LEVEL_STS_3  as
(
       select 
       case_id,
       MAX (DECODE(RSN_ID, 1, CASE_STS_RSN_TYP_CD)) BWC_LVL_CASE_STS_RSN_TYP_CD,
       MAX (DECODE(RSN_ID, 2, CASE_STS_RSN_TYP_CD)) C9_LVL_CASE_STS_RSN_TYP_CD,
       MAX (DECODE(RSN_ID, 3, CASE_STS_RSN_TYP_CD)) DHO_LVL_CASE_STS_RSN_TYP_CD,
       MAX (DECODE(RSN_ID, 4, CASE_STS_RSN_TYP_CD)) MCO_LVL_CASE_STS_RSN_TYP_CD,
       MAX (DECODE(RSN_ID, 5, CASE_STS_RSN_TYP_CD)) SHO_LVL_CASE_STS_RSN_TYP_CD
       from LEVEL_STS_2
       group by case_id
),
/******************************************************************************************************************/

adr_document  as 
(
       select distinct 
       e.DOCM_ELEM_VAL_VAL         ADR_CASE_NO, 
       a.DOCM_ID                   ADR_ORDER_DOCM_ID, 
       b.DOCM_NO                   ADR_ORDER_DOCM_NO, 
       b.DOCM_STS_TYP_CD           ADR_ORDER_DOCM_STS_TYP_CD, 
       g.DOCM_STS_TYP_NM           ADR_ORDER_DOCM_STS_TYP_NM,
       date(b.DOCM_STS_TYP_EFF_DT) ADR_ORDER_DOCM_STS_EFF_DATE,
       b.DOCM_STS_TYP_EFF_DT       ADR_ORDER_DOCM_STS_EFF_DTM, 
       b.AUDIT_USER_ID_CREA        ADR_ORDER_DOCM_CREA_USER_ID, 
       f.USER_LGN_NM               ADR_ORDER_DOCM_CREA_USER_LGN_NM, 
       f.USER_DRV_UPCS_NM          ADR_ORDER_DOCM_CREA_USER_DRV_UPCS_NM, 
       b.AUDIT_USER_CREA_DTM       ADR_ORDER_DOCM_CREA_DTM,
       row_number() over (partition by e.DOCM_ELEM_VAL_VAL order by b.AUDIT_USER_CREA_DTM desc) RN
       from DOCX        a
              join DOC  b on a.DOCM_ID = b.DOCM_ID and b.VOID_IND = 'n'
              join DTV  c on b.DOCM_TYP_VER_ID = c.DOCM_TYP_VER_ID and c.VOID_IND = 'n'
              join DT   d on c.DOCM_TYP_ID = d.DOCM_TYP_ID and d.VOID_IND = 'n'
              join DEV  e on a.DOCM_ID = e.DOCM_ID and e.VOID_IND = 'n' and e.DOCM_ELEM_TYP_CD = 'dsp_num'
              left join USRS f on b.AUDIT_USER_ID_CREA = f.USER_ID
              left join DST   g on b.DOCM_STS_TYP_CD = g.DOCM_STS_TYP_CD
       where a.VOID_IND = 'n'
              and d.DOCM_TYP_REF_NO = 'Corr008H'
       qualify RN = 1
)

SELECT DISTINCT
       a.ADR_CASE_ID
       , a.ADR_CASE_NO
       , a.CLM_AGRE_ID
       , a.CLM_NO
       , CASE WHEN a.CASE_SRC_TYP_CD IS NULL 
              THEN '-1'
              ELSE a.CASE_SRC_TYP_CD
              END                          AS CASE_SRC_TYP_CD    
       , a.CASE_SRC_TYP_NM
       , a.CASE_EXTRNL_NO
       , a.CASE_INT_DATE
       , a.CASE_NAME CASE_NM
       , a.CASE_EFF_DATE
       , a.CASE_DUE_DATE
       , CASE WHEN a.CASE_PRTY_TYP_CD IS NULL 
              THEN '-1'
              ELSE a.CASE_PRTY_TYP_CD
              END                          AS CASE_PRTY_TYP_CD
       , a.CASE_PRTY_TYP_NM
       , CASE WHEN a.CASE_RSOL_TYP_CD IS NULL 
              THEN '-1'
              ELSE a.CASE_RSOL_TYP_CD
              END                          AS CASE_RSOL_TYP_CD
       , a.CASE_RSOL_TYP_NM
       , a.CASE_COMP_DATE
       , a.CASE_RSN_SUM_TXT
       , CASE WHEN a.CASE_STT_TYP_CD IS NULL 
              THEN '-1'
              ELSE a.CASE_STT_TYP_CD
              END                          AS CASE_STT_TYP_CD
       , a.CASE_STT_TYP_NM
       , a.CASE_STT_EFF_DATE
       , CASE WHEN a.CASE_STS_TYP_CD IS NULL 
              THEN '-1'
              ELSE a.CASE_STS_TYP_CD
              END                           AS CASE_STS_TYP_CD
       , a.CASE_STS_TYP_NM
       , a.CASE_STS_EFF_DATE
       , CASE WHEN a.CASE_STS_RSN_TYP_CD IS NULL 
              THEN '-1'
              ELSE a.CASE_STS_RSN_TYP_CD
              END                           AS CASE_STS_RSN_TYP_CD
       , a.CASE_STS_RSN_TYP_NM
       , a.CASE_STS_RSN_EFF_DATE
       , a.CASE_STS_CREA_USER_ID
       , a.CASE_STS_CREA_USER_LGN_NM
       , a.CASE_STS_CREA_USER_NM
       , a.CASE_STS_CREA_DATE
       , a.CASE_STS_CREA_DTM
       , a.CASE_STS_UPDT_USER_ID
       , a.CASE_STS_UPDT_USER_LGN_NM
       , a.CASE_STS_UPDT_USER_NM
       , a.CASE_STS_UPDT_DATE
       , a.CASE_STS_UPDT_DTM
       , a.CASE_STT_STS_COMT_TXT
       , CASE WHEN C.BWC_LVL_CASE_STS_RSN_TYP_CD IS NULL 
              THEN '-1'
              ELSE C.BWC_LVL_CASE_STS_RSN_TYP_CD
              END                              AS BWC_LVL_CASE_STS_RSN_TYP_CD
       , T1.CASE_STS_RSN_TYP_NM BWC_LVL_CASE_STS_RSN_TYP_NM
       , CASE WHEN C.C9_LVL_CASE_STS_RSN_TYP_CD IS NULL 
              THEN '-1'
              ELSE C.C9_LVL_CASE_STS_RSN_TYP_CD
              END                              AS C9_LVL_CASE_STS_RSN_TYP_CD
       , T2.CASE_STS_RSN_TYP_NM C9_LVL_CASE_STS_RSN_TYP_NM
       , CASE WHEN C.DHO_LVL_CASE_STS_RSN_TYP_CD IS NULL 
              THEN '-1'
              ELSE C.DHO_LVL_CASE_STS_RSN_TYP_CD
              END                              AS DHO_LVL_CASE_STS_RSN_TYP_CD
       , T3.CASE_STS_RSN_TYP_NM DHO_LVL_CASE_STS_RSN_TYP_NM
       , CASE WHEN C.MCO_LVL_CASE_STS_RSN_TYP_CD IS NULL 
              THEN '-1'
              ELSE C.MCO_LVL_CASE_STS_RSN_TYP_CD
              END                              AS MCO_LVL_CASE_STS_RSN_TYP_CD
       , T4.CASE_STS_RSN_TYP_NM MCO_LVL_CASE_STS_RSN_TYP_NM
       , CASE WHEN C.SHO_LVL_CASE_STS_RSN_TYP_CD IS NULL 
              THEN '-1'
              ELSE C.SHO_LVL_CASE_STS_RSN_TYP_CD
              END                              AS SHO_LVL_CASE_STS_RSN_TYP_CD
       , T5.CASE_STS_RSN_TYP_NM SHO_LVL_CASE_STS_RSN_TYP_NM
       , A.ADR_CASE_ASGND_FNCT_ROLE_ID
       , A.ADR_CASE_ASGND_FNCT_ROLE_NM
       , A.ADR_CASE_ASGND_ORG_UNT_ID
       , A.ADR_CASE_ASGND_ORG_UNT_NM
       , A.ADR_CASE_ASGND_ORG_UNT_ABRV_NM
       , A.ADR_CASE_ASGND_USER_ID
       , A.ADR_CASE_ASGND_USER_LGN_NM
       , A.ADR_CASE_ASGND_USER_NM
       , A.ADR_CASE_ASGND_USER_PHONE_NMBR 
       , A.ADR_CASE_ASGND_USER_PHONE_EXTNS
       , A.ADR_CASE_ASGND_USER_EMAIL_ADRS
       , A.ADR_CASE_ASGND_USER_TITLE 
       , A.ADR_CASE_ASGND_USER_SUPV_ID
       , A.ADR_CASE_ASGND_USER_SUPV_LGN_NM
       , A.ADR_CASE_ASGND_USER_SUPV_NM
       , A.ADR_CASE_ASGND_USER_SUPV_PHONE_NMBR
       , A.ADR_CASE_ASGND_EFF_DATE
       , A.ADR_CASE_ASGND_END_DATE
       , A.ADR_CASE_ASGND_OVRRD_IND
       , A.ADR_CASE_ASGND_OVRRD_COMT
       , CASE WHEN A.ADR_CASE_ASGND_STS_TYP_CD IS NULL 
              THEN '-1'
              ELSE A.ADR_CASE_ASGND_STS_TYP_CD
              END                              AS ADR_CASE_ASGND_STS_TYP_CD
       , A.ADR_CASE_ASGND_STS_TYP_NM
       , CASE WHEN A.ADR_CASE_ASGND_LD_BAL_RL_TYP_CD IS NULL 
              THEN '-1'
              ELSE A.ADR_CASE_ASGND_LD_BAL_RL_TYP_CD
              END                              AS ADR_CASE_ASGND_LD_BAL_RL_TYP_CD
       , A.ADR_CASE_ASGND_LD_BAL_RL_TYP_NM
       , A.CDL_ID
       , CASE WHEN A.CASE_JUR_TYP_CD IS NULL 
              THEN '-1'
              ELSE A.CASE_JUR_TYP_CD
              END                         AS CASE_JUR_TYP_CD
       , A.CASE_JUR_TYP_NM
       , CASE WHEN A.CASE_VENU_TYP_CD IS NULL 
              THEN '-1'
              ELSE A.CASE_VENU_TYP_CD
              END                         AS CASE_VENU_TYP_CD
       , A.CASE_VENU_TYP_NM
       , CASE WHEN A.CASE_VENU_LOC_TYP_CD IS NULL 
              THEN '-1'
              ELSE A.CASE_VENU_LOC_TYP_CD
              END                         AS CASE_VENU_LOC_TYP_CD
       , A.CASE_VENU_LOC_TYP_NM
       , A.CDL_NTC_HEAR_ISS_DATE
       , A.CDL_NTC_HEAR_ISS_DTM
       , A.CDL_NTC_HEAR_RECV_DATE
       , A.CDL_NTC_APL_DUE_DATE
       , A.CDL_NTC_APL_FILE_DATE
       , DATE(LP1.LGL_PRCD_DTM) SHO_LGL_PRCD_DATE
       , TO_CHAR(LP1.LGL_PRCD_DTM, 'HH12:MI:SS AM') SHO_LGL_PRCD_TIME
       , LP1.LGL_PRCD_DTM SHO_LGL_PRCD_DTM
       , LP1.LGL_PRCD_DESC SHO_LGL_PRCD_DESC
       , DATE(LP2.LGL_PRCD_DTM) DHO_LGL_PRCD_DATE
       , TO_CHAR(LP2.LGL_PRCD_DTM, 'HH12:MI:SS AM') DHO_LGL_PRCD_TIME
       , LP2.LGL_PRCD_DTM DHO_LGL_PRCD_DTM
       , LP2.LGL_PRCD_DESC DHO_LGL_PRCD_DESC
       , DATE(LP3.LGL_PRCD_DTM) COMM_LGL_PRCD_DATE
       , TO_CHAR(LP3.LGL_PRCD_DTM, 'HH12:MI:SS AM') COMM_LGL_PRCD_TIME
       , LP3.LGL_PRCD_DTM COMM_LGL_PRCD_DTM
       , LP3.LGL_PRCD_DESC COMM_LGL_PRCD_DESC
       , DATE(LP4.LGL_PRCD_DTM) DPTY_LGL_PRCD_DATE
       , TO_CHAR(LP4.LGL_PRCD_DTM, 'HH12:MI:SS AM') DPTY_LGL_PRCD_TIME
       , LP4.LGL_PRCD_DTM DPTY_LGL_PRCD_DTM
       , LP4.LGL_PRCD_DESC DPTY_LGL_PRCD_DESC
       , B.EXAM_SCHDL_CASE_ID
       , B.EXAM_SCHDL_CASE_NO
       , B.EXAM_SCHDL_CREATE_DTM
       , D.ADR_ORDER_DOCM_ID
       , D.ADR_ORDER_DOCM_NO
       , CASE WHEN D.ADR_ORDER_DOCM_STS_TYP_CD IS NULL 
              THEN '-1'
              ELSE D.ADR_ORDER_DOCM_STS_TYP_CD
              END                         AS  ADR_ORDER_DOCM_STS_TYP_CD
       , D.ADR_ORDER_DOCM_STS_TYP_NM
       , D.ADR_ORDER_DOCM_STS_EFF_DATE
       , D.ADR_ORDER_DOCM_STS_EFF_DTM
       , D.ADR_ORDER_DOCM_CREA_USER_ID
       , D.ADR_ORDER_DOCM_CREA_USER_LGN_NM
       , D.ADR_ORDER_DOCM_CREA_USER_DRV_UPCS_NM
       , D.ADR_ORDER_DOCM_CREA_DTM
       , CURRENT_DATE DW_CREATE_DTM
       , CURRENT_DATE DW_UPDATE_DTM
FROM ADR A
       LEFT JOIN ADR_EXAM_CASES B ON A.ADR_CASE_ID = B.ADR_CASE_ID
       left join LP1 on a.CDL_ID = LP1.CDL_ID
       left join LP2 on a.CDL_ID = LP2.CDL_ID
       left join LP3 on a.CDL_ID = LP3.CDL_ID
       left join LP4 on a.CDL_ID = LP4.CDL_ID
       left join LEVEL_STS_3 C ON A.ADR_CASE_ID = C.CASE_ID
       LEFT JOIN adr_document d on a.adr_case_no = d.adr_case_no
       LEFT JOIN CSRT T1 ON C.BWC_LVL_CASE_STS_RSN_TYP_CD = T1.CASE_STS_RSN_TYP_CD
       LEFT JOIN CSRT T2 ON C.C9_LVL_CASE_STS_RSN_TYP_CD  = T2.CASE_STS_RSN_TYP_CD
       LEFT JOIN CSRT T3 ON C.DHO_LVL_CASE_STS_RSN_TYP_CD = T3.CASE_STS_RSN_TYP_CD
       LEFT JOIN CSRT T4 ON C.MCO_LVL_CASE_STS_RSN_TYP_CD = T4.CASE_STS_RSN_TYP_CD
       LEFT JOIN CSRT T5 ON C.SHO_LVL_CASE_STS_RSN_TYP_CD = T5.CASE_STS_RSN_TYP_CD
