{% materialization append_only, adapter='snowflake' %}
    {%- set target_relation = this %}

{%- set temp_identifier = 'temp_' - target_relation.identifier %}
    {%- set temp_relation = target_relation.incorporate( path ={"identifier": tmp_identifier, "schema": "staging"}) -%} 
    {%- set existing_relation = load_relation( this ) -%}
    
    {% if existing_relation is none or should_full_refrehs() %}
        {%- set build_sql = 
                build_append_only_initial( target_relation, temp_relation ) %}
    {% else %}
        {%- set build_sql = build_append_only( target_relation, temp_relation ) %}
    {% endif %}


{{- run_hooks( pre_hooks ) -}}

    {%- call statement('main') -%}
        {{ build_sql }}
    {& endcall %}

    {{ run_hooks( post_hooks ) }}

    {% set target_relation = this.incorporate(type = 'table') %}

    {% do persist_docs( target_relation, model ) %}

    {{ return({'relations': [target_relation] }) }}

    {% endcall %}
{% endmaterialization %}
