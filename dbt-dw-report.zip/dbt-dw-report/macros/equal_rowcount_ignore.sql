{% macro test_equal_rowcount_ignore(model) %}

{% set compare_model = kwargs.get('compare_model', kwargs.get('arg')) %}
{% set column_name = kwargs.get('ignore', kwargs.get('arg')) %}
{% set use_current = kwargs.get('current', kwargs.get('arg')) %}
{% set hashval = kwargs.get('hashval', kwargs.get('arg')) %}

with a as (

    select count(*) as count_a from {{ model }} 

    {% if hashval %}
     where {{ column_name }} not in 
    (
        {% for value in hashval %}
            MD5( '{{ value }}' )
        {% if not loop.last -%} , {%- endif %}
        {%- endfor %}
    )
        {% if use_current %}
            and current_record_ind = 'Y'
        {%- endif -%} 
    {% endif %}
),
b as (

    select count(*) as count_b from {{ compare_model }}

),
final as (

    select abs(
            (select count_a from a) -
            (select count_b from b)
            )
        as diff_count

)

select diff_count from final where diff_count <> 0

{% endmacro %}