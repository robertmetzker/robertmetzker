{% macro CREATE_PRD_SCHEMA_BACKUP(tgt) %}
{#-
To run it:
    $ dbt run-operation CREATE_SCHEMA_BACKUP --args {'tgt': 'DIMENSIONS'}

-#}

date =

{% set date_qry %}
select 'create or replace schema PRD_EDW_ROLLBACK.{{-tgt-}}_' || trim( replace(current_date,'-','')) ||  '  clone PRD_EDW.{{-tgt}};'
{% endset %}
{% set dt_result = run_query(date_qry) %}
{# set dt = dt_result.columns[0].values() #}

{% if execute %}
    {% set run_list = dt_result.columns[0].values() %}
{% else %}
    {% set run_list = [] %}
{% endif %}


{% set query1 %}
    {% for STATMENTS in run_list %}
            {{STATMENTS}}
    {% endfor %}
{% endset %}


    {{ dbt_utils.log_info("Cloning schema " ~ tgt ~ " into PRD_EDW_ROLLBACK schema.") }}
        {% do run_query(query1) %} 
    {{ dbt_utils.log_info("Cloning complete.") }}

{% endmacro %}
