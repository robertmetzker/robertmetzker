{# 
My Version of the merge that will allow the overlay of the UPDATE_DATETIME when it finds a matching
record where not all of the fields match
#}

{% macro dynamic_merge( target, source, unique_keys, dest_columns ) %}
    {% set unique_keys = ['EOB_HKEY'] %}
    {% set mergetbl = ['DIM_EOB'] %}

{%set mergecols %}
    select distinct column_name
    from information_schema.columns
    where table_name = '{{mergetbl}}'
    and column_name not in ('LOAD_DATETIME', 'UPDATE_DATETIME') and column_name not like '%HKEY'
{% endset %}

{% set results = run_query(mergecols) %}

merge into {{ target }} as DBT_INTERNAL_DEST
using {{ source }} as DBT_INTERNAL_SOURCE
    on 
(   {% for key in unique_keys -%}
    DBT_INTERNAL_DEST.{{key}} = DBT_INTERNAL_SOURCE.{{key}}  {% if not loop.last -%} and {% endif %}
    {% endfor -%}
AND    (
    {% for merge_column in dest_columns -%}
    DBT_INTERNAL_DEST.{{merge_column}} != DBT_INTERNAL_SOURCE.{{merge_column}}  {% if not loop.last -%} or {% endif %}
    {% endfor -%}
)
when MATCHED then UPDATE set
    {%- for column in dest_columns -%}
    DBT_INTERNAL_DEST.{{merge_column}} = DBT_INTERNAL_SOURCE.{{merge_column}} ,    
    {%- endfor -%}
    DBT_INTERNAL_DEST.UPDATE_DATETIME = DBT_INTERNAL_SOURCE.UPDATE_DATETIME
when NOT MATCHED then INSERT
(
    {%- for column in dest_columns -%}
    DBT_INTERNAL_DEST.{{merge_column}} {% if not loop.last -%} , {% endif %}
    {%- endfor -%}
)
values
(
    {%- for column in dest_columns -%}
    DBT_INTERNAL_SOURCE.{{merge_column}} {% if not loop.last -%} , {% endif %}
    {%- endfor -%}
)

{% endmacro %}