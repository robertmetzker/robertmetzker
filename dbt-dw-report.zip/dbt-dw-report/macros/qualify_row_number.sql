{% macro qualify_row_number( partition_by_string, order_by_string ) %}

{% set partition_by = partition_by_string.split(',') %}
{% set order_by = order_by_string.split(',') %}

{%- set qualify_statement %}
QUALIFY ROW_NUMBER() OVER ( partition by 
    {% for value in partition_by -%}
    {{ value }}
    {%- if not loop.last -%} , {%- endif -%}
    {% endfor %}
    order by
    {% for value in order_by -%}
    {{ value }}
    {%- if not loop.last -%} , {%- endif -%}
    {%- endfor -%}
    ) = 1
 {% endset %}

{{ return( qualify_statement ) }}
{% endmacro %}