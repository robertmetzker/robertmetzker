{% macro db(dbname) %}
    {% if target.name == 'prod'%}
      {{ return("EDW")}}  



    {% elif target.name == 'dev'%}
      {{ return("DEV_EDW")}}
    {% else %}
      {{ return ("UAT_EDW")}}
    {% endif %}
  
{% endmacro %}



