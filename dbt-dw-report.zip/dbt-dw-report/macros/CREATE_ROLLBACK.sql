{% macro create_rollback() %}

{% set sql='create or replace schema DEV_EDW_ROLLBACK.DIMENSIONS clone DEV_EDW.DIMENSIONS;
    create or replace schema DEV_EDW_ROLLBACK.MEDICAL_MART clone DEV_EDW.MEDICAL_MART;' %}
    {% do run_query(sql) %}
    {{ log("Rollback SCHEMA (DEV_EDW_ROLLBACK) created", info=True) }}
    {{ log(sql, info=True) }}

{{ log(sql, info=True) }}
{% endmacro %}
