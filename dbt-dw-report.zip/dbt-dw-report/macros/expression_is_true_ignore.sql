{% macro test_expression_is_true_ignore( model ) %}

{% set expression = kwargs.get('expression', kwargs.get('arg')) %}
{% set column_name = kwargs.get('column_name') %}
{% set ignore = kwargs.get('ignore', kwargs.get('arg')) %}

with meet_condition as (

    select * from {{ model }}  
    {% if ignore -%}

        where {{ignore}} not in ( MD5('99999'), MD5('-1111'), MD5('-2222'), MD5('88888'), MD5('00000') )
    {% endif %}
),
validation_errors as (

    select
        *
    from meet_condition
    {% if column_name is none %}
    where not({{ expression }})
    {%- else %}
    where not({{ column_name }} {{ expression }})
    {%- endif %}

)

select *
from validation_errors

{% endmacro %}
