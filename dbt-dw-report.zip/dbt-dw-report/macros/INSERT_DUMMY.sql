{% macro insert_dummy() %}


{% set tablename_query %}
select
        distinct insert_stm
    from EDW_STAGING.DIM_DUMMY
where regexp_replace(table_name,'[0-9]','') 
in (
    select table_name
    from "INFORMATION_SCHEMA"."TABLES" 
   )
{% endset %}

{% set results = run_query(tablename_query) %}
{{ log(tablename_query, info=True) }}

{% if execute %}
{# Return the first column #}
{% set results_list = results.columns[0].values() %}
{% else %}
{% set results_list = [] %}
{% endif %}

{% set query1 %}
    {% for STATEMENTS in results_list %}
            {{STATEMENTS}}
    {% endfor %}
{% endset %}


{% do run_query(query1) %} 
{{ log(query1, info=True) }}

{% set sql='COMMIT;' %}
    {% do run_query(sql) %}
{{ log(sql, info=True) }}


{% endmacro %}
