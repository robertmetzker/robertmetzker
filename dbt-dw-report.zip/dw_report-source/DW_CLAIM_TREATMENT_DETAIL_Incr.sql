--\set ON_ERROR_STOP on
-- TRUNCATE AND INSERT ROWS 
TRUNCATE TABLE DW_REPORT.DW_CLAIM_TREATMENT_DETAIL;
INSERT
    /*+DIRECT*/
    INTO
        DW_REPORT.DW_CLAIM_TREATMENT_DETAIL(
            CLM_TRT_DTL_ID,
            AGRE_ID,
            CLM_TRT_DTL_TYP_CD,
            CLM_TRT_MCO_REF_CD,
            CUST_ID,
            CLM_NONCUST_PTCP_ID,
            AUDIT_USER_ID_CREA,
            AUDIT_USER_CREA_DTM,
            AUDIT_USER_ID_UPDT,
            AUDIT_USER_UPDT_DTM,
            DW_CREATE_DTTM,
            DW_UPDATE_DTTM
        ) SELECT
            CTD.CLM_TRT_DTL_ID,
            CTD.AGRE_ID,
            CASE
                WHEN CTD.CLM_TRT_DTL_TYP_CD IS NULL
                THEN '-1'
                ELSE CTD.CLM_TRT_DTL_TYP_CD
            END CLM_TRT_DTL_TYP_CD,
            CASE
                WHEN CTDT.CLM_TRT_MCO_REF_CD IS NULL
                THEN '-1'
                ELSE CTDT.CLM_TRT_MCO_REF_CD
            END CLM_TRT_MCO_REF_CD,            
            CTD.CUST_ID,
            CTD.CLM_NONCUST_PTCP_ID,
            CTD.AUDIT_USER_ID_CREA,
            CTD.AUDIT_USER_CREA_DTM,
            CTD.AUDIT_USER_ID_UPDT,
            CTD.AUDIT_USER_UPDT_DTM,
            CURRENT_DATE AS DW_CREATE_DTTM,
            CURRENT_DATE AS DW_UPDATE_DTTM
        FROM  PCMP.CLAIM_TREATMENT_DETAIL CTD
        LEFT OUTER JOIN PCMP.CLAIM_TREATMENT_DETAIL_TYP CTDT
        ON CTD.CLM_TRT_DTL_TYP_CD = CTDT.CLM_TRT_DTL_TYP_CD;COMMIT;