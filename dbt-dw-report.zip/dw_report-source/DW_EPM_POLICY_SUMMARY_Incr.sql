/* Version #  1		 	:  	(Prod Release date 05/16/2017 ) */
/* Version #  2		 	:  	(Prod Release date 10/24/2017 ) */

/* Table Description 		: 	This report is used to determine an employer�s frequency and severity performance measurements. This report calculates claim 
					counts and days absent. This is then used to calculate employer claims frequency and severity for Policy Summary Report.Then two 
					years of claim frequency and severity is used to determine the Safety Council Performance bonus. The output of this report is 
					used by S&H to create the policy file to be sent to R&P for PERFORMANCE bonus eligibility/calculations. One row per CLAIM by 
					CALENDAR YEAR or FISCAL YEAR.  Both Payroll (PDP) and no Payroll queries for both Fiscal and Calendar years can use this table. 
					Data for the current year plus the last 4 years. This summary table is built once for every QUARTER.*/				
							
						
/* L1 Dependency 		: 	DW_REPORT.DW_PLCY_END_OF_CHAIN_CMBNS
					DW_REPORT.DW_EMPLOYER_DEMOGRAPHICS
					DW_REPORT.DW_EPM_CLAIM_SUMMARY
					DW_REPORT.DATE_DIM */

/* SCHEDULING 			:       This table needs to be refreshed on 1st weekend of EVERY MONTH */



/* STEP 1: 
   Select end of chain policy demographic information with business sequence number = 0 and for all policy types except 'si'.
   Calculate year type and year label using the policy type.
*/

CREATE TEMPORARY TABLE EPM_TEMP_1  as
SELECT 
distinct
A.EOC_PLCY_AGRE_ID,
A.EOC_CUST_ID_ACCT_HLDR,
A.EOC_PLCY_NO,
A.EOC_BSNS_SQNC_NO,
B.EMPLR_LEGAL_NAME,
B.EMPLR_PHYS_ADRS_LINE1, 
B.EMPLR_PHYS_ADRS_LINE2, 
B.EMPLR_PHYS_ADRS_CITY_NAME, 
B.EMPLR_PHYS_ADRS_STATE_NAME, 
B.EMPLR_PHYS_ADRS_POST_CODE,
CASE WHEN B.CRNT_PLCY_TYPE_CODE = 'pec' THEN 'C' ELSE 'F' END YEAR_TYP,
CASE WHEN B.CRNT_PLCY_TYPE_CODE = 'pec' THEN 'CALENDER' ELSE 'FISCAL' END YEAR_LABEL
FROM DW_REPORT.DW_PLCY_END_OF_CHAIN_CMBNS A
JOIN DW_REPORT.DW_EMPLOYER_DEMOGRAPHICS B ON  A.EOC_PLCY_AGRE_ID = B.AGRE_ID
                                          AND A.EOC_PLCY_NO = B.PLCY_NO
                                          AND A.EOC_CUST_ID_ACCT_HLDR = B.EMPLR_CUST_ID
                                          AND A.EOC_BSNS_SQNC_NO = B.BUSN_SEQ_NO
where CRNT_PLCY_TYPE_CODE <> 'si';

/* STEP 2: 
   Creating 5 dummy rows for every policy with year number, year begining date and year ending date for current year and last 4 years.
*/

CREATE TEMPORARY TABLE EPM_TEMP_2  as
SELECT A.*, B.YEAR_YYYY_NO EPM_YEAR, B.CRNT_YEAR_BGNG_DATE YEAR_BGNG_DATE, B.CRNT_YEAR_ENDNG_DATE YEAR_ENDNG_DATE 
FROM EPM_TEMP_1 A
JOIN 
(
select distinct 'C' YEAR_TYP, YEAR_YYYY_NO, CRNT_YEAR_BGNG_DATE, CRNT_YEAR_ENDNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
union
select distinct 'F' YEAR_TYP, FISC_YYYY_NO, FSCL_YEAR_BGNG_DATE, FSCL_YEAR_ENDNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
) B ON A.YEAR_TYP = B.YEAR_TYP;

/* STEP 3:
   Payroll amount is calculated for policy for 5 years (current year through current year - 4)
*/

CREATE TEMPORARY TABLE EPM_TEMP_3  as
select * from
(SELECT 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
EFF_YYYY PAYROLL_YEAR,
sum(WC_COV_PREM_BS_VAL) PAYROLL_AMOUNT
FROM (
SELECT 
p.AGRE_ID,
PP.PLCY_NO,
p.CUST_ID_ACCT_HLDR,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT,
WCP.WC_COV_PREM_BS_VAL,
plcytyp.CTL_ELEM_SUB_TYP_CD,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd.YEAR_YYYY_NO else dd.FISC_YYYY_NO END EFF_YYYY,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd1.YEAR_YYYY_NO else dd1.FISC_YYYY_NO END END_YYYY
FROM pcmp.POLICY P
join PCMP.POLICY_PERIOD PP on p.AGRE_ID = pp.AGRE_ID and pp.VOID_IND = 'n'
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON PP.PLCY_PRD_ID=PCE.PLCY_PRD_ID AND PCE.CTL_ELEM_TYP_CD = 'rpt_freq'
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE C ON C.CTL_ELEM_SUB_TYP_ID=PCE.CTL_ELEM_SUB_TYP_ID AND C.CTL_ELEM_SUB_TYP_NM != 'Payment Plan'
INNER JOIN PCMP.PREMIUM_PERIOD PR ON PP.PLCY_PRD_ID=PR.PLCY_PRD_ID AND PR.PREM_TYP_CD='r' AND PR.VOID_IND='n'
LEFT JOIN PCMP.WC_COVERAGE_PREMIUM WCP ON pr.PREM_PRD_ID = wcp.PREM_PRD_ID AND WCP.WC_COV_PREM_VOID_IND = 'n'
join (
        select DISTINCT pp1.AGRE_ID, pp1.PLCY_NO, pp1.PLCY_PRD_ID, cest.CTL_ELEM_SUB_TYP_CD, cest.CTL_ELEM_SUB_TYP_NM
        from pcmp.POLICY_PERIOD pp1 
        join pcmp.AGREEMENT a1 on pp1.AGRE_ID = a1.AGRE_ID and a1.AGRE_TYP_CD = 'plcy'
        join pcmp.POLICY_CONTROL_ELEMENT pce on pp1.PLCY_PRD_ID = pce.PLCY_PRD_ID and pce.CTL_ELEM_TYP_CD = 'plcy_typ' and pce.VOID_IND = 'n'
        join pcmp.CONTROL_ELEMENT_SUB_TYPE cest on pce.CTL_ELEM_SUB_TYP_ID = cest.CTL_ELEM_SUB_TYP_ID and cest.CTL_ELEM_SUB_TYP_CD in ('pes', 'pec', 'bl', 'mif', 'pa')
        where pp1.VOID_IND = 'n' 
     ) plcytyp on p.AGRE_ID = plcytyp.AGRE_ID and PP.PLCY_NO = plcytyp.PLCY_NO and PP.PLCY_PRD_ID = plcytyp.PLCY_PRD_ID
join dw_report.DATE_DIM dd on pp.PLCY_PRD_EFF_DT = dd.ACTUAL_DT
join dw_report.DATE_DIM dd1 on DATEADD(DAY,-1, pp.PLCY_PRD_END_DT ) = dd1.ACTUAL_DT
where p.QUOT_NO is null and p.VOID_IND = 'n' and p.CUST_ID_ACCT_HLDR = wcp.CUST_ID_COV 
order by PP.PLCY_NO,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT
) X
WHERE 
EFF_YYYY = END_YYYY
group by 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
PAYROLL_YEAR
order by 
PLCY_NO,
PAYROLL_YEAR
) retrospective
union
select * from
(SELECT 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
EFF_YYYY PAYROLL_YEAR,
sum(WC_COV_PREM_BS_VAL) PAYROLL_AMOUNT
FROM (
SELECT 
p.AGRE_ID,
PP.PLCY_NO,
p.CUST_ID_ACCT_HLDR,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT,
WCP.WC_COV_PREM_BS_VAL,
plcytyp.CTL_ELEM_SUB_TYP_CD,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd.YEAR_YYYY_NO else dd.FISC_YYYY_NO END EFF_YYYY,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd1.YEAR_YYYY_NO else dd1.FISC_YYYY_NO END END_YYYY
FROM pcmp.POLICY P
join PCMP.POLICY_PERIOD PP on p.AGRE_ID = pp.AGRE_ID and pp.VOID_IND = 'n'
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON PP.PLCY_PRD_ID=PCE.PLCY_PRD_ID AND PCE.CTL_ELEM_TYP_CD = 'rpt_freq'
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE C ON C.CTL_ELEM_SUB_TYP_ID=PCE.CTL_ELEM_SUB_TYP_ID AND C.CTL_ELEM_SUB_TYP_NM = 'Payment Plan'
INNER JOIN PCMP.PREMIUM_PERIOD PR ON PP.PLCY_PRD_ID=PR.PLCY_PRD_ID AND PR.PREM_TYP_CD='a' AND PR.VOID_IND='n'
INNER JOIN PCMP.POLICY_PERIOD_AUDIT_DETAIL PAD ON PP.PLCY_PRD_ID=PAD.PLCY_PRD_ID AND PAD.PLCY_AUDT_TYP_CD in ('tu', 'fld') AND PAD.VOID_IND='n'
INNER JOIN PCMP.POLICY_PERIOD_AUDIT_STATUS PPAS on PAD.PLCY_PRD_AUDT_DTL_ID = PPAS.PLCY_PRD_AUDT_DTL_ID and PPAS.VOID_IND = 'n' and PPAS.PLCY_AUDT_STS_TYP_CD = 'comp'
LEFT JOIN PCMP.WC_COVERAGE_PREMIUM WCP ON PR.PREM_PRD_ID=WCP.PREM_PRD_ID AND WCP.WC_COV_PREM_VOID_IND = 'n' 
join (
        select  pp1.AGRE_ID, pp1.PLCY_NO, pp1.PLCY_PRD_ID, cest.CTL_ELEM_SUB_TYP_CD, cest.CTL_ELEM_SUB_TYP_NM
        from pcmp.POLICY_PERIOD pp1 
        join pcmp.AGREEMENT a1 on pp1.AGRE_ID = a1.AGRE_ID and a1.AGRE_TYP_CD = 'plcy'
        join pcmp.POLICY_CONTROL_ELEMENT pce on pp1.PLCY_PRD_ID = pce.PLCY_PRD_ID and pce.CTL_ELEM_TYP_CD = 'plcy_typ' and pce.VOID_IND = 'n'
        join pcmp.CONTROL_ELEMENT_SUB_TYPE cest on pce.CTL_ELEM_SUB_TYP_ID = cest.CTL_ELEM_SUB_TYP_ID and cest.CTL_ELEM_SUB_TYP_CD in ('pes', 'pec', 'bl', 'mif', 'pa')
        where pp1.VOID_IND = 'n'
     ) plcytyp on p.AGRE_ID = plcytyp.AGRE_ID and PP.PLCY_NO = plcytyp.PLCY_NO and PP.PLCY_PRD_ID = plcytyp.PLCY_PRD_ID
join dw_report.DATE_DIM dd on pp.PLCY_PRD_EFF_DT = dd.ACTUAL_DT
join dw_report.DATE_DIM dd1 on DATEADD(DAY,-1, pp.PLCY_PRD_END_DT ) = dd1.ACTUAL_DT
where p.QUOT_NO is null and p.VOID_IND = 'n' and p.CUST_ID_ACCT_HLDR = wcp.CUST_ID_COV 
order by PP.PLCY_NO,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT
) X
WHERE 
EFF_YYYY = END_YYYY
group by 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
PAYROLL_YEAR
order by 
PLCY_NO,
PAYROLL_YEAR
) prospective
;

/* STEP 4:
   Join step 2 and 3 on agreement id, policy number, payroll year and account holder customer id.
   Join with DW_EPM_CLAIM_SUMMARY table to calculate total claims entered by year, total days absent by year rolled up by policy.
   Calculate epm claim frequency count and epm sevarity count.
*/

CREATE TEMPORARY TABLE EPM_TEMP_4  as
SELECT 
A.*, 
NVL(B.PAYROLL_AMOUNT, 0) PAYROLL_AMOUNT, 
NVL(C.TOTAL_CLM_ENTRD, 0) TOTAL_CLM_ENTRD,  
NVL(C.TOTAL_DAYS_ABSENT, 0) TOTAL_DAYS_ABSENT,
case when NVL(B.PAYROLL_AMOUNT, 0) != 0 THEN ROUND(((NVL(C.TOTAL_CLM_ENTRD,0) * 1000000)/ NVL(B.PAYROLL_AMOUNT, 0)), 2) end EPM_CLM_FRQC_CNT,
case when NVL(B.PAYROLL_AMOUNT, 0) != 0 THEN ROUND(((NVL(C.TOTAL_DAYS_ABSENT,0) * 1000000)/NVL(B.PAYROLL_AMOUNT, 0)), 2) end EPM_SVR_CNT
FROM EPM_TEMP_2 A
LEFT JOIN EPM_TEMP_3 B ON  A.EOC_PLCY_AGRE_ID = B.AGRE_ID
                       AND A.EOC_CUST_ID_ACCT_HLDR = B.CUST_ID_ACCT_HLDR
                       AND A.EOC_PLCY_NO = B.PLCY_NO
                       AND A.EPM_YEAR = B.PAYROLL_YEAR
LEFT JOIN (
             SELECT 
             EOC_PLCY_NO, EOC_PLCY_AGRE_ID, EOC_CUST_ID_ACCT_HLDR, YEAR_TYPE_IND, 
             EPM_YEAR, SUM(DAYS_ABSNT_TTL_CNT) TOTAL_DAYS_ABSENT, SUM(CLM_ENTRD_IND) TOTAL_CLM_ENTRD
             FROM DW_REPORT.DW_EPM_CLAIM_SUMMARY
             GROUP BY EOC_PLCY_NO, EOC_PLCY_AGRE_ID, EOC_CUST_ID_ACCT_HLDR, YEAR_TYPE_IND, EPM_YEAR
          ) C ON  A.EOC_PLCY_AGRE_ID = C.EOC_PLCY_AGRE_ID
              AND A.EOC_CUST_ID_ACCT_HLDR = C.EOC_CUST_ID_ACCT_HLDR
              AND A.EOC_PLCY_NO = C.EOC_PLCY_NO
              AND A.EPM_YEAR = C.EPM_YEAR
;

truncate table DW_REPORT.DW_EPM_POLICY_SUMMARY;

/* STEP 5: Inserting data into table */

INSERT 
    /*+DIRECT*/
INTO 
DW_REPORT.DW_EPM_POLICY_SUMMARY
( 
  EOC_PLCY_AGRE_ID
, EOC_PLCY_NO
, EOC_CUST_ID_ACCT_HLDR
, EOC_EMPLR_LEGAL_NAME
, EOC_EMPLR_PHYS_ADRS_LINE1
, EOC_EMPLR_PHYS_ADRS_LINE2
, EOC_EMPLR_PHYS_ADRS_CITY_NAME
, EOC_EMPLR_PHYS_ADRS_STATE_NAME
, EOC_EMPLR_PHYS_ADRS_POST_CODE
, YEAR_TYPE_IND
, YEAR_TYPE_NAME
, EPM_YEAR
, EPM_YEAR_BGNG_DATE
, EPM_YEAR_ENDNG_DATE
, EOC_PYRL_AMT
, TTL_CLM_ENTRD_QTY
, TTL_DAYS_ABSNT_QTY
, EPM_CLM_FRQC_CNT
, EPM_SVRTY_CNT
, DW_CREATE_DTM
, DW_UPDATE_DTM
)
(
SELECT   EOC_PLCY_AGRE_ID
       , EOC_PLCY_NO
       , EOC_CUST_ID_ACCT_HLDR
       , EMPLR_LEGAL_NAME
       , EMPLR_PHYS_ADRS_LINE1
       , EMPLR_PHYS_ADRS_LINE2
       , EMPLR_PHYS_ADRS_CITY_NAME
       , EMPLR_PHYS_ADRS_STATE_NAME
       , EMPLR_PHYS_ADRS_POST_CODE
       , YEAR_TYP
       , YEAR_LABEL
       , EPM_YEAR
       , YEAR_BGNG_DATE
       , YEAR_ENDNG_DATE
       , PAYROLL_AMOUNT
       , TOTAL_CLM_ENTRD
       , TOTAL_DAYS_ABSENT
       , EPM_CLM_FRQC_CNT
       , EPM_SVR_CNT
	   , CURRENT_DATE DW_CREATE_DTM
       , CURRENT_DATE DW_UPDATE_DTM
from EPM_TEMP_4
)
;

COMMIT;