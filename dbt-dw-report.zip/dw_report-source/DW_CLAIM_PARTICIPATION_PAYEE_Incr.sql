--\set ON_ERROR_STOP on
TRUNCATE TABLE DW_REPORT.DW_CLAIM_PARTICIPATION_PAYEE;
INSERT /*+DIRECT*/ INTO DW_REPORT.DW_CLAIM_PARTICIPATION_PAYEE(
            CLM_PTCP_PAYE_ID,
            CLM_PTCP_ID,
            CLM_PTCP_PAYE_EFF_DT,
            CLM_PTCP_PAYE_END_DT,
            PAY_TYP_CD,
            PAY_TYP_NM,
            PAY_STS_TYP_CD,
            PAY_STS_TYP_NM,
			CRNT_IND,
            DW_CREATE_DTTM,
            DW_UPDATE_DTTM
        ) SELECT
            CPP.CLM_PTCP_PAYE_ID,
            CPP.CLM_PTCP_ID,
            CPP.CLM_PTCP_PAYE_EFF_DT,
            CPP.CLM_PTCP_PAYE_END_DT,
            CASE
                WHEN CPP.PAY_TYP_CD IS NULL
                THEN '-1'
                ELSE CPP.PAY_TYP_CD
            END PAY_TYP_CD,
            PAYT.PAY_TYP_NM,
            CASE
                WHEN CPP.PAY_STS_TYP_CD IS NULL
                THEN '-1'
                ELSE CPP.PAY_STS_TYP_CD
            END PAY_STS_TYP_CD,
            PAYST.PAY_STS_TYP_NM,
			CASE WHEN CPP.CLM_PTCP_PAYE_END_DT IS NULL 
			     THEN 'y' 
				 ELSE 'n'
			END  CRNT_IND,
            CURRENT_DATE DW_CREATE_DTTM,
            CURRENT_DATE DW_UPDATE_DTTM
        FROM
            PCMP.CLAIM_PARTICIPATION_PAYEE CPP LEFT OUTER JOIN PCMP.PAYMENT_TYPE PAYT
                ON CPP.PAY_TYP_CD = PAYT.PAY_TYP_CD LEFT OUTER JOIN PCMP.PAYMENT_STATUS_TYPE PAYST
                ON CPP.PAY_STS_TYP_CD = PAYST.PAY_STS_TYP_CD
        WHERE
            CPP.VOID_IND = 'n';COMMIT;