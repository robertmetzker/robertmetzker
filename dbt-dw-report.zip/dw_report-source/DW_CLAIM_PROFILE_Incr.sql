 --\set ON_ERROR_STOP on
-- TRUNCATE AND INSERT ROWS
TRUNCATE TABLE DW_REPORT.DW_CLAIM_PROFILE;
INSERT
    /*+DIRECT*/
    INTO
        DW_REPORT.DW_CLAIM_PROFILE(
            CLM_PRFL_ID,
            AGRE_ID,
            PTCP_ID,
            CLM_PRFL_CTG_TYP_CD,
            LOB_TYP_CD,
            PTCP_TYP_CD,
            JUR_TYP_CD,
            PRFL_STMT_ID,
            PRFL_STMT_DESC,
            PRFL_STMT_SEL_ID,
            PRFL_STMT_SEL_NEST_ID,
            PRFL_SEL_VAL_TYP_CD,
            CLM_PRFL_ANSW_TEXT,
            AUDIT_USER_CREA_DTM,
			AUDIT_USER_ID_CREA, 
			AUDIT_USER_ID_UPDT, 
			AUDIT_USER_UPDT_DTM,	
            VOID_IND,
            DW_CREATE_DTTM,
            DW_UPDATE_DTTM
        )(
            SELECT
                CP.CLM_PRFL_ID,
                CP.AGRE_ID,
                CP.PTCP_ID,
                CASE
                    WHEN CP.CLM_PRFL_CTG_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CP.CLM_PRFL_CTG_TYP_CD
                END CLM_PRFL_CTG_TYP_CD,
                CASE
                    WHEN CP.LOB_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CP.LOB_TYP_CD
                END LOB_TYP_CD,
                CASE
                    WHEN CP.PTCP_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CP.PTCP_TYP_CD
                END PTCP_TYP_CD,
                CASE
                    WHEN CP.JUR_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CP.JUR_TYP_CD
                END JUR_TYP_CD,
                CP.PRFL_STMT_ID,
                PS.PRFL_STMT_DESC,
                CP.PRFL_STMT_SEL_ID,
                CP.PRFL_STMT_SEL_NEST_ID,
                CASE
                    WHEN CP.PRFL_SEL_VAL_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CP.PRFL_SEL_VAL_TYP_CD
                END PRFL_SEL_VAL_TYP_CD,
                CP.CLM_PRFL_ANSW_TEXT,
                CP.AUDIT_USER_CREA_DTM,
				CP.AUDIT_USER_ID_CREA, 
				CP.AUDIT_USER_ID_UPDT, 
				CP.AUDIT_USER_UPDT_DTM,
                CP.VOID_IND,
                CURRENT_DATE AS DW_CREATE_DTTM,
                CURRENT_DATE AS DW_UPDATE_DTTM
            FROM
                PCMP.CLAIM_PROFILE CP LEFT JOIN PCMP.PROFILE_STATEMENT PS
                    ON CP.PRFL_STMT_ID = PS.PRFL_STMT_ID
        );COMMIT;