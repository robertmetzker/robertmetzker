/* DW_CLAIM_DEMOGRAPHICS - July 2017
	Updates:
	1. add claimant customer number CLMT_CUST_NO
	2. add 4 columns for HB 207 data
	3. add 5 columns for last paid dates, using new temp table
*/

/* Added filter to remove voided records from Claim Other Date, correcting the data in CATASTROPHIC_CLAIM_IND (sharepoint request #673)  -- Sep 2017 Release */

/* Added two COLUMNS OCCR_PRMS_TYP_CD & OCCR_PRMS_TYP_NM to the table as part of  request #972)  -- 26th June  2018 Release */

/* Added criteria to INNER JOIN on PCMP.CLAIM_PARTICIPATION table in sub-query cvrg as part of request #992  -- Jun 2018 Release */

/* Added 3 notification dates from PCMP.CLAIM: Claim Employer Notification Date, Claim Claimant Notification Date, Claim Administration Notification Date SP #1004  -- JULY 24 2018*/

/* sEPTEMBER 2018  -  SP# 952 - Remap Claim Demographics to remove dependency on DW_CLAIM
   sEPTEMBER 2018  -  SP# 1043 - Add claim fields to Claim Demographics
   sEPTEMBER 2018  -  SP# 1055 - Add field to Claim Demographics for First Indemnity Paid Date */

/* November 2021 - Update Initial Settled Indemnity Date and Initial Settled Medical Date to use History Dates, not Status Effective Dates, from Claim Status History */



--\set ON_ERROR_STOP on
TRUNCATE TABLE DW_REPORT.DW_CLAIM_DEMOGRAPHICS;

/* create temp table for last paid dates */

CREATE TEMPORARY TABLE CLM_LST_PAID  AS
select c.CLM_NO, c.AGRE_ID, 
last_comp_dpc.MAX_WRNT_DATE as WRNT_INDM_DATE,  
last_comp_cft.MAX_CFT_DATE as CFT_INDMN_DATE, 
last_comp_isd.MAX_ISD_DATE as ISD_INDMN_DATE, 
sc.MAX_SC_DATE as SC_INDMN_DATE,
nullif(greatest(
	coalesce(last_comp_dpc.MAX_WRNT_DATE, '1900-01-01'), coalesce(last_comp_cft.MAX_CFT_DATE, '1900-01-01'), 
	coalesce(last_comp_isd.MAX_ISD_DATE, '1900-01-01'), coalesce(sc.MAX_SC_DATE, '1900-01-01') ),'1900-01-01') as LAST_INDMN_PAID_DATE,
nullif(LEAST(
	coalesce(last_comp_dpc.MIN_WRNT_DATE, '2999-12-31'), coalesce(last_comp_cft.MIN_CFT_DATE, '2999-12-31'), 
	coalesce(last_comp_isd.MIN_ISD_DATE, '2999-12-31'), coalesce(sc.MIN_SC_DATE, '2999-12-31') ),'2999-12-31') as FIRST_INDMN_PAID_DATE,
last_comp_ext_dpc.MAX_WRNT_DATE as WRNT_EXTND_INDMN_DATE, 
last_comp_ext_cft.MAX_CFT_DATE as CFT_EXTND_INDMN_DATE, 
last_comp_ext_isd.MAX_ISD_DATE as ISD_EXTND_INDMN_DATE,
nullif(greatest(
	coalesce(last_comp_ext_dpc.MAX_WRNT_DATE, '1900-01-01'), coalesce(last_comp_ext_cft.MAX_CFT_DATE, '1900-01-01'), 
	coalesce(last_comp_ext_isd.MAX_ISD_DATE, '1900-01-01'), coalesce(sc.MAX_SC_DATE, '1900-01-01') ),'1900-01-01') as LAST_EXTND_INDMN_PAID_DATE,
last_mdcl.MAX_PAID_DATE as LAST_MDCL_PAID_DATE, 
last_mdcl_ext.MAX_PAID_DATE as LAST_EXTND_MDCL_PAID_DATE,
lss_dpc.MAX_WRNT_DATE as DPC_STLMN_DATE, 
lss_cft.MAX_CFT_DATE as CFT_STLMN_DATE, 
lss_isd.MAX_ISD_DATE as ISD_STLMN_DATE,
nullif(greatest(
	coalesce(lss_dpc.MAX_WRNT_DATE, '1900-01-01'), coalesce(lss_cft.MAX_CFT_DATE, '1900-01-01'), 
	coalesce(lss_isd.MAX_ISD_DATE, '1900-01-01') ),'1900-01-01') as LAST_STLMN_PAID_DATE
from PCMP.CLAIM c
left outer join (
	select dpc.CLAIM_NO, max(date(dpc.WRNT_DATE)) as MAX_WRNT_DATE,min(date(dpc.WRNT_DATE)) as MIN_WRNT_DATE
	from DW_REPORT.DW_TPYPCDQ dpc
	where BILL_TYPE_F2 in ('85', '89', '95', '96', '97', '98')
	and STS_CODE_DESC not in ('CANCELLED', 'VOID', 'VOIDED')
	group by dpc.CLAIM_NO
) last_comp_dpc on c.CLM_NO = last_comp_dpc.CLAIM_NO
left outer join (
	select dpc.CLAIM_NO, max(date(dpc.WRNT_DATE)) as MAX_WRNT_DATE
	from DW_REPORT.DW_TPYPCDQ dpc
	where BILL_TYPE_F2 in ('85', '89', '95', '96', '98') and BILL_TYPE_L3 <> '125'
	and STS_CODE_DESC not in ('CANCELLED', 'VOID', 'VOIDED')
	group by dpc.CLAIM_NO
) last_comp_ext_dpc on c.CLM_NO = last_comp_ext_dpc.CLAIM_NO
left outer join (
	select cft.AGRE_ID, max(date(cft.CFT_DT)) as MAX_CFT_DATE,MIN(date(cft.CFT_DT)) as MIN_CFT_DATE
	from DW_REPORT.DW_CLAIM_FINANCIAL_TRNSCTN cft
	where cft.PAY_TYP_CD = 'indm'  and cft.FNCL_TRAN_TYP_NM = 'Indemnity Due'
	group by cft.AGRE_ID
) last_comp_cft on c.AGRE_ID = last_comp_cft.AGRE_ID
left outer join (
	select cft.AGRE_ID, max(date(cft.CFT_DT)) as MAX_CFT_DATE
	from DW_REPORT.DW_CLAIM_FINANCIAL_TRNSCTN cft
	where cft.PAY_TYP_CD = 'indm' and cft.FNCL_TRAN_TYP_NM = 'Indemnity Due'
	and cft.BNFT_TYP_CD not in ('dwrfs-oh', 'lsaaf-oh', 'lsa-oh', 'lss-oh', 'miscls-oh', 'moi-oh', 'vssrs-oh') 
	group by cft.AGRE_ID
) last_comp_ext_cft on c.AGRE_ID = last_comp_ext_cft.AGRE_ID
left outer join (
	select ip.AGRE_ID, max(date(isd.INDM_SCH_DLVR_DT)) as MAX_ISD_DATE,MIN(date(isd.INDM_SCH_DLVR_DT)) as MIN_ISD_DATE
	from DW_REPORT.DW_INDEMNITY_PAYMENT ip
	inner join DW_REPORT.DW_INDEMNITY_SCHEDULE_DETAIL isd on ip.INDM_SCH_ID = isd.INDM_SCH_ID
	where isd.INDM_SCH_DLVR_DT <= CURRENT_DATE
	and isd.ISD_INDM_SCH_DTL_STS_TYP_NM = 'Paid' and isd.INDM_SCH_DET_VOID_IND = 'n'
	group by ip.AGRE_ID
) last_comp_isd on c.AGRE_ID = last_comp_isd.AGRE_ID
left outer join (
	select ip.AGRE_ID, max(date(isd.INDM_SCH_DLVR_DT)) as MAX_ISD_DATE
	from DW_REPORT.DW_INDEMNITY_PAYMENT ip
	inner join DW_REPORT.DW_INDEMNITY_SCHEDULE_DETAIL isd on ip.INDM_SCH_ID = isd.INDM_SCH_ID
	where isd.INDM_SCH_DLVR_DT <= CURRENT_DATE
	and isd.ISD_INDM_SCH_DTL_STS_TYP_NM = 'Paid' and isd.INDM_SCH_DET_VOID_IND = 'n'
	and ip.BNFT_TYP_CD not in ('dwrfs-oh', 'lsaaf-oh', 'lsa-oh', 'lss-oh', 'miscls-oh', 'moi-oh', 'vssrs-oh')
	group by ip.AGRE_ID
) last_comp_ext_isd on c.AGRE_ID = last_comp_ext_isd.AGRE_ID
left outer join (
	select AGRE_ID, MAX(date(INDM_PAY_END_DT)) as MAX_SC_DATE,MIN(date(INDM_PAY_END_DT)) as MIN_SC_DATE from PCMP.INDEMNITY_PAYMENT 
	where VOID_IND = 'n' and BNFT_TYP_CD in ('sclt-oh', 'scst-oh') group by AGRE_ID
) sc on c.AGRE_ID = sc.AGRE_ID
left outer join (
	SELECT trim(HAR.CLAIM_NO) as CLAIM_NO , MAX(HAR.MAX_PAID_DATE)	 AS MAX_PAID_DATE FROM 
(		
SELECT 	q1.CLAIM_NO, max(dd.PLUS1_BSNS_DAYS_DATE) as MAX_PAID_DATE FROM
(
SELECT AB.CLAIM_NO, AB.FIRST_SRVC_DATE,AB.PRCDR_CODE,AB.RX_NO,SUM(AB.PAID_AMT)AS PAID_AMT,
MAX(CASE WHEN AB.PAID_AMT > 0 THEN AB.ADJDC_DATE END)	AS ADJDC_DATE
FROM BWCODS.TDFMLIC AB 
WHERE AB.PAID_AMT <> 0
GROUP BY AB.CLAIM_NO,AB.FIRST_SRVC_DATE,AB.PRCDR_CODE,AB.RX_NO
HAVING SUM(AB.PAID_AMT) > 0
) q1
inner join DW_REPORT.DATE_DIM dd on q1.ADJDC_DATE = dd.ACTUAL_DT
	group by q1.CLAIM_NO
UNION 
	SELECT 	q1.CLAIM_NO, max(dd.PLUS1_BSNS_DAYS_DATE) as MAX_PAID_DATE FROM
(
	SELECT AB.CLAIM_NO, AB.FIRST_SRVC_DATE,AB.PRCDR_CODE,AB.RX_NO,SUM(AB.PAID_AMT)AS PAID_AMT,
MAX(CASE WHEN AB.PAID_AMT > 0 THEN AB.ADJDC_DATE END)	AS ADJDC_DATE
FROM BWCODS.TDFcLIC AB
WHERE AB.PAID_AMT <> 0
GROUP BY AB.CLAIM_NO,AB.FIRST_SRVC_DATE,AB.PRCDR_CODE,AB.RX_NO
HAVING SUM(AB.PAID_AMT) > 0
) q1
inner join DW_REPORT.DATE_DIM dd on q1.ADJDC_DATE = dd.ACTUAL_DT
	group by q1.CLAIM_NO
	) HAR
	GROUP BY HAR.CLAIM_NO
) last_mdcl on c.CLM_NO = last_mdcl.CLAIM_NO
left outer join (
	SELECT trim(HAR.CLAIM_NO) as CLAIM_NO, MAX(HAR.MAX_PAID_DATE)	 AS MAX_PAID_DATE FROM 
(		
	Select q1.CLAIM_NO, max(dd.PLUS1_BSNS_DAYS_DATE) as MAX_PAID_DATE
	from (
		select li.CLAIM_NO, li.FIRST_SRVC_DATE, li.PRCDR_CODE, li.RX_NO, sum(li.PAID_AMT) as PAID_AMT,  
		max(case when li.PAID_AMT > 0 then ADJDC_DATE end) as ADJDC_DATE 
		from BWCODS.TDFMLIC li
		where li.PAID_AMT <> 0
			and li.PRCDR_CODE not in (select PRCDR_CODE from DW_REPORT.V_DW_TDDMPXC)
		group by li.CLAIM_NO, li.FIRST_SRVC_DATE, li.PRCDR_CODE, li.RX_NO having sum(li.PAID_AMT) > 0
		) q1
		inner join DW_REPORT.DATE_DIM dd on q1.ADJDC_DATE = dd.ACTUAL_DT
	group by q1.CLAIM_NO
	UNION	
		Select q1.CLAIM_NO, max(dd.PLUS1_BSNS_DAYS_DATE) as MAX_PAID_DATE
	from (
		select li.CLAIM_NO, li.FIRST_SRVC_DATE, li.PRCDR_CODE, li.RX_NO, sum(li.PAID_AMT) as PAID_AMT,  
		max(case when li.PAID_AMT > 0 then ADJDC_DATE end) as ADJDC_DATE 
		from BWCODS.TDFCLIC li
		where li.PAID_AMT <> 0
				and li.PRCDR_CODE not in (select PRCDR_CODE from DW_REPORT.V_DW_TDDMPXC)
		group by li.CLAIM_NO, li.FIRST_SRVC_DATE, li.PRCDR_CODE, li.RX_NO having sum(li.PAID_AMT) > 0
		) q1
		inner join DW_REPORT.DATE_DIM dd on q1.ADJDC_DATE = dd.ACTUAL_DT
	group by q1.CLAIM_NO
	) HAR
	GROUP BY HAR.CLAIM_NO
) last_mdcl_ext on c.CLM_NO = last_mdcl_ext.CLAIM_NO
left outer join (
	select dpc.CLAIM_NO, max(date(dpc.WRNT_DATE)) as MAX_WRNT_DATE
	from DW_REPORT.DW_TPYPCDQ dpc
	where BILL_TYPE_F2 = '97'
	and STS_CODE_DESC not in ('CANCELLED', 'VOID', 'VOIDED')
	group by dpc.CLAIM_NO
) lss_dpc on c.CLM_NO = lss_dpc.CLAIM_NO
	left outer join (
	select cft.AGRE_ID, max(date(cft.CFT_DT)) as MAX_CFT_DATE
	from DW_REPORT.DW_CLAIM_FINANCIAL_TRNSCTN cft
	where cft.PAY_TYP_CD = 'indm' and cft.FNCL_TRAN_TYP_NM = 'Indemnity Due'
	and cft.BNFT_TYP_CD in ('dwrfs-oh', 'lss-oh', 'miscls-oh', 'vssrs-oh')
	group by cft.AGRE_ID
) lss_cft on c.AGRE_ID = lss_cft.AGRE_ID
left outer join (
	select ip.AGRE_ID, max(date(isd.INDM_SCH_DLVR_DT)) as MAX_ISD_DATE
	from DW_REPORT.DW_INDEMNITY_PAYMENT ip
	inner join DW_REPORT.DW_INDEMNITY_SCHEDULE_DETAIL isd on ip.INDM_SCH_ID = isd.INDM_SCH_ID
	where isd.INDM_SCH_DLVR_DT <= CURRENT_DATE
	and isd.ISD_INDM_SCH_DTL_STS_TYP_NM = 'Paid' and isd.INDM_SCH_DET_VOID_IND = 'n'
	and ip.BNFT_TYP_CD in ('dwrfs-oh', 'lss-oh', 'miscls-oh', 'vssrs-oh')
	group by ip.AGRE_ID
) lss_isd on c.AGRE_ID = lss_isd.AGRE_ID
where C.CLM_REL_SNPSHT_IND = 'n';



/* insert statement */
INSERT /*+DIRECT*/ INTO   DW_REPORT.DW_CLAIM_DEMOGRAPHICS
(CLM_AGRE_ID
,CLM_NO
,CLAIM_TYPE_CODE
,CLAIM_TYPE_NAME
,CLAIM_TYPE_EFF_DT
,JURISDICTION_TYPE_CODE
,JURISDICTION_TYPE_NAME
,CLM_FILE_MEDIA_TYPE_CODE
,CLM_FILE_MEDIA_TYPE_NAME
,CLM_FILE_SOURCE_TYPE_CODE
,CLM_FILE_SOURCE_TYPE_NAME
,CLAIM_FILE_DATE
,CLAIM_CMBND_IND
,CLAIM_ACDNT_DATETIME
,CLAIM_ACDNT_DATE
,ACDNT_CTGRY_CODE
,ACDNT_CTGRY_NAME
,ACDNT_TYPE_CODE
,ACDNT_TYPE_NAME
,CLM_ACDNT_DESCR
,CLM_CAUSE_CTGRY_CODE
,CLM_CAUSE_CTGRY_NAME
,CLM_CAUSE_TYPE_CODE
,CLM_CAUSE_TYPE_NAME
,ACDNT_LCTN_ADRS_1
,ACDNT_LCTN_ADRS_2
,ACDNT_LCTN_CITY_NAME
,ACDNT_LCTN_STATE_CODE 
,ACDNT_LCTN_STATE_NAME
,ACDNT_LCTN_POST_CODE
,ACDNT_LCTN_COUNTY_NAME
,CRNT_ASGN_EFF_DATE
,ASGND_USER_NUMBER
,ASGND_USER_NAME
,SUPERVISOR_NUMBER
,SUPERVISOR_NAME
,ASGND_SRVC_OFFICE
,ASGND_ORG_UNIT
,CLAIM_CREATE_DATETIME
,CLAIM_CREATE_USER_NUMBER
,CLAIM_CREATE_USER_NAME
,PLCY_AGRE_ID
,PLCY_NO
,BUSN_SEQ_NO
,PLCY_TYPE_CODE
,PLCY_TYPE_UPRCS_CODE
,PLCY_TYPE_NAME
,MCO_ID_NO
,MCO_NAME
,CLMT_CUST_ID
,CLMT_FULL_NAME
,CLMT_FULL_UPRCS_NAME
,CLMT_FIRST_NAME
,CLMT_MID_NAME
,CLMT_LAST_NAME
,CLMT_SUFFIX_NAME
,CLMT_BIRTH_DATE
,CLMT_DEATH_DATE
,CLMT_GENDER_TYPE_CODE
,CLMT_GENDER_TYPE_NAME
,CLMT_MARITAL_STATUS_TYPE_CODE
,CLMT_MARITAL_STATUS_TYPE_NAME
,CLMT_SSN
,CLMT_FRMTD_SSN 
,CLMT_JOB_TITLE
,CLMT_MANUAL_CLASS_CODE
,CLMT_SOC_CODE
,CLMT_JOB_TYPE_CODE
,CLMT_JOB_TYPE_NAME
,CLMT_HIRE_DATE
,CLMT_SHIFT_BEGIN_TIME
,CLMT_LAST_WORK_DATE
,CLMT_PHYS_ADRS_LINE1
,CLMT_PHYS_ADRS_LINE2
,CLMT_PHYS_ADRS_CITY_NAME
,CLMT_PHYS_ADRS_STATE_CODE
,CLMT_PHYS_ADRS_STATE_NAME
,CLMT_PHYS_ADRS_POST_CODE
,CLMT_PHYS_ADRS_COUNTY_NAME
,CLMT_PHYS_ADRS_COUNTRY_NAME
,CLMT_MAIL_ADRS_LINE1
,CLMT_MAIL_ADRS_LINE2
,CLMT_MAIL_ADRS_CITY_NAME
,CLMT_MAIL_ADRS_STATE_CODE
,CLMT_MAIL_ADRS_STATE_NAME
,CLMT_MAIL_ADRS_POST_CODE
,CLMT_MAIL_ADRS_COUNTY_NAME
,CLMT_MAIL_ADRS_COUNTRY_NAME
,CLMT_HOME_PHONE_NUMBER
,CLMT_HOME_FRMTD_PHONE_NUMBER
,CLMT_HOME_PHONE_EXTNS_NUMBER
,CLMT_THRTN_BHVR_IND
,CRNT_CLAIM_STATE_TYPE_CODE
,CRNT_CLAIM_STATE_TYPE_NAME
,CRNT_CLAIM_STATUS_TYPE_CODE
,CRNT_CLAIM_STATUS_TYPE_NAME
,CRNT_CLAIM_STS_RSN_TYPE_CODE
,CRNT_CLAIM_STS_RSN_TYPE_NAME
,CRNT_V3_MCO_CLAIM_STS_CD
,CRNT_V3_MCO_CLAIM_STS_NM
,CLAIM_STATUS_EFF_DATE
,CLAIM_STATE_EFF_DATE
,CLM_FST_DCSN_DT
,CLAIM_STAT_OF_LIMIT_DATE
,CLAIM_STAT_OF_LIMIT_OVRRD_DATE
,CATASTROPHIC_CLAIM_IND
,CATASTROPHIC_CLAIM_DATE
,TOTAL_MDCL_PAID_AMT
,TOTAL_INDM_PAID_AMT
,MED_ONLY_PRGRM_IND
,DW_CREATE_DTTM
,DW_UPDATE_DTTM 
,CLMT_PHYS_ADRS_VLDTD_IND
,CLMT_MAIL_ADRS_VLDTD_IND
,ORIG_PLCY_TYPE_CODE
,ORIG_PLCY_TYPE_NAME
,ORIG_CLAIM_TYPE_CODE
,ORIG_CLAIM_TYPE_NAME
,INTL_ACPT_DATE
,INTL_DENY_DATE
,INTL_STLD_INDM_DATE
,INTL_STLD_MDCL_DATE
,CRNT_CLMT_REP_IND
,FLNG_DATE_CLMT_REP_IND
,CRNT_CLAIM_CVRG_STS_TYP_CD
,CRNT_CLAIM_CVRG_STS_TYP_NM
,CRNT_CLAIM_CVRG_OVRRD_TYP_CD
,CRNT_CLAIM_CVRG_OVRRD_TYP_NM
,CRNT_CLAIM_CVRG_EFF_DATE
,UNSL_CLM_TYP_CD
,UNSL_CLM_TYP_NM
,EDUC_LVL_TYP_CD
,EDUC_LVL_TYP_NM
,CLM_EMPL_STS_TYP_CD
,CLM_EMPL_STS_TYP_NM
,CLM_ALCH_INVD_IND
,CLM_DRUG_INVD_IND
,CLM_NOTE_IND
,FOLD_ID
,FOLD_EFF_DTM
,FOLD_FILE_LOC_TEXT
,FOLD_LOC_STS_TEXT
,CTRPH_INJR_TYP_CD
,CTRPH_INJR_TYP_NM
,CLMT_EMAIL_ADDRESS
,ACDNT_LCTN_CNTRY_NAME
,ACP_PASSED_IND
,ACP_PASSED_DATE
,MMI_DATE
,CLMT_CUST_NO
,CRNT_CLAIM_EMPLR_EXPRN_ADJST_IND
,CRNT_CLAIM_EMPLR_EXPRN_ADJST_STS_CODE
,CRNT_CLAIM_EMPLR_EXPRN_ADJST_STS_NAME
,CRNT_CLAIM_EMPLR_EXPRN_ADJST_STS_EFCTV_DATE
,LAST_INDMN_PAID_DATE
,LAST_EXTND_INDMN_PAID_DATE
,LAST_MDCL_PAID_DATE
,LAST_EXTND_MDCL_PAID_DATE
,LAST_STLMN_PAID_DATE
,CRNT_HNDCP_RMBRS_STLMN_IND                
,CRNT_HNDCP_RMBRS_STLMN_STS_CODE           
,CRNT_HNDCP_RMBRS_STLMN_STS_NAME           
,CRNT_HNDCP_RMBRS_STLMN_STS_EFCTV_DATE
,CRNT_PRMRY_AOR_PTCP_ID    
,CRNT_PRMRY_AOR_CUST_ID    
,CRNT_PRMRY_AOR_CLM_PTCP_ID
,CRNT_PRMRY_AOR_NAME       
,CRNT_PRMRY_AOR_REP_ID 
,CRNT_PRMRY_POR_PTCP_ID    
,CRNT_PRMRY_POR_CUST_ID        
,CRNT_PRMRY_POR_CLM_PTCP_ID
,CRNT_PRMRY_POR_NAME       
,CRNT_PRMRY_POR_CUST_NO 
,CRNT_INSRD_PEO_IND
,OCCR_PRMS_TYP_CD
,OCCR_PRMS_TYP_NM
,CLMT_NTFCT_DATE
,EMPLR_NTFCT_DATE
,ADMIN_NTFCT_DATE
,CLM_CLMT_FATL_IND
,CLM_RCVR_TYP_CD
,CLM_RCVR_TYP_NM
,CLM_OCCR_TIME
,CLM_OCCR_RPT_TIME
,CLM_MULTI_OCCR_IND
,CLM_REL_SNPSHT_IND
,CLAIM_TYPE_END_DT
,CLAIM_STATUS_END_DATE
,CLAIM_CREATE_USER_ID
,CLAIM_UPDATE_USER_ID
,CLAIM_UPDATE_USER_NUMBER
,CLAIM_UPDATE_USER_NAME
,CLAIM_UPDATE_DATETIME
,FIRST_INDMN_PAID_DATE
) 
(select /*+ SYNTACTIC_JOIN,LABEL(L1_claim_demo_proj)*/ DISTINCT C.AGRE_ID
, c.CLM_NO
, CCT_NEW.CLM_TYP_CD as CLAIM_TYPE_CODE
, CCT_NEW.CLM_TYP_NM as CLAIM_TYPE_NAME
, CCT_NEW.CLM_CLM_TYP_EFF_DT as CLAIM_TYPE_EFF_DT
, c.JUR_TYP_CD as JURISDICTION_TYPE_CODE
, jt.JUR_TYP_NM as JURISDICTION_TYPE_NAME
, c.OCCR_MEDA_TYP_CD as CLM_FILE_MEDIA_TYPE_CODE
, OMT.OCCR_MEDA_TYP_NM as CLM_FILE_MEDIA_TYPE_NAME
, c.OCCR_SRC_TYP_CD as CLM_FILE_SOURCE_TYPE_CODE
, OST.OCCR_SRC_TYP_NM as CLM_FILE_SOURCE_TYPE_NAME
, to_date(to_char(C.CLM_OCCR_RPT_DT,'YYYY-MM-DD'),'YYYY-MM-DD') as CLAIM_FILE_DATE      
, CASE WHEN CS.CLM_TRANS_RSN_TYP_CD = 'dup' AND CAN2.AGRE_ID IS NOT NULL
                  THEN 'y' ELSE 'n'  END AS CLAIM_CMBND_IND
, c.CLM_OCCR_DTM as CLAIM_ACDNT_DATETIME
, DATE_TRUNC('DAY', c.CLM_OCCR_DTM) as CLAIM_ACDNT_DATE
, c.NOI_CTG_TYP_CD as ACDNT_CTGRY_CODE
, NOICT.NOI_CTG_TYP_NM as ACDNT_CTGRY_NAME
, c.NOI_TYP_CD as ACDNT_TYPE_CODE
, NOIT.NOI_TYP_NM as ACDNT_TYPE_NAME
, c.CLM_LOSS_DESC as CLM_ACDNT_DESCR
, CASE WHEN c.CAUS_OF_LOSS_CTG_TYP_CD IS NULL THEN '-1' ELSE c.CAUS_OF_LOSS_CTG_TYP_CD END as CLM_CAUSE_CTGRY_CODE
, COLCT.CAUS_OF_LOSS_CTG_TYP_NM as CLM_CAUSE_CTGRY_NAME                             
, CASE WHEN c.CAUS_OF_LOSS_TYP_CD IS NULL THEN '-1' ELSE c.CAUS_OF_LOSS_TYP_CD END   as CLM_CAUSE_TYPE_CODE
, COLT.CAUS_OF_LOSS_TYP_NM as CLM_CAUSE_TYPE_NAME
, c.CLM_OCCR_LOC_STR_1 as ACDNT_LCTN_ADRS_1
, c.CLM_OCCR_LOC_STR_2 as ACDNT_LCTN_ADRS_2
, c.CLM_OCCR_LOC_CITY_NM as ACDNT_LCTN_CITY_NAME
, stt.STT_ABRV as ACDNT_LCTN_STATE_CODE
, stt.STT_NM as ACDNT_LCTN_STATE_NAME
, CASE WHEN c.CLM_OCCR_LOC_POST_CD IS NULL THEN '-1' ELSE c.CLM_OCCR_LOC_POST_CD END as ACDNT_LCTN_POST_CODE
, c.CLM_OCCR_LOC_CNTY_NM as ACDNT_LCTN_COUNTY_NAME
, a.ASGN_EFF_DT as CRNT_ASGN_EFF_DATE
, au.USER_LGN_NM as ASGND_USER_NUMBER                                                 
, au.USER_DRV_UPCS_NM as ASGND_USER_NAME
, su.USER_LGN_NM as SUPERVISOR_NUMBER 
, su.USER_DRV_UPCS_NM as SUPERVISOR_NAME
, du.USER_DRV_UPCS_NM as ASGND_SRVC_OFFICE 
, ou.ORG_UNT_NM as ASGND_ORG_UNIT
, c.AUDIT_USER_CREA_DTM as CLAIM_CREATE_DATETIME
, cu.USER_LGN_NM as CLAIM_CREATE_USER_NUMBER
, cu.USER_DRV_UPCS_NM as CLAIM_CREATE_USER_NAME
, cph.PLCY_AGRE_ID
, cph.PLCY_NO
, cph.BUSN_SEQ_NO                                                                                   
, cph.CTL_ELEM_SUB_TYP_CD as PLCY_TYPE_CODE
, upper(cph.CTL_ELEM_SUB_TYP_CD) as PLCY_TYPE_UPRCS_CODE
, cph.CTL_ELEM_SUB_TYP_NM as PLCY_TYPE_NAME
, TRIM(memp.MCO_ID_NO)     AS MCO_ID_NO                                   
, TRIM(mco.NTWRK_NAME) as MCO_NAME
, cn.CUST_ID as CLMT_CUST_ID
, cn.CUST_NM_NM as CLMT_FULL_NAME
, cn.CUST_NM_DRV_UPCS_NM as CLMT_FULL_UPRCS_NAME
, cn.CUST_NM_FST as CLMT_FIRST_NAME
, cn.CUST_NM_MID as CLMT_MID_NAME
, cn.CUST_NM_LST as CLMT_LAST_NAME                                                           
, cnst.CUST_NM_SFX_TYP_NM as CLMT_SUFFIX_NAME
, prsn.PRSN_BRTH_DTM as CLMT_BIRTH_DATE
, prsn.PRSN_DTH_DTM as CLMT_DEATH_DATE
, coalesce(prsn.GNDR_TYP_CD, '-1') as CLMT_GENDER_TYPE_CODE
, gt.GNDR_TYP_NM as CLMT_GENDER_TYPE_NAME
, coalesce(prsn.MAR_STS_TYP_CD, '-1') as CLMT_MARITAL_STATUS_TYPE_CODE
, mst.MAR_STS_TYP_NM as CLMT_MARITAL_STATUS_TYPE_NAME
, ti.TAX_ID_NO as CLMT_SSN
, left(ti.TAX_ID_NO,3) || '-' || substr(ti.TAX_ID_NO,4,2) || '-' || right(ti.TAX_ID_NO,4) as CLMT_FRMTD_SSN
, c.CLM_CLMT_JOB_TTL as CLMT_JOB_TITLE
, cch.ADJST_CLASS_CODE as CLMT_MANUAL_CLASS_CODE
, soc.CLM_PRFL_ANSW_TEXT as CLMT_SOC_CODE
, case when cph.CTL_ELEM_SUB_TYP_CD in ('pec', 'pes') then 'P'
       when cph.CTL_ELEM_SUB_TYP_CD = 'pa' and c.CLM_OCCR_DTM < '1996-07-01' then 'S'
       when cph.CTL_ELEM_SUB_TYP_CD = 'pa' and c.CLM_OCCR_DTM >= '1996-07-01' then 'N'
       else 'N' end as CLMT_JOB_TYPE_CODE
, case when cph.CTL_ELEM_SUB_TYP_CD in ('pec', 'pes') then 'SOC'
       when cph.CTL_ELEM_SUB_TYP_CD = 'pa' and c.CLM_OCCR_DTM < '1996-07-01' then 'OSIF'
       when cph.CTL_ELEM_SUB_TYP_CD = 'pa' and c.CLM_OCCR_DTM >= '1996-07-01' then 'NCCI'
       else 'NCCI' end as CLMT_JOB_TYPE_NAME
, c.CLM_CLMT_HIRE_DT as CLMT_HIRE_DATE
, c.CLM_CLMT_SHFT_BGN_TIME as CLMT_SHIFT_BEGIN_TIME  
, c.CLM_CLMT_LST_WK_DT as CLMT_LAST_WORK_DATE  
, cap.CUST_ADDR_STR_1 as CLMT_PHYS_ADRS_LINE1
, cap.CUST_ADDR_STR_2 as CLMT_PHYS_ADRS_LINE2
, cap.CUST_ADDR_CITY_NM as CLMT_PHYS_ADRS_CITY_NAME
, sttp.STT_ABRV as CLMT_PHYS_ADRS_STATE_CODE
, sttp.STT_NM as CLMT_PHYS_ADRS_STATE_NAME
, cap.CUST_ADDR_POST_CD as CLMT_PHYS_ADRS_POST_CODE
, cap.CUST_ADDR_CNTY_NM as CLMT_PHYS_ADRS_COUNTY_NAME
, cyp.CNTRY_NM as CLMT_PHYS_ADRS_COUNTRY_NAME
, cam.CUST_ADDR_STR_1 as CLMT_MAIL_ADRS_LINE1
, cam.CUST_ADDR_STR_2 as CLMT_MAIL_ADRS_LINE2
, cam.CUST_ADDR_CITY_NM as CLMT_MAIL_ADRS_CITY_NAME  
, sttm.STT_ABRV as CLMT_MAIL_ADRS_STATE_CODE   
, sttm.STT_NM as CLMT_MAIL_ADRS_STATE_NAME
, cam.CUST_ADDR_POST_CD as CLMT_MAIL_ADRS_POST_CODE
, cam.CUST_ADDR_CNTY_NM as CLMT_MAIL_ADRS_COUNTY_NAME
, cym.CNTRY_NM as CLMT_MAIL_ADRS_COUNTRY_NAME
, cich.CUST_INTRN_CHNL_PHN_NO as CLMT_HOME_PHONE_NUMBER
, case when length(cich.CUST_INTRN_CHNL_PHN_NO) = 10
       then '(' || left(cich.CUST_INTRN_CHNL_PHN_NO,3) || ') ' || substr(cich.CUST_INTRN_CHNL_PHN_NO,4,3) || '-' || right(cich.CUST_INTRN_CHNL_PHN_NO,4)
       when length(cich.CUST_INTRN_CHNL_PHN_NO) = 7
       then left(cich.CUST_INTRN_CHNL_PHN_NO,3) || '-' || right(cich.CUST_INTRN_CHNL_PHN_NO,4)
       else null end as CLMT_HOME_FRMTD_HOME_PHONE_NUMBER
, cich.CUST_INTRN_CHNL_PHN_NO_EXT as CLMT_HOME_PHONE_EXTNS_NUMBER
, case when blk.CUST_ID is not null then 'y' else 'n' end as CLMT_THRTN_BHVR_IND
, S.STT_TYP_CD as CRNT_CLAIM_STATE_TYPE_CODE                                                      
, S.STT_TYP_NM as CRNT_CLAIM_STATE_TYPE_NAME
, S.STS_TYP_CD as CRNT_CLAIM_STATUS_TYPE_CODE
, S.STS_TYP_NM as CRNT_CLAIM_STATUS_TYPE_NAME                                 
, S.TRANS_RSN_TYP_CD as CRNT_CLAIM_STS_RSN_TYPE_CODE      
, S.TRANS_RSN_TYP_NM as CRNT_CLAIM_STS_RSN_TYPE_NAME
, stsx.V3_MCO_CLAIM_STS_CD as CRNT_V3_MCO_CLAIM_STS_CD
, stsx.V3_MCO_CLAIM_STS_NM as CRNT_V3_MCO_CLAIM_STS_NM
, cs.CLM_CLM_STS_EFF_DT as CLAIM_STATUS_EFF_DATE
, cs.CLM_CLM_STS_STT_DT as CLAIM_STATE_EFF_DATE
, c.CLM_FST_DCSN_DT                                                
, CAA.CLM_STATU_LMT_DT as CLAIM_STAT_OF_LIMIT_DATE
, cod.CLAIM_STAT_OF_LIMIT_OVRRD_DATE
, case when cod2.CATASTROPHIC_CLAIM_DATE is not null then 'y' else 'n' end as CATASTROPHIC_CLAIM_IND
, cod2.CATASTROPHIC_CLAIM_DATE
, cbse.CBSE_TOT_MED_PD_TO_DT as TOTAL_MDCL_PAID_AMT                      
, csd.CSD_INDM_PD_AMT as TOTAL_INDM_PAID_AMT
, case when mop.CLM_PRFL_ANSW_TEXT = 'yes' then 'y' else 'n' end as MED_ONLY_PRGRM_IND
, CURRENT_DATE AS DW_CREATE_DTTM
, CURRENT_DATE AS DW_UPDATE_DTTM
, cap.VLDTD_IND as CLMT_PHYS_ADRS_VLDTD_IND
, cam.VLDTD_IND as CLMT_MAIL_ADRS_VLDTD_IND
, ort.ORIG_PLCY_TYPE_CODE
, ort.ORIG_PLCY_TYPE_NAME
, oct.ORIG_CLAIM_TYPE_CODE
, oct.ORIG_CLAIM_TYPE_NAME
, sa.INTL_ACPT_DATE
, sd.INTL_DENY_DATE
, si.INTL_STLD_INDM_DATE
, sm.INTL_STLD_MDCL_DATE
, case when crf_crnt.AGRE_ID is not null then 'y' else 'n' end as CRNT_CLMT_REP_IND
, case when crf_dof.AGRE_ID is not null then 'y' else 'n' end as FLNG_DATE_CLMT_REP_IND
, cvrg.CLM_COV_STS_TYP_CD as CRNT_CLAIM_CVRG_STS_TYP_CD
, cvrg.CLM_COV_STS_TYP_NM as CRNT_CLAIM_CVRG_STS_TYP_NM
, cvrg.CLM_COV_OVRRD_TYP_CD as CRNT_CLAIM_CVRG_OVRRD_TYP_CD
, cvrg.CLM_COV_OVRRD_TYP_NM as CRNT_CLAIM_CVRG_OVRRD_TYP_NM
, cvrg.CLM_CVRG_EFF_DATE as CRNT_CLAIM_CVRG_EFF_DATE
, CASE WHEN c.UNSL_CLM_TYP_CD IS NULL THEN '-1' ELSE c.UNSL_CLM_TYP_CD END AS UNSL_CLM_TYP_CD
, UCT.UNSL_CLM_TYP_NM
, CASE WHEN c.EDUC_LVL_TYP_CD IS NULL THEN '-1' ELSE c.EDUC_LVL_TYP_CD END AS EDUC_LVL_TYP_CD
, ELT.EDUC_LVL_TYP_NM
, c.CLM_EMPL_STS_TYP_CD
, CEST.CLM_EMPL_STS_TYP_NM
, c.CLM_ALCH_INVD_IND
, c.CLM_DRUG_INVD_IND
, c.CLM_NOTE_IND
, fold.FOLD_ID
, fold.FOLD_EFF_DT
, fold.FOLD_FILE_LOC
, fold.FOLD_LOC_STS
, CASE WHEN  c.CTRPH_INJR_TYP_CD IS NULL THEN '-1' ELSE c.CTRPH_INJR_TYP_CD END AS CTRPH_INJR_TYP_CD
, catinj.CTRPH_INJR_TYP_NM
, cice.CUST_INTRN_CHNL_ADDR as CLMT_EMAIL_ADDRESS
, cntry.CNTRY_NM as ACDNT_LCTN_CNTRY_NAME
, coalesce(acp.ACP_PASSED_IND, 'n') as ACP_PASSED_IND
, acp.ACP_PASSED_DATE
, mmi.MMI_DATE
, cust.CUST_NO as CLMT_CUST_NO
, coalesce(emp_exp_adj.IND, 'n') as CRNT_CLAIM_EMPLR_EXPRN_ADJST_IND
, emp_exp_adj.STS_CODE as CRNT_CLAIM_EMPLR_EXPRN_ADJST_STS_CODE
, emp_exp_adj.STS_NAME as CRNT_CLAIM_EMPLR_EXPRN_ADJST_STS_NAME
, emp_exp_adj.STS_DATE as CRNT_CLAIM_EMPLR_EXPRN_ADJST_STS_EFCTV_DATE
, clp.LAST_INDMN_PAID_DATE as LAST_INDMN_PAID_DATE
, clp.LAST_EXTND_INDMN_PAID_DATE as LAST_EXTND_INDMN_PAID_DATE
, clp.LAST_MDCL_PAID_DATE as LAST_MDCL_PAID_DATE
, clp.LAST_EXTND_MDCL_PAID_DATE as LAST_EXTND_MDCL_PAID_DATE
, clp.LAST_STLMN_PAID_DATE as LAST_STLMN_PAID_DATE
, HB27.CRNT_HNDCP_RMBRS_STLMN_IND                
, HB27.CRNT_HNDCP_RMBRS_STLMN_STS_CODE           
, HB27.CRNT_HNDCP_RMBRS_STLMN_STS_NAME           
, HB27.CRNT_HNDCP_RMBRS_STLMN_STS_EFCTV_DATE
, AOR.CRNT_PRMRY_AOR_PTCP_ID    
, AOR.CRNT_PRMRY_AOR_CUST_ID    
, AOR.CRNT_PRMRY_AOR_CLM_PTCP_ID
, AOR.CRNT_PRMRY_AOR_NAME       
, AOR.CRNT_PRMRY_AOR_REP_ID 
, POR.CRNT_PRMRY_POR_PTCP_ID    
, POR.CRNT_PRMRY_POR_CUST_ID        
, POR.CRNT_PRMRY_POR_CLM_PTCP_ID
, POR.CRNT_PRMRY_POR_NAME       
, POR.CRNT_PRMRY_POR_CUST_NO  
, cvrg.CLM_PTCP_INSRD_PEO_IND as CRNT_INSRD_PEO_IND
, CASE WHEN OCCRTC.OCCR_PRMS_TYP_CD IS NULL THEN '-1' ELSE OCCRTC.OCCR_PRMS_TYP_CD END AS OCCR_PRMS_TYP_CD 
, OCCRTC.OCCR_PRMS_TYP_NM AS OCCR_PRMS_TYP_NM
, CLMT_NTFCT_DATE
, EMPLR_NTFCT_DATE
, ADMIN_NTFCT_DATE
, C.CLM_CLMT_FATL_IND AS CLM_CLMT_FATL_IND
, CASE WHEN C.CLM_RCVR_TYP_CD IS NULL THEN '-1' ELSE C.CLM_RCVR_TYP_CD END AS CLM_RCVR_TYP_CD
, CRT.CLM_RCVR_TYP_NM AS CLM_RCVR_TYP_NM
, CAST(TO_CHAR(C.CLM_OCCR_DTM,'hh:mi:ss') AS TIME(6)) AS CLM_OCCR_TIME
, NULL::TIMESTAMP AS CLM_OCCR_RPT_TIME
, C.CLM_MULTI_OCCR_IND AS CLM_MULTI_OCCR_IND
, C.CLM_REL_SNPSHT_IND AS CLM_REL_SNPSHT_IND
, DATE(CCT_NEW.CLM_CLM_TYP_END_DT) AS CLAIM_TYPE_END_DT
, DATE(CS.CLM_CLM_STS_END_DT) AS CLAIM_STATUS_END_DATE
, C.AUDIT_USER_ID_CREA AS CLAIM_CREATE_USER_ID
, C.AUDIT_USER_ID_UPDT AS CLAIM_UPDATE_USER_ID
, CUNN.USER_LGN_NM AS CLAIM_UPDATE_USER_NUMBER
, CUNN.USER_DRV_UPCS_NM AS CLAIM_UPDATE_USER_NAME
, C.AUDIT_USER_UPDT_DTM AS CLAIM_UPDATE_DATETIME
, clp.FIRST_INDMN_PAID_DATE
from PCMP.CLAIM C
inner join PCMP.JURISDICTION_TYPE jt on c.JUR_TYP_CD = jt.JUR_TYP_CD and c.CLM_REL_SNPSHT_IND = 'n'
inner join PCMP.PARTICIPATION p on C.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'clmt'
inner join PCMP.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.VOID_IND = 'n' and cp.CLM_PTCP_PRI_IND = 'y'
inner join PCMP.CUSTOMER_NAME cn on p.CUST_ID = cn.CUST_ID 
	and cn.CUST_NM_TYP_CD = 'prsn_nm' and cn.VOID_IND = 'n' 
	and cn.CUST_NM_EFF_DT <= CURRENT_DATE and (cn.CUST_NM_END_DT > CURRENT_DATE or cn.CUST_NM_END_DT is null)
inner join PCMP.CUSTOMER cust on p.CUST_ID = cust.CUST_ID
inner join PCMP.PERSON prsn on p.CUST_ID = prsn.CUST_ID
INNER JOIN (SELECT * FROM PCMP.CLAIM_CLAIM_STATUS ORDER BY AGRE_ID)  CS ON C.AGRE_ID = CS.AGRE_ID 
 INNER JOIN (SELECT * FROM DW_REPORT.DW_STATUS ORDER BY STS_TYP_CD, STT_TYP_CD, TRANS_RSN_TYP_CD, PLCY_CLM_IND) S ON CS.CLM_STS_TYP_CD = S.STS_TYP_CD  AND CS.CLM_STT_TYP_CD = S.STT_TYP_CD  
 	AND CS.CLM_TRANS_RSN_TYP_CD = S.TRANS_RSN_TYP_CD  AND S.PLCY_CLM_IND = 'CLM'
left outer join DW_REPORT.DW_CLAIM_POLICY_HISTORY cph on C.AGRE_ID = cph.CLM_AGRE_ID
	 and cph.CRNT_PLCY_IND = 'y'
left outer join PCMP.GENDER_TYPE gt on prsn.GNDR_TYP_CD = gt.GNDR_TYP_CD
left outer join PCMP.MARITAL_STATUS_TYPE mst on prsn.MAR_STS_TYP_CD = mst.MAR_STS_TYP_CD
left outer join PCMP.STATE stt on c.STT_ID = stt.STT_ID
left outer join PCMP.CLAIM_BILL_SUMMARY_EXTERNAL cbse on C.AGRE_ID = cbse.AGRE_ID
left outer join DW_REPORT.DW_CLAIM_CLASS_CODE_HISTORY cch on C.AGRE_ID = cch.CLM_AGRE_ID and cch.CRNT_IND = 'y'
left outer join PCMP.WC_CLASS wc on cch.ADJST_CLASS_CODE = wc.WC_CLS_CLS_CD and wc.WC_CLS_END_DT is null and wc.WC_CLS_VOID_IND = 'n'
left outer join DW_REPORT.DW_CLAIM_STATUS_V3_PCMP_XREF stsx on s.STT_TYP_CD = stsx.PCMP_CLAIM_STT_TYP_CD
	and S.STS_TYP_CD = stsx.PCMP_CLAIM_STS_TYP_CD and s.TRANS_RSN_TYP_CD = stsx.PCMP_CLAIM_TRANS_RSN_TYP_CD
left outer join (
       select cs1.CS_ID, cs1.CS_CLM_NO, cs1.CS_END_DT from PCMP.CLAIM_SUMMARY cs1
       inner join (select CS_CLM_NO, max(CS_ID) as MAX_CS_ID from PCMP.CLAIM_SUMMARY where CS_END_DT is null and VOID_IND = 'n' group by CS_CLM_NO) cs2
       on  cs1.CS_CLM_NO = cs2.CS_CLM_NO and cs1.CS_ID = cs2.MAX_CS_ID and cs1.CS_END_DT is null and cs1.VOID_IND = 'n'
) csum on c.CLM_NO = csum.CS_CLM_NO
left outer join PCMP.CLAIM_SUMMARY_DTL csd on csum.CS_ID = csd.CS_ID and csd.VOID_IND = 'n'
left outer join BWCODS.THFMEMP memp on cph.PLCY_NO = lpad(memp.PLCY_NO::varchar, 8, '0'::varchar(1)) 
	and memp.CRNT_RLTNS_FLAG = 'Y' and memp.MCO_ID_NO like '1%'
left outer join BWCODS.TDFNTWD mco on memp.MCO_ID_NO = mco.MCO_ID_NO
left outer join PCMP.TAX_IDENTIFIER ti on p.CUST_ID = ti.CUST_ID 
	and ti.TAX_ID_TYP_CD = 'ssn' and ti.TAX_ID_END_DT is null and ti.VOID_IND = 'n'
left outer join PCMP.CUSTOMER_NAME_SUFFIX_TYPE cnst on cn.CUST_NM_SFX_TYP_CD = cnst.CUST_NM_SFX_TYP_CD
left outer join (
	select a3.ASGN_CNTX_ID, FNCT_ROLE_ID, ORG_UNT_ID, USER_ID, a3.AUDIT_USER_CREA_DTM, a3.AUDIT_USER_UPDT_DTM, 
	ASGN_EFF_DT, ASGN_END_DT, ASGN_PRI_OWNR_IND from PCMP.ASSIGNMENT a3
	inner join (
		select a1.ASGN_CNTX_ID, a1.AUDIT_USER_CREA_DTM, max(a1.ASGN_ID) as MAX_ASGN_ID from PCMP.ASSIGNMENT a1
		inner join (
			select ASGN_CNTX_ID, max(AUDIT_USER_CREA_DTM) as MAX_DTM from PCMP.ASSIGNMENT 
			where APP_CNTX_TYP_CD = 'claim' and ASGN_END_DT is null and ASGN_PRI_OWNR_IND = 'y'
			group by ASGN_CNTX_ID
		) a2 on a1.ASGN_CNTX_ID = a2.ASGN_CNTX_ID and a1.AUDIT_USER_CREA_DTM = a2.MAX_DTM and a1.ASGN_END_DT is null and a1.ASGN_PRI_OWNR_IND = 'y'
		group by a1.ASGN_CNTX_ID, a1.AUDIT_USER_CREA_DTM
	) max_asgn on a3.ASGN_ID = max_asgn.MAX_ASGN_ID and a3.ASGN_CNTX_ID = max_asgn.ASGN_CNTX_ID and a3.AUDIT_USER_CREA_DTM = max_asgn.AUDIT_USER_CREA_DTM
	where a3.APP_CNTX_TYP_CD = 'claim' and a3.ASGN_END_DT is null and a3.ASGN_PRI_OWNR_IND = 'y'
) a on a.ASGN_CNTX_ID = C.AGRE_ID
left outer join PCMP.USERS au on a.USER_ID = au.USER_ID
left outer join PCMP.USERS su on au.USER_SUPR_ID = su.USER_ID
left outer join PCMP.USERS du on su.USER_SUPR_ID = du.USER_ID  --April 2022 change to get S.O. director name
left outer join PCMP.ORGANIZATIONAL_UNIT ou on a.ORG_UNT_ID = ou.ORG_UNT_ID
left outer join PCMP.USERS cu on c.AUDIT_USER_ID_CREA = cu.USER_ID
left outer join (
       select cap1.CUST_ID, cap1.CUST_ADDR_STR_1, cap1.CUST_ADDR_STR_2, cap1.CUST_ADDR_CITY_NM, cap1.STT_ID, 
       cap1.CUST_ADDR_POST_CD, cap1.CUST_ADDR_CNTY_NM, cap1.CNTRY_ID, cap1.CUST_ADDR_VLDT_PRFM_IND as VLDTD_IND
       from PCMP.CUSTOMER_ADDRESS cap1
       inner join (
       		select a.CUST_ID, b.MAX_CRT_DTM, b.MAX_EFF_DT, max(a.CUST_ADDR_VLDT_PRFM_IND) as MAX_VLDTD_IND
       		from PCMP.CUSTOMER_ADDRESS a
       		inner join (
       		select CUST_ID, CUST_ADDR_TYP_CD, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DTM, max(CUST_ADDR_EFF_DT) as MAX_EFF_DT
       		from PCMP.CUSTOMER_ADDRESS where CUST_ADDR_TYP_CD = 'phys' and VOID_IND = 'n'
       		and CUST_ADDR_EFF_DT <= CURRENT_DATE and (CUST_ADDR_END_DT > CURRENT_DATE or CUST_ADDR_END_DT is null)
       		group by CUST_ID, CUST_ADDR_TYP_CD
       		) b on a.CUST_ID = b.CUST_ID and a.CUST_ADDR_TYP_CD = b.CUST_ADDR_TYP_CD and a.CUST_ADDR_TYP_CD = 'phys'
       		and a.AUDIT_USER_CREA_DTM = b.MAX_CRT_DTM and a.CUST_ADDR_EFF_DT = b.MAX_EFF_DT and a.VOID_IND = 'n'
       		and a.CUST_ADDR_EFF_DT <= CURRENT_DATE and (a.CUST_ADDR_END_DT > CURRENT_DATE or a.CUST_ADDR_END_DT is null)
       		group by a.CUST_ID, b.MAX_CRT_DTM, b.MAX_EFF_DT
       ) cap2 on cap1.CUST_ID = cap2.CUST_ID and cap1.AUDIT_USER_CREA_DTM = cap2.MAX_CRT_DTM 
       		and cap1.CUST_ADDR_EFF_DT = cap2.MAX_EFF_DT and cap1.CUST_ADDR_VLDT_PRFM_IND = cap2.MAX_VLDTD_IND
       where cap1.CUST_ADDR_TYP_CD = 'phys' and cap1.VOID_IND = 'n' 
       and cap1.CUST_ADDR_EFF_DT <= CURRENT_DATE and (cap1.CUST_ADDR_END_DT > CURRENT_DATE or cap1.CUST_ADDR_END_DT is null)
) cap on p.CUST_ID = cap.CUST_ID 
left outer join PCMP.STATE sttp on cap.STT_ID = sttp.STT_ID
left outer join PCMP.COUNTRY cyp on cap.CNTRY_ID = cyp.CNTRY_ID
left outer join (
       select cam1.CUST_ID, cam1.CUST_ADDR_STR_1, cam1.CUST_ADDR_STR_2, cam1.CUST_ADDR_CITY_NM, cam1.STT_ID, 
       cam1.CUST_ADDR_POST_CD, cam1.CUST_ADDR_CNTY_NM, cam1.CNTRY_ID, cam1.CUST_ADDR_VLDT_PRFM_IND as VLDTD_IND
       from PCMP.CUSTOMER_ADDRESS cam1
       inner join (
       		select a.CUST_ID, b.MAX_CRT_DTM, b.MAX_EFF_DT, max(a.CUST_ADDR_VLDT_PRFM_IND) as MAX_VLDTD_IND
       		from PCMP.CUSTOMER_ADDRESS a
       		inner join (
       		select CUST_ID, CUST_ADDR_TYP_CD, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DTM, max(CUST_ADDR_EFF_DT) as MAX_EFF_DT
       		from PCMP.CUSTOMER_ADDRESS where CUST_ADDR_TYP_CD = 'mail' and VOID_IND = 'n'
       		and CUST_ADDR_EFF_DT <= CURRENT_DATE and (CUST_ADDR_END_DT > CURRENT_DATE or CUST_ADDR_END_DT is null)
       		group by CUST_ID, CUST_ADDR_TYP_CD
       		) b on a.CUST_ID = b.CUST_ID and a.CUST_ADDR_TYP_CD = b.CUST_ADDR_TYP_CD and a.CUST_ADDR_TYP_CD = 'mail'
       		and a.AUDIT_USER_CREA_DTM = b.MAX_CRT_DTM and a.CUST_ADDR_EFF_DT = b.MAX_EFF_DT and a.VOID_IND = 'n'
       		and a.CUST_ADDR_EFF_DT <= CURRENT_DATE and (a.CUST_ADDR_END_DT > CURRENT_DATE or a.CUST_ADDR_END_DT is null)
       		group by a.CUST_ID, b.MAX_CRT_DTM, b.MAX_EFF_DT
       ) cam2 on cam1.CUST_ID = cam2.CUST_ID and cam1.AUDIT_USER_CREA_DTM = cam2.MAX_CRT_DTM 
       		and cam1.CUST_ADDR_EFF_DT = cam2.MAX_EFF_DT and cam1.CUST_ADDR_VLDT_PRFM_IND = cam2.MAX_VLDTD_IND
       where cam1.CUST_ADDR_TYP_CD = 'mail' and cam1.VOID_IND = 'n' 
       and cam1.CUST_ADDR_EFF_DT <= CURRENT_DATE and (cam1.CUST_ADDR_END_DT > CURRENT_DATE or cam1.CUST_ADDR_END_DT is null)
) cam on p.CUST_ID = cam.CUST_ID 
left outer join PCMP.STATE sttm on cam.STT_ID = sttm.STT_ID
left outer join PCMP.COUNTRY cym on cam.CNTRY_ID = cym.CNTRY_ID
left outer join (
	select distinct cic1a.CUST_ID, cic1a.CUST_INTRN_CHNL_PHN_NO, cic1a.CUST_INTRN_CHNL_PHN_NO_EXT
	from PCMP.CUSTOMER_INTERACTION_CHANNEL cic1a
	inner join (
		select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CUSTOMER_INTERACTION_CHANNEL 
		where INTRN_CHNL_TYP_CD = 'p' and PHN_NO_TYP_CD = 'h'
		and CUST_INTRN_CHNL_PRI_IND = 'y' and VOID_IND = 'n' group by CUST_ID
	) cic1b on cic1a.CUST_ID = cic1b.CUST_ID and cic1a.AUDIT_USER_CREA_DTM = cic1b.MAX_DT
	where cic1a.INTRN_CHNL_TYP_CD = 'p' and cic1a.PHN_NO_TYP_CD = 'h'
	and cic1a.CUST_INTRN_CHNL_PRI_IND = 'y' and cic1a.VOID_IND = 'n'
) cich on p.CUST_ID = cich.CUST_ID
left outer join (
	select distinct cic1a.CUST_ID, cic1a.CUST_INTRN_CHNL_ADDR
	from PCMP.CUSTOMER_INTERACTION_CHANNEL cic1a
	inner join (
		select CUST_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CUSTOMER_INTERACTION_CHANNEL 
		where INTRN_CHNL_TYP_CD = 'e'
		and CUST_INTRN_CHNL_PRI_IND = 'y' and VOID_IND = 'n' group by CUST_ID
	) cic1b on cic1a.CUST_ID = cic1b.CUST_ID and cic1a.AUDIT_USER_CREA_DTM = cic1b.MAX_DT
	where cic1a.INTRN_CHNL_TYP_CD = 'e'
	and cic1a.CUST_INTRN_CHNL_PRI_IND = 'y' and cic1a.VOID_IND = 'n'
) cice on p.CUST_ID = cice.CUST_ID
left outer join PCMP.COUNTRY cntry on c.CNTRY_ID = cntry.CNTRY_ID and cntry.CNTRY_VOID_IND = 'n'
left outer join (
	select distinct AGRE_ID, CLM_PRFL_ANSW_TEXT from PCMP.CLAIM_PROFILE_HISTORY 
	where PRFL_STMT_ID = 6000349 and VOID_IND = 'n' and HIST_END_DTM is null
) mop on C.AGRE_ID = mop.AGRE_ID 
left outer join (
	select distinct AGRE_ID, CLM_PRFL_ANSW_TEXT from PCMP.CLAIM_PROFILE_HISTORY 
	where PRFL_STMT_ID = 6000108 and VOID_IND = 'n' and HIST_END_DTM is null
) soc on C.AGRE_ID = soc.AGRE_ID 
left outer join (
	select cb.CUST_ID, b.BLK_EFF_DT, b.BLK_END_DT
	from PCMP.CUSTOMER_BLOCK_ROLE_BLOCK cb
	inner join PCMP.BLOCK b on cb.BLK_ID = b.BLK_ID and b.BLK_TYP_CD = 'alert'
	and b.VOID_IND = 'n' and cb.CUST_BLK_ROLE_BLK_VOID_IND = 'n'
) blk on p.CUST_ID = blk.CUST_ID and blk.BLK_END_DT is null
left outer join (
	select AGRE_ID, max(CLM_OTHR_DT_EFF_DT) as CLAIM_STAT_OF_LIMIT_OVRRD_DATE from PCMP.CLAIM_OTHER_DATE 
	where VOID_IND = 'n' and CLM_DT_TYP_CD = 'statu_lmt_ovrrd'
	group by AGRE_ID
)cod on C.AGRE_ID = cod.AGRE_ID 
left outer join (
	select cat1.AGRE_ID, cat1.CLM_OTHR_DT_EFF_DT as CATASTROPHIC_CLAIM_DATE from PCMP.CLAIM_OTHER_DATE cat1
	inner join (
		select AGRE_ID, max(AUDIT_USER_CREA_DTM) as MAX_DT from PCMP.CLAIM_OTHER_DATE
		where VOID_IND = 'n'  /* Added Sept 2017 Release  */
		and  CLM_DT_TYP_CD = 'ctrphdt' 
		and  void_ind = 'n'
		and  CLM_OTHR_DT_END_DT is null
		group by AGRE_ID
	) cat2 on cat1.AGRE_ID = cat2.AGRE_ID and cat1.AUDIT_USER_CREA_DTM = cat2.MAX_DT and cat1.CLM_DT_TYP_CD = 'ctrphdt' and  cat1.VOID_IND = 'n' /* Added Sept 2017 Release  */
	and  cat1.CLM_OTHR_DT_END_DT is null
) cod2 on C.AGRE_ID = cod2.AGRE_ID 
left outer join (
	select AGRE_ID, min(CLM_CLM_STS_EFF_DT) as INTL_ACPT_DATE
	from PCMP.CLAIM_CLAIM_STATUS_HISTORY
	where CLM_STS_TYP_CD = 'acpt'
	group by AGRE_ID
) sa on C.AGRE_ID = sa.AGRE_ID
left outer join (
	select AGRE_ID, min(CLM_CLM_STS_EFF_DT) as INTL_DENY_DATE
	from PCMP.CLAIM_CLAIM_STATUS_HISTORY
	where CLM_STS_TYP_CD = 'dny'
	group by AGRE_ID
) sd on C.AGRE_ID = sd.AGRE_ID
left outer join (
	select AGRE_ID, min(HIST_EFF_DTM) as INTL_STLD_INDM_DATE
	from PCMP.CLAIM_CLAIM_STATUS_HISTORY
	where CLM_TRANS_RSN_TYP_CD in ('setlindm', 'setlboth')
	group by AGRE_ID
) si on C.AGRE_ID = si.AGRE_ID
left outer join (
	select AGRE_ID, min(HIST_EFF_DTM) as INTL_STLD_MDCL_DATE
	from PCMP.CLAIM_CLAIM_STATUS_HISTORY
	where CLM_TRANS_RSN_TYP_CD in ('setlmed', 'setlboth')
	group by AGRE_ID
) sm on C.AGRE_ID = sm.AGRE_ID
left outer join (
	select distinct p.AGRE_ID
	from PCMP.PARTICIPATION p
	inner join PCMP.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID
	where p.PTCP_TYP_CD = 'clmt_atty'
	and cp.CLM_PTCP_END_DT is null
) crf_crnt on C.AGRE_ID = crf_crnt.AGRE_ID
left outer join (
	select distinct p.AGRE_ID
	from PCMP.PARTICIPATION p
	inner join PCMP.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID
	inner join PCMP.CLAIM c on p.AGRE_ID = c.AGRE_ID and c.CLM_REL_SNPSHT_IND = 'n'
	where p.PTCP_TYP_CD = 'clmt_atty'
	and to_date(to_char(C.CLM_OCCR_RPT_DT,'YYYY-MM-DD'),'YYYY-MM-DD') >= cp.CLM_PTCP_EFF_DT and to_date(to_char(C.CLM_OCCR_RPT_DT,'YYYY-MM-DD'),'YYYY-MM-DD') < cp.CLM_PTCP_END_DT
) crf_dof on C.AGRE_ID = crf_dof.AGRE_ID
left outer join (
	select cph.CLM_AGRE_ID, CTL_ELEM_SUB_TYP_CD as ORIG_PLCY_TYPE_CODE, 
	CTL_ELEM_SUB_TYP_NM as ORIG_PLCY_TYPE_NAME, CLM_PLCY_RLTNS_EFF_DT
	from DW_REPORT.DW_CLAIM_POLICY_HISTORY cph
	inner join (
		select CLM_AGRE_ID, min(CLM_PLCY_RLTNS_EFF_DT) as MIN_DATE
		from DW_REPORT.DW_CLAIM_POLICY_HISTORY 
		where CTL_ELEM_SUB_TYP_CD is not null
		group by CLM_AGRE_ID
	) cph2 on cph.CLM_AGRE_ID = cph2.CLM_AGRE_ID and cph.CLM_PLCY_RLTNS_EFF_DT = cph2.MIN_DATE
) ort on C.AGRE_ID = ort.CLM_AGRE_ID
left outer join (
	select cct.AGRE_ID, cct.CLM_TYP_CD as ORIG_CLAIM_TYPE_CODE, ct.CLM_TYP_NM as ORIG_CLAIM_TYPE_NAME, HIST_EFF_DTM
	from PCMP.CLAIM_CLAIM_TYPE_HISTORY cct
	inner join (
		select AGRE_ID, min(HIST_EFF_DTM) as MIN_EFF_DTM
		from PCMP.CLAIM_CLAIM_TYPE_HISTORY
		group by AGRE_ID
	) cct2 on cct.AGRE_ID = cct2.AGRE_ID and cct.HIST_EFF_DTM = cct2.MIN_EFF_DTM
	left outer join PCMP.CLAIM_TYPE ct on cct.CLM_TYP_CD = ct.CLM_TYP_CD
) oct on C.AGRE_ID = oct.AGRE_ID
left outer join (
select distinct cc.CLM_COV_STS_TYP_CD, ccst.CLM_COV_STS_TYP_NM, 
	cc.CLM_COV_OVRRD_TYP_CD, ccot.CLM_COV_OVRRD_TYP_NM, 
	DATE_TRUNC('DAY', cc.HIST_EFF_DTM) as CLM_CVRG_EFF_DATE,
	p.CUST_ID, 
	p.AGRE_ID,
	cpi.CLM_PTCP_INSRD_PEO_IND
	from PCMP.CLAIM_COVERAGE_HISTORY cc
	inner join PCMP.CLAIM_PARTICIPATION_INSRD cpi on cc.CLM_PTCP_INSRD_ID = cpi.CLM_PTCP_INSRD_ID and cc.VOID_IND = 'n' and cpi.VOID_IND = 'n'
	inner join PCMP.CLAIM_PARTICIPATION cp on cpi.CLM_PTCP_ID = cp.CLM_PTCP_ID
                                        and cp.CLM_PTCP_END_DT is null and cp.CLM_PTCP_PRI_IND = 'y' and cp.VOID_IND = 'n'  -- added criteria to remove duplicate rows (June 2018 release)
	inner join PCMP.PARTICIPATION p on cp.PTCP_ID = p.PTCP_ID
	left outer join PCMP.CLAIM_COVERAGE_STATUS_TYPE ccst on cc.CLM_COV_STS_TYP_CD = ccst.CLM_COV_STS_TYP_CD
	left outer join PCMP.CLAIM_COVERAGE_OVERRIDE_TYPE ccot on cc.CLM_COV_OVRRD_TYP_CD = ccot.CLM_COV_OVRRD_TYP_CD
	where cc.HIST_END_DTM is null
) cvrg on C.AGRE_ID = cvrg.AGRE_ID and cph.INS_PARTICIPANT = cvrg.CUST_ID
left outer join (
	select cp.AGRE_ID, to_date(cp.CLM_PRFL_ANSW_TEXT, 'MMDDYYYY') as MMI_DATE
	from PCMP.CLAIM_PROFILE cp
	inner join (select AGRE_ID, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DTM from PCMP.CLAIM_PROFILE 
		where PRFL_STMT_ID = 6000230 group by AGRE_ID
	) cp2 on cp.AGRE_ID = cp2.AGRE_ID and cp.AUDIT_USER_CREA_DTM = cp2.MAX_CRT_DTM
	inner join PCMP.PROFILE_STATEMENT ps on cp.PRFL_STMT_ID = ps.PRFL_STMT_ID
	where cp.PRFL_STMT_ID = 6000230 and cp.VOID_IND = 'n'
) mmi on C.AGRE_ID = mmi.AGRE_ID
left outer join (
	select t1.AGRE_ID, t2.ACP_PASSED_DATE, max(CLM_ACP_STS_IND) as ACP_PASSED_IND from PCMP.CLAIM_ACP_STATUS t1
	left outer join (
		select AGRE_ID, min(date(AUDIT_USER_CREA_DTM)) as ACP_PASSED_DATE from PCMP.CLAIM_ACP_STATUS where CLM_ACP_STS_IND = 'y' group by AGRE_ID
	) t2 on t1.AGRE_ID = t2.AGRE_ID
	group by t1.AGRE_ID, t2.ACP_PASSED_DATE
) acp on C.AGRE_ID = acp.AGRE_ID
left outer join (
	select f1.FOLD_NO, f1.FOLD_ID, f1.FOLD_EFF_DT, f1.FOLD_FILE_LOC, f1.FOLD_LOC_STS 
	from PCMP.FOLDER f1 
	inner join (
		select FOLD_NO, max(AUDIT_USER_CREA_DTM) as MAX_CRT_DTM 
		from PCMP.FOLDER where APP_CNTX_TYP_CD = 'claim' and VOID_IND = 'n' group by FOLD_NO
	) f2 on f1.FOLD_NO = f2.FOLD_NO and f1.AUDIT_USER_CREA_DTM = f2.MAX_CRT_DTM
	where f1.APP_CNTX_TYP_CD = 'claim' and f1.VOID_IND = 'n'
) fold on c.CLM_NO = fold.FOLD_NO
left outer join PCMP.CATASTROPHIC_INJURY_TYPE catinj on c.CTRPH_INJR_TYP_CD = catinj.CTRPH_INJR_TYP_CD and catinj.VOID_IND = 'n'
left outer join (
	select trim(clsc.NMBR) as CLM_NO
	, case when trim(ceas.FK_CXST_CODE) = 'ACTV' then 'y' else 'n' end as IND
	, trim(ceas.FK_CXST_CODE) as STS_CODE
	, trim(cxst.NAME) as STS_NAME
	, date(ceas.CEAS_CRT_DTTM) as STS_DATE
	, ROW_NUMBER() OVER (PARTITION by ceea.FK_OICL_NMBR ORDER BY ceea.CEEA_CRT_DTTM DESC) as ROW_NUM
	from BWCRNP.TEACLSC clsc
	inner join BWCRNP.TEACEEA ceea on clsc.FK_OICL_NMBR = ceea.FK_OICL_NMBR and ceea.DCTVT_DTTM = '3000-01-01' and trim(ceea.FK_EXAT_CODE) = 'AUTOAC'
	left outer join BWCRNP.TEACEAS ceas on ceea.FK_OICL_NMBR = ceas.FK_OICL_NMBR and 
		ceea.CEEA_CRT_DTTM = ceas.FK_CEEA_CRT_DTTM and ceas.DCTVT_DTTM = '3000-01-01' and trim(ceas.FK_EXAT_CODE) = 'AUTOAC'
	left outer join BWCRNP.TEACXST cxst on ceas.FK_CXST_CODE = cxst.CXST_CODE 
	where clsc.DCTVT_DTTM = '3000-01-01'
) emp_exp_adj on c.CLM_NO = emp_exp_adj.CLM_NO and emp_exp_adj.ROW_NUM=1
left outer join CLM_LST_PAID clp on c.CLM_NO = clp.CLM_NO
/*HB 27 --task705-- Columns Added*/
left outer join 
(
  select 
  trim(clsc.NMBR) as CLM_NO, 
  case when trim(ceas.FK_CXST_CODE) = 'ACTV' then 'y' else 'n' end as CRNT_HNDCP_RMBRS_STLMN_IND, 
  trim(ceas.FK_CXST_CODE) as CRNT_HNDCP_RMBRS_STLMN_STS_CODE, 
  trim(cxst.NAME) as CRNT_HNDCP_RMBRS_STLMN_STS_NAME, 
  date(ceas.CEAS_CRT_DTTM) as CRNT_HNDCP_RMBRS_STLMN_STS_EFCTV_DATE,
  ROW_NUMBER() OVER (PARTITION by ceea.FK_OICL_NMBR ORDER BY ceea.CEEA_CRT_DTTM DESC) as ROW_NUM
  from BWCRNP.TEACLSC clsc
  inner join BWCRNP.TEACEEA      ceea on  clsc.FK_OICL_NMBR = ceea.FK_OICL_NMBR 
                                      and ceea.DCTVT_DTTM = '3000-01-01'
                                      and trim(ceea.FK_EXAT_CODE) = 'STHNDC'
  left outer join BWCRNP.TEACEAS ceas on  ceea.FK_OICL_NMBR = ceas.FK_OICL_NMBR 
                                      and ceea.CEEA_CRT_DTTM = ceas.FK_CEEA_CRT_DTTM 
                                      and ceas.DCTVT_DTTM = '3000-01-01'
                                      and trim(ceas.FK_EXAT_CODE) = 'STHNDC'
  left outer join BWCRNP.TEACXST cxst on  ceas.FK_CXST_CODE = cxst.CXST_CODE
  where clsc.DCTVT_DTTM = '3000-01-01'
) HB27 on c.CLM_NO = HB27.CLM_NO and HB27.ROW_NUM=1
/*Current and Primary AOR --task705  -- Columns Added*/
left outer join 
(
select DISTINCT
c.AGRE_ID CLM_AGRE_ID, 
p.PTCP_ID CRNT_PRMRY_AOR_PTCP_ID, 
p.CUST_ID CRNT_PRMRY_AOR_CUST_ID, 
cp.CLM_PTCP_ID CRNT_PRMRY_AOR_CLM_PTCP_ID,  
cn.CUST_NM_DRV_UPCS_NM CRNT_PRMRY_AOR_NAME, 
cri.CUST_ROLE_ID_VAL_STR CRNT_PRMRY_AOR_REP_ID
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'clmt_atty'
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.CLM_PTCP_PRI_IND = 'y' and cp.VOID_IND = 'n'
left join pcmp.CUSTOMER_NAME cn on p.CUST_ID = cn.CUST_ID and cn.VOID_IND = 'n' and cn.CUST_NM_END_DT is null and cn.CUST_NM_TYP_CD in ('busn_legal_nm', 'prsn_nm')
left join pcmp.CUSTOMER_ROLE_IDENTIFIER cri on p.CUST_ID = cri.CUST_ID and cri.VOID_IND = 'n' and cri.CUST_ROLE_ID_END_DT is null and cri.ID_TYP_CD = 'rep'
where c.CLM_REL_SNPSHT_IND = 'n'
and   (c.AGRE_ID, p.CUST_ID, cp.AUDIT_USER_CREA_DTM) in
(select c.AGRE_ID, p.CUST_ID, max(cp.AUDIT_USER_CREA_DTM) AUDIT_USER_CREA_DTM
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'clmt_atty'
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.CLM_PTCP_PRI_IND = 'y' and cp.VOID_IND = 'n'
where c.CLM_REL_SNPSHT_IND = 'n'
group by 1,2) 
)AOR on C.AGRE_ID = AOR.CLM_AGRE_ID
/*Current and Primary POR --task 705 -- Columns Added*/
left outer join 
(
select distinct
c.AGRE_ID CLM_AGRE_ID, 
p.PTCP_ID CRNT_PRMRY_POR_PTCP_ID,
p.CUST_ID CRNT_PRMRY_POR_CUST_ID, 
cp.CLM_PTCP_ID CRNT_PRMRY_POR_CLM_PTCP_ID,
cn.CUST_NM_DRV_UPCS_NM CRNT_PRMRY_POR_NAME,
cust.CUST_NO CRNT_PRMRY_POR_CUST_NO
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'prov'
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.CLM_PTCP_PRI_IND = 'y' and cp.VOID_IND = 'n'
join pcmp.CLAIM_PARTICIPATION_PROV cpp on cp.CLM_PTCP_ID = cpp.CLM_PTCP_ID and cpp.VOID_IND = 'n' 
join pcmp.CLAIM_PTCP_PROV_PTCP_TYP prov on cpp.CLM_PTCP_PROV_ID = prov.CLM_PTCP_PROV_ID and prov.VOID_IND = 'n' 
                                        and prov.CPPPT_END_DT is null and prov.PROV_PTCP_TYP_CD = 'primarytreating'
left join pcmp.customer cust on p.CUST_ID = cust.CUST_ID and cust.VOID_IND = 'n'
left join pcmp.CUSTOMER_NAME cn on p.CUST_ID = cn.CUST_ID and cn.VOID_IND = 'n' and cn.CUST_NM_END_DT is null and cn.CUST_NM_TYP_CD in ('busn_legal_nm', 'prsn_nm') 
where c.CLM_REL_SNPSHT_IND = 'n'
)POR on C.AGRE_ID = POR.CLM_AGRE_ID
LEFT OUTER JOIN (SELECT DISTINCT OCCR.AGRE_ID ,OCCR.OCCR_PRMS_TYP_CD,OCCPT.OCCR_PRMS_TYP_NM  FROM PCMP.CLAIM OCCR
	LEFT OUTER JOIN PCMP.OCCURRENCE_PREMISES_TYPE OCCPT ON OCCR.OCCR_PRMS_TYP_CD = OCCPT.OCCR_PRMS_TYP_CD 
		WHERE OCCR.CLM_REL_SNPSHT_IND = 'n' and OCCPT.VOID_IND = 'n') OCCRTC 
		ON C.AGRE_ID = OCCRTC.AGRE_ID
LEFT OUTER JOIN (SELECT DISTINCT  C.AGRE_ID, DATE(C.CLM_CLMT_NTF_DT) AS CLMT_NTFCT_DATE, DATE(C.CLM_EMPLR_NTF_DT) AS EMPLR_NTFCT_DATE, DATE(C.CLM_ADMN_NTF_DT) AS ADMIN_NTFCT_DATE
					FROM PCMP.CLAIM C WHERE C.CLM_REL_SNPSHT_IND = 'n') DT 	
					ON C.AGRE_ID = DT.AGRE_ID
LEFT OUTER JOIN (SELECT CCT.AGRE_ID ,CCT.CLM_TYP_CD,CT.CLM_TYP_NM,CCT.CLM_CLM_TYP_EFF_DT,CCT.CLM_CLM_TYP_END_DT FROM PCMP.CLAIM_CLAIM_TYPE CCT
										LEFT OUTER JOIN PCMP.CLAIM_TYPE CT ON CCT.CLM_TYP_CD = CT.CLM_TYP_CD) CCT_NEW
				ON C.AGRE_ID = CCT_NEW.AGRE_ID
LEFT OUTER JOIN PCMP.OCCURRENCE_MEDIA_TYPE OMT 
				ON C.OCCR_MEDA_TYP_CD = OMT.OCCR_MEDA_TYP_CD
LEFT OUTER JOIN PCMP.OCCURRENCE_SOURCE_TYPE OST
				ON C.OCCR_SRC_TYP_CD = OST.OCCR_SRC_TYP_CD
LEFT OUTER JOIN PCMP.NATURE_OF_INJURY_CATEGORY_TYPE NOICT
				ON C.NOI_CTG_TYP_CD = NOICT.NOI_CTG_TYP_CD
LEFT OUTER JOIN PCMP.NATURE_OF_INJURY_TYPE NOIT
				ON C.NOI_TYP_CD = NOIT.NOI_TYP_CD
LEFT OUTER JOIN PCMP.CAUSE_OF_LOSS_CATEGORY_TYPE COLCT
				ON C.CAUS_OF_LOSS_CTG_TYP_CD = COLCT.CAUS_OF_LOSS_CTG_TYP_CD
LEFT OUTER JOIN PCMP.CAUSE_OF_LOSS_TYPE COLT
				ON C.CAUS_OF_LOSS_TYP_CD = COLT.CAUS_OF_LOSS_TYP_CD
LEFT OUTER JOIN PCMP.CLAIM_ADDITIONAL_DETAIL CAA
				ON C.AGRE_ID = CAA.AGRE_ID AND CAA.VOID_IND = 'n'
LEFT OUTER JOIN PCMP.UNUSUAL_CLAIM_TYPE UCT 
				ON C.UNSL_CLM_TYP_CD = UCT.UNSL_CLM_TYP_CD AND UCT.VOID_IND = 'n'
LEFT OUTER JOIN PCMP.EDUCATION_LEVEL_TYPE ELT
				ON C.EDUC_LVL_TYP_CD = ELT.EDUC_LVL_TYP_CD AND ELT.VOID_IND = 'n'
LEFT OUTER JOIN PCMP.CLAIM_EMPLOYMENT_STATUS_TYPE CEST
				ON C.CLM_EMPL_STS_TYP_CD = CEST.CLM_EMPL_STS_TYP_CD AND CEST.VOID_IND = 'n'
LEFT OUTER JOIN PCMP.CLAIM_ALIAS_NUMBER CAN2 ON CAN2.CLM_ALIAS_NO_NO = C.CLM_NO
               		AND CAN2.CLM_ALIAS_NO_TYP_CD = 'dupexprdclm' AND CAN2.VOID_IND = 'n' 
LEFT OUTER JOIN PCMP.CLAIM_RECOVERY_TYPE CRT ON C.CLM_RCVR_TYP_CD = CRT.CLM_RCVR_TYP_CD AND CRT.VOID_IND = 'n'
LEFT OUTER JOIN PCMP.USERS CUNN ON C.AUDIT_USER_ID_UPDT = CUNN.USER_ID
WHERE C.CLM_REL_SNPSHT_IND = 'n'
);

COMMIT;