/* SEPT 2017  5 additional rules are added to see if there is any activity happened since the previous business day on the fraud flagged customers.
		27-->Any update to the participation type of Claimant Representative. 
		28-->Addition of primary or non-primary Claimant Representative participation.
		29-->Any update to the participation type of Provider.
		30-->Addition of primary or non-primary Provider participation.
		31-->Any new primary assignment added to the claim. */


--\set ON_ERROR_STOP on
--STEP-1: Create Temp table for date range selection 

CREATE TEMPORARY TABLE TEMP_DATES  AS 
SELECT 
A.ACTUAL_DT AS ACTUAL_DT, DAY_IN_WEEK_NM AS WEEK_NM,
CASE 
	WHEN A.DAY_IN_WEEK_NM = 'Monday'    AND FOUR_HOL_IND = 'y' THEN A.PRVS1_BSNS_DAY_DATE - 1
	WHEN A.DAY_IN_WEEK_NM = 'Tuesday'   AND ONE_HOL_IND = 'n' 
									    AND FOUR_HOL_IND = 'n' THEN A.PRVS1_BSNS_DAY_DATE - 2
	WHEN A.DAY_IN_WEEK_NM = 'Tuesday'   AND FOUR_HOL_IND = 'y' THEN A.PRVS1_BSNS_DAY_DATE - 3
	WHEN A.DAY_IN_WEEK_NM = 'Wednesday' AND TWO_HOL_IND = 'y' THEN A.PRVS1_BSNS_DAY_DATE - 3
ELSE A.PRVS1_BSNS_DAY_DATE 
END PRVS1_BSNS_DAY_DATE
FROM DW_REPORT.DATE_DIM A
, LATERAL(SELECT HOL_IND FOUR_HOL_IND FROM DW_REPORT.DATE_DIM WHERE ACTUAL_DT = A.ACTUAL_DT - 4) AS B
, LATERAL(SELECT HOL_IND ONE_HOL_IND FROM DW_REPORT.DATE_DIM WHERE ACTUAL_DT = A.ACTUAL_DT - 1) AS C
, LATERAL(SELECT HOL_IND TWO_HOL_IND FROM DW_REPORT.DATE_DIM WHERE ACTUAL_DT = A.ACTUAL_DT - 2) AS D
;


/*CREATE TEMPORARY TABLE TEMP_DATES  AS (
with d1 as (
    select actual_dt, day_in_week_short_nm, hol_ind, prvs1_bsns_day_date 
    from DW_REPORT.DATE_DIM 
    where actual_dt between current_date - 10 and current_date )
select
    d1.ACTUAL_DT AS ACTUAL_DT,
    d1.DAY_IN_WEEK_SHORT_NM AS WEEK_NM,
    d1.PRVS1_BSNS_DAY_DATE as PRVS_BSNS_DT,
    d2.PRVS1_BSNS_DAY_DATE as PRVS1_BSNS_DAY_DATE
from d1
inner join d1 as d2 on (d1.prvs1_bsns_day_date = d2.actual_dt )
and d1.actual_dt = current_date
order by actual_dt
  );*/


/*STEP-2: Create temp table to check siu flag*/
CREATE TEMPORARY TABLE FDAR_TEMP_1  AS
select 
c.AGRE_ID, 
c.CLM_NO                     CLAIM_NO, 
pt.PTCP_TYP_NM               ROLE_TYPE, 
ti.TAX_ID_NO                 SSN,
cn.CUST_NM_NM                CUST_NAME, 
u.USER_DRV_UPCS_NM           SIU_NAME, 
COALESCE
(ou.ORG_UNT_ABRV_NM, 
 ou.ORG_UNT_NM, 
 ou1.ORG_UNT_ABRV_NM, 
 ou1.ORG_UNT_NM)             SERVICE_OFFICE_NAME
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
left join pcmp.PARTICIPATION_TYPE pt on p.PTCP_TYP_CD = pt.PTCP_TYP_CD
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
join (
         select CUST_LIEN_REST_ID, CUST_ID, AUDIT_USER_ID_CREA from pcmp.CUSTOMER_LIEN_RESTRICTION
         where LIEN_REST_TYP_CD = 'siu' 
         and   LIEN_REST_STS_TYP_CD = 'open'
         and   VOID_IND = 'n'
         union
         select a.* from
         ( select CUST_LIEN_REST_ID, CUST_ID, AUDIT_USER_ID_UPDT from pcmp.CUSTOMER_LIEN_RESTRICTION
           where LIEN_REST_TYP_CD = 'siu' 
           and   LIEN_REST_STS_TYP_CD = 'cls'
           and   VOID_IND = 'n'
           and   AUDIT_USER_UPDT_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE) /*status changed from open to closed on previous business day*/
         ) a
         join
         ( select * from pcmp.CUSTOMER_LIEN_RESTRICTION_HIST
           where LIEN_REST_TYP_CD = 'siu' 
           and   LIEN_REST_STS_TYP_CD = 'open'
           and   VOID_IND = 'n' and HIST_END_DTM is not null
           and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE) /*status changed from open to closed on previous business day*/
         ) b on a.CUST_LIEN_REST_ID = b.CUST_LIEN_REST_ID
     ) clr on p.CUST_ID = clr.CUST_ID
left join pcmp.TAX_IDENTIFIER ti on p.CUST_ID = ti.CUST_ID and ti.VOID_IND = 'n' and ti.TAX_ID_TYP_CD = 'ssn'
left join pcmp.CUSTOMER_NAME cn on p.CUST_ID = cn.CUST_ID and cn.VOID_IND = 'n' and cn.CUST_NM_TYP_CD in ('prsn_nm', 'busn_legal_nm') and cn.CUST_NM_END_DT is null
left join pcmp.USERS u on clr.AUDIT_USER_ID_CREA = u.USER_ID
left join (
            select USER_ID, min(ORG_UNT_ID) ORG_UNT_ID 
            from pcmp.FUNCTIONAL_ROLE_ORG_UNT_XREF 
            where FROUX_VOID_IND = 'n' and FROUX_END_DT is null
            group by USER_ID  
          ) froux on clr.AUDIT_USER_ID_CREA = froux.user_id
left join pcmp.ORGANIZATIONAL_UNIT ou on froux.ORG_UNT_ID = ou.ORG_UNT_ID and ou.ORG_UNT_VOID_IND = 'n' and ou.ORG_UNT_END_DT is null
left join pcmp.ASSIGNMENT asgn on c.AGRE_ID = asgn.ASGN_CNTX_ID and asgn.APP_CNTX_TYP_CD = 'claim' and asgn.ASGN_PRI_OWNR_IND = 'y' and asgn.ASGN_END_DT is null
left join pcmp.ORGANIZATIONAL_UNIT ou1 on asgn.ORG_UNT_ID = ou1.ORG_UNT_ID and ou1.ORG_UNT_VOID_IND = 'n' and ou1.ORG_UNT_END_DT is null
where CLM_REL_SNPSHT_IND = 'n'
;

/*STEP-3: Create temp table to check for activilities on all claims */
CREATE TEMPORARY TABLE FDAR_TEMP_2  AS
/*SIU-HEAR-DATE*/
select c.CASE_CNTX_ID AGRE_ID, 
'HEARING DATE: '||to_char(lp.LGL_PRCD_DTM, 'MM/DD/YYYY') ACTIVITY_DESCRIPTION, 
COALESCE(LP.AUDIT_USER_UPDT_DTM, LP.AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM,
COALESCE(LP.AUDIT_USER_ID_UPDT, LP.AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CASES c
join pcmp.CASE_DETAIL_LEGAL cdl on c.CASE_ID = cdl.CASE_ID and cdl.VOID_IND = 'n'
join pcmp.LEGAL_PROCEEDING lp on cdl.CDL_ID = lp.CDL_ID and lp.VOID_IND = 'n'
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim'
and   c.CASE_CTG_TYP_CD = 'lgl'
AND   COALESCE(LP.AUDIT_USER_UPDT_DTM, LP.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-PAY-BUILT*/
select IP.AGRE_ID, 
'PAYMENT PLAN: '||BT.BNFT_TYP_NM||' FROM: '||to_char(IP.INDM_PAY_EFF_DT, 'MM/DD/YYYY')||' TO: '||to_char(IP.INDM_PAY_END_DT, 'MM/DD/YYYY') ACTIVITY_DESCRIPTION,
IP.AUDIT_USER_CREA_DTM,
IP.AUDIT_USER_ID_CREA
from pcmp.INDEMNITY_PAYMENT IP
LEFT JOIN PCMP.BENEFIT_TYPE BT on IP.BNFT_TYP_CD = BT.BNFT_TYP_CD
where IP.VOID_IND = 'n'
and   DATE_TRUNC('DAY', IP.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU- CHG-PAY-DATE*/
select 
CUR.AGRE_ID, 
'PAYMENT PLAN: '||CUR.BNFT_TYP_NM||' FROM: '||to_char(CUR.INDM_PAY_EFF_DT, 'MM/DD/YYYY')||' TO: '||to_char(CUR.INDM_PAY_END_DT, 'MM/DD/YYYY') ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from
( select a.AGRE_ID, a.INDM_PAY_ID, b.BNFT_TYP_NM, a.INDM_PAY_EFF_DT, a.INDM_PAY_END_DT, 
  COALESCE(a.AUDIT_USER_UPDT_DTM, a.AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(a.AUDIT_USER_ID_UPDT, a.AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
  from pcmp.INDEMNITY_PAYMENT a
  join pcmp.BENEFIT_TYPE b on a.BNFT_TYP_CD = b.BNFT_TYP_CD
  where a.VOID_IND = 'n'
  and   DATE_TRUNC('DAY', a.AUDIT_USER_UPDT_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur
join 
(
  select AGRE_ID, INDM_PAY_ID, INDM_PAY_EFF_DT, INDM_PAY_END_DT 
  from pcmp.INDEMNITY_PAYMENT_HISTORY 
  where VOID_IND = 'n' 
  and   HIST_END_DTM is not null
  and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.INDM_PAY_ID = HIST.INDM_PAY_ID
where (DATE_TRUNC('DAY',cur.INDM_PAY_EFF_DT) <> DATE_TRUNC('DAY', hist.INDM_PAY_EFF_DT) or DATE_TRUNC('DAY', cur.INDM_PAY_END_DT) <> DATE_TRUNC('DAY', hist.INDM_PAY_EFF_DT))
union
/*SIU-CHG-SSN*/
select c.AGRE_ID, 'SSN CHANGED' ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
join (
        select cust_id, tax_id_id, tax_id_no,  
        COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
        from pcmp.TAX_IDENTIFIER
        where DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
     ) cur on p.CUST_ID = cur.cust_id
join
(
select cust_id, tax_id_id, tax_id_no from pcmp.TAX_IDENTIFIER_HISTORY
where HIST_END_DTM is not null
and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.tax_id_id = hist.tax_id_id
union
/*SIU-CHG-NAME*/
select c.AGRE_ID, 'NAME CHANGED' ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
join ( 
       select cust_id, cust_nm_id, cust_nm_drv_upcs_nm,
       COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
       from pcmp.CUSTOMER_NAME
       where VOID_IND = 'n'
       and DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
     ) cur on p.CUST_ID = cur.cust_id
join
(
select cust_id, cust_nm_id, cust_nm_drv_upcs_nm from pcmp.CUSTOMER_NAME_HISTORY
where VOID_IND = 'n' 
and DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.cust_nm_id = hist.cust_nm_id and cur.cust_nm_drv_upcs_nm != hist.cust_nm_drv_upcs_nm
union
/*SIU-CHG-HOME-ADDR*/
select 
distinct
c.AGRE_ID, 
'HOME ADDR: '||nvl(cur.cust_addr_str_1,' ')||nvl(cur.cust_addr_str_2, '')||', '||nvl(cur.cust_addr_city_nm, '')||', '||nvl(cur.STT_NM, '')||', '||cur.cust_addr_post_cd ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
join ( 
       select 
       cust_id, 
       cust_addr_id, 
       cust_addr_str_1,
       cust_addr_str_2, 
       cust_addr_city_nm, 
       a.stt_id, 
       b.STT_NM, 
       cust_addr_post_cd,
       COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, 
       COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
       from pcmp.CUSTOMER_ADDRESS a
       left join pcmp.STATE b on a.STT_ID = b.STT_ID
       where CUST_ADDR_TYP_CD = 'phys' and a.cust_addr_end_dt is null
       and COALESCE( DATE_TRUNC('DAY',AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
     ) cur on p.CUST_ID = cur.cust_id
union
/*SIU-CHG-MAIL-ADDR*/
select 
distinct
c.AGRE_ID, 
'MAIL ADDR: '||nvl(cur.cust_addr_str_1,' ')||nvl(cur.cust_addr_str_2, '')||', '||nvl(cur.cust_addr_city_nm, '')||', '||nvl(cur.STT_NM, '')||', '||cur.cust_addr_post_cd ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
join ( 
       select 
       cust_id, 
       cust_addr_id, 
       cust_addr_str_1,
       cust_addr_str_2, 
       cust_addr_city_nm, 
       a.stt_id, 
       b.STT_NM, 
       cust_addr_post_cd,
       COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, 
       COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
       from pcmp.CUSTOMER_ADDRESS a
       left join pcmp.STATE b on a.STT_ID = b.STT_ID
       where CUST_ADDR_TYP_CD = 'mail' and a.cust_addr_end_dt is null
       and COALESCE( DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
     ) cur on p.CUST_ID = cur.cust_id
union
/*SIU-CHG-ISSUE-STATUS*/
select c.CASE_CNTX_ID, 'ISSUE STATUS: '||ci.case_iss_typ_nm||' - '||ci.CASE_ISS_STS_TYP_NM ACTIVITY_DESCRIPTION, ci.AUDIT_USER_UPDT_DTM, ci.AUDIT_USER_ID_UPDT 
from pcmp.CASES c
join
(
select cur.case_id, cur.CASE_ISS_STS_TYP_NM, cur.case_iss_typ_nm, cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT from
(
select a.case_iss_id, a.case_iss_sts_typ_cd, b.CASE_ISS_STS_TYP_NM, c.case_iss_typ_nm , a.CASE_ID,
COALESCE(a.AUDIT_USER_UPDT_DTM, a.AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(a.AUDIT_USER_ID_UPDT, a.AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CASE_ISSUE a
left join pcmp.CASE_ISSUE_STATUS_TYPE b on a.case_iss_sts_typ_cd = b.CASE_ISS_STS_TYP_CD
left join pcmp.CASE_ISSUE_TYPE c on a.CASE_ISS_TYP_CD = c.CASE_ISS_TYP_CD
where a.VOID_IND = 'n'
and a.CASE_ISS_TYP_CD in 
( 'pct_pp', 'pct_pp_incr', 'adt_allow', 'adm_stl', 'crt_stl', 'dth_bef', 'durg_utiliz', 'facial_disf', 
  'fraud', 'lm_wag_los', 'ls_advan', 'np_sal_continu', 'np_tep_tot', 'no_sp_tot_dis', 'no_work_wag_los'
, 'og_pr_tmp_tot', 'othr', 'overpayment', 'react', 'schd_los', 'sp_tot_dis', 'term_temp_tot'
, 'vssr', 'wage_set_adj', 'work_wag_los')
and DATE_TRUNC('DAY', a.AUDIT_USER_UPDT_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur
join 
(
select a.case_iss_id, a.case_iss_sts_typ_cd, b.CASE_ISS_STS_TYP_NM, c.case_iss_typ_nm , a.CASE_ID from pcmp.CASE_ISSUE_HISTORY a
left join pcmp.CASE_ISSUE_STATUS_TYPE b on a.case_iss_sts_typ_cd = b.CASE_ISS_STS_TYP_CD
left join pcmp.CASE_ISSUE_TYPE c on a.CASE_ISS_TYP_CD = c.CASE_ISS_TYP_CD
where a.VOID_IND = 'n'
and a.CASE_ISS_TYP_CD in 
( 'pct_pp', 'pct_pp_incr', 'adt_allow', 'adm_stl', 'crt_stl', 'dth_bef', 'durg_utiliz', 'facial_disf', 
  'fraud', 'lm_wag_los', 'ls_advan', 'np_sal_continu', 'np_tep_tot', 'no_sp_tot_dis', 'no_work_wag_los'
, 'og_pr_tmp_tot', 'othr', 'overpayment', 'react', 'schd_los', 'sp_tot_dis', 'term_temp_tot'
, 'vssr', 'wage_set_adj', 'work_wag_los')
and DATE_TRUNC('DAY', a.HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.case_iss_id = hist.case_iss_id and nvl(cur.case_iss_sts_typ_cd, 'a') != nvl(hist.case_iss_sts_typ_cd, 'a')
) ci on c.CASE_ID = ci.case_id 
where c.VOID_IND = 'n' and c.APP_CNTX_TYP_CD = 'claim' and c.CASE_CTG_TYP_CD = 'lgl' and c.CASE_TYP_CD = 'admn_hear'
union
/*SIU-ISSUE-FILED*/
select c.CASE_CNTX_ID, 'ISSUE FILED: '||CIT.CASE_ISS_TYP_NM ACTIVITY_DESCRIPTION, c.AUDIT_USER_CREA_DTM, c.AUDIT_USER_ID_CREA
from pcmp.CASES c
join pcmp.CASE_ISSUE CI on C.CASE_ID = CI.CASE_ID and CI.VOID_IND = 'n'
left join pcmp.CASE_ISSUE_TYPE CIT on CI.CASE_ISS_TYP_CD = CIT.CASE_ISS_TYP_CD
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim' 
and   c.CASE_CTG_TYP_CD = 'lgl' 
and   c.CASE_TYP_CD = 'admn_hear'
and   ci.AUDIT_USER_CREA_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-CHG-CLM-STATUS*/
select cur.AGRE_ID, 'CLAIM STATUS CHANGE: '||cur.CLM_STS_TYP_NM||'-'||cur.CLM_TRANS_RSN_TYP_NM ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from
(
select ccs.CLM_CLM_STS_ID, ccs.AGRE_ID, ccs.CLM_STS_TYP_CD, cst.CLM_STS_TYP_NM, ccs.CLM_TRANS_RSN_TYP_CD, ctrt.CLM_TRANS_RSN_TYP_NM,
COALESCE(ccs.AUDIT_USER_UPDT_DTM, ccs.AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(ccs.AUDIT_USER_ID_UPDT, ccs.AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CLAIM_CLAIM_STATUS ccs
left join pcmp.CLAIM_STATUS_TYPE cst on ccs.CLM_STS_TYP_CD = cst.CLM_STS_TYP_CD
left join pcmp.CLAIM_TRANSITION_REASON_TYPE ctrt on ccs.CLM_TRANS_RSN_TYP_CD = ctrt.CLM_TRANS_RSN_TYP_CD
where COALESCE(DATE_TRUNC('DAY',ccs.AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', ccs.AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur
join
(
select ccs.CLM_CLM_STS_ID, ccs.AGRE_ID, ccs.CLM_STS_TYP_CD, cst.CLM_STS_TYP_NM, ccs.CLM_TRANS_RSN_TYP_CD, ctrt.CLM_TRANS_RSN_TYP_NM from pcmp.CLAIM_CLAIM_STATUS_HISTORY ccs
left join pcmp.CLAIM_STATUS_TYPE cst on ccs.CLM_STS_TYP_CD = cst.CLM_STS_TYP_CD
left join pcmp.CLAIM_TRANSITION_REASON_TYPE ctrt on ccs.CLM_TRANS_RSN_TYP_CD = ctrt.CLM_TRANS_RSN_TYP_CD
where ccs.HIST_END_DTM is not null
and   DATE_TRUNC('DAY', ccs.HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.clm_clm_sts_id = hist.clm_clm_sts_id
where (cur.clm_sts_typ_cd != hist.clm_sts_typ_cd or cur.clm_trans_rsn_typ_cd != hist.clm_trans_rsn_typ_cd)
union
/*11_SIU-EXAM-SCHED*/
select c.CASE_CNTX_ID AGRE_ID, 
'Exam Details: Added or Modified' ACTIVITY_DESCRIPTION,
COALESCE( DATE_TRUNC('DAY', his.AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', his.AUDIT_USER_CREA_DTM)) AUDIT_USER_UPDT_DTM,
COALESCE(his.AUDIT_USER_ID_UPDT, his.AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CASES c
join pcmp.CASE_DETAIL_EXM_SCH_HIS his on c.CASE_ID = his.CASE_ID
where c.VOID_IND = 'n' and his.VOID_IND = 'n'
and   c.APP_CNTX_TYP_CD = 'claim' 
and   c.CASE_CTG_TYP_CD = 'med' 
and   c.CASE_TYP_CD = 'exam_schd'
and   his.CDES_EXM_DT is not null
and   COALESCE( DATE_TRUNC('DAY', his.AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', his.AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
and   COALESCE( DATE_TRUNC('DAY', his.AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', his.AUDIT_USER_CREA_DTM)) < his.CDES_EXM_DT
union
/*SIU-CHG-EXAM-STATUS*/
select c.CASE_CNTX_ID, 'EXAM STATUS CHANGE: '||cst.CASE_STS_TYP_NM||'-'||csrt.CASE_STS_RSN_TYP_NM ACTIVITY_DESCRIPTION,
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from pcmp.CASES c
join ( 
        select CASE_ID, CASE_STT_STS_ID, CASE_STS_TYP_CD, CASE_STS_RSN_TYP_CD,
        COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
        from pcmp.CASE_STATE_STATUS
        where VOID_IND = 'n'
        and   COALESCE( DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
     ) cur on c.CASE_ID = cur.case_id
join 
(
select CASE_ID, CASE_STT_STS_ID, CASE_STS_TYP_CD from pcmp.CASE_STATE_STATUS_HISTORY 
where VOID_IND = 'n'
and   HIST_END_DTM is not null
and   CASE_STS_TYP_CD in ('exam_sched_bwc', 'exm_sch_mco', 'exam_sched_vedr')
and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.CASE_STT_STS_ID = hist.CASE_STT_STS_ID and cur.CASE_STS_TYP_CD != hist.CASE_STS_TYP_CD
left join pcmp.CASE_STATUS_TYPE cst on cur.CASE_STS_TYP_CD = cst.CASE_STS_TYP_CD 
left join pcmp.CASE_STATUS_REASON_TYPE csrt on cur.CASE_STS_RSN_TYP_CD = csrt.CASE_STS_RSN_TYP_CD
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim' 
and   c.CASE_CTG_TYP_CD = 'med' 
and   c.CASE_TYP_CD = 'exam_schd'
union
/*SIU-ADD-RHB-PLN*/
select c.CASE_CNTX_ID, 'REHAB PLAN ADDED' ACTIVITY_DESCRIPTION, c.AUDIT_USER_CREA_DTM, c.AUDIT_USER_ID_CREA
from pcmp.CASES c
join pcmp.CASE_PROFILE cp on c.CASE_ID = cp.CASE_ID and cp.VOID_IND = 'n'
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim'
and   c.CASE_CTG_TYP_CD = 'voc_rhbl'
and   c.CASE_TYP_CD = 'voc_rhbl'
and   cp.PRFL_STMT_ID in (6000223, 6000224)
and   DATE_TRUNC('DAY', cp.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-CHG-RHB-PLN*/
select c.CASE_CNTX_ID, 'REHAB PLAN CHANGED' ACTIVITY_DESCRIPTION, cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from pcmp.CASES c
join
(
select CASE_ID, CASE_PRFL_ID, CASE_PRFL_ANSW_TXT,
COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CASE_PROFILE
where VOID_IND = 'n'
and   PRFL_STMT_ID in (6000223, 6000224)
and   COALESCE( DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur on c.CASE_ID = cur.CASE_ID
join
(
select CASE_ID, CASE_PRFL_ID, CASE_PRFL_ANSW_TXT from pcmp.CASE_PROFILE_HISTORY
where VOID_IND = 'n'
and   PRFL_STMT_ID in (6000223, 6000224)
and   HIST_END_DTM is not null
and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.CASE_PRFL_ID = hist.CASE_PRFL_ID and nvl(cur.CASE_PRFL_ANSW_TXT, 'a') != nvl(HIST.CASE_PRFL_ANSW_TXT, 'a')
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim'
and   c.CASE_CTG_TYP_CD = 'voc_rhbl'
and   c.CASE_TYP_CD = 'voc_rhbl'
union
/*SIU-ADD-MDC-RFR*/
select c.CASE_CNTX_ID, 'MEDICAL REFERRAL ADDED' ACTIVITY_DESCRIPTION, c.AUDIT_USER_CREA_DTM, c.AUDIT_USER_ID_CREA
from pcmp.CASES c
join pcmp.CASE_EVENT CE on c.CASE_ID = ce.CASE_ID and ce.VOID_IND = 'n'
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim'
and   c.CASE_CTG_TYP_CD = 'lgl'
and   c.CASE_TYP_CD = 'admn_hear'
and   ce.CASE_EVNT_TYP_CD like '%nurse%'
and   DATE_TRUNC('DAY', ce.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-CHG-ICD*/
select distinct AGRE_ID, 'ICD CHANGE' ACTIVITY_DESCRIPTION, AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA from
(
select AGRE_ID, AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA from pcmp.CLAIM_ICD_STATUS
where VOID_IND = 'n'
and   DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
select cur.agre_id, cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT from 
(
select AGRE_ID, CLM_ICD_STS_ID, ICD_STS_TYP_CD,
COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CLAIM_ICD_STATUS
where VOID_IND = 'n'
and   COALESCE( DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur
join
(
select AGRE_ID, CLM_ICD_STS_ID, ICD_STS_TYP_CD 
from pcmp.CLAIM_ICD_STATUS_HISTORY
where VOID_IND = 'n'
and   HIST_END_DTM is not null
and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.CLM_ICD_STS_ID = hist.CLM_ICD_STS_ID and cur.ICD_STS_TYP_CD != hist.ICD_STS_TYP_CD
) x
union
/*SIU-ADD-IC-RFR-*/
select c.CASE_CNTX_ID, 'IC REFERRAL ADDED' ACTIVITY_DESCRIPTION, c.AUDIT_USER_CREA_DTM, c.AUDIT_USER_ID_CREA
from pcmp.CASES c
join pcmp.CASE_EVENT CE on c.CASE_ID = ce.CASE_ID and ce.VOID_IND = 'n'
where c.VOID_IND = 'n' 
and   c.APP_CNTX_TYP_CD = 'claim'
and   c.CASE_CTG_TYP_CD = 'lgl'
and   c.CASE_TYP_CD = 'admn_hear'
and   ce.CASE_EVNT_TYP_CD = 'notic_ref_issud'
and   DATE_TRUNC('DAY', ce.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-CHG-RTW*/
select cur.agre_id, 'RTW DATE CHANGE: '||typ.CLM_DISAB_MANG_DISAB_TYP_NM||' '||cur.CLM_DISAB_MANG_EFF_DT ACTIVITY_DESCRIPTION, 
cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT
from
(
select CLM_DISAB_MANG_ID, AGRE_ID, CLM_DISAB_MANG_DISAB_TYP_CD, CLM_DISAB_MANG_EFF_DT, CLM_DISAB_MANG_END_DT,
COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CLAIM_DISABILITY_MANAGEMENT
where VOID_IND = 'n' and CLM_DISAB_MANG_DISAB_TYP_CD in ('offwkactrtw', 'offwkestrtw')
and COALESCE(DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur
join
(
select CLM_DISAB_MANG_ID, AGRE_ID, CLM_DISAB_MANG_DISAB_TYP_CD, CLM_DISAB_MANG_EFF_DT, CLM_DISAB_MANG_END_DT from pcmp.CLAIM_DISABILITY_MANG_HIST
where VOID_IND = 'n' and CLM_DISAB_MANG_DISAB_TYP_CD in ('offwkactrtw', 'offwkestrtw')
and HIST_END_DTM is not null
and DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.clm_disab_mang_id = hist.clm_disab_mang_id
left join pcmp.CLAIM_DISAB_MANG_DISAB_TYP typ on cur.CLM_DISAB_MANG_DISAB_TYP_CD = typ.CLM_DISAB_MANG_DISAB_TYP_CD
where 
(
DATE_TRUNC('DAY',cur.CLM_DISAB_MANG_EFF_DT) != DATE_TRUNC('DAY', hist.CLM_DISAB_MANG_EFF_DT) or 
nvl( DATE_TRUNC('DAY',cur.CLM_DISAB_MANG_END_DT), '9999-12-31') != nvl(DATE_TRUNC('DAY',hist.CLM_DISAB_MANG_END_DT), '9999-12-31')
)
union
/*SIU-ADD-RTW*/
select AGRE_ID, 'RTW DATE ADD: '||typ.CLM_DISAB_MANG_DISAB_TYP_NM||' '||cdm.CLM_DISAB_MANG_EFF_DT ACTIVITY_DESCRIPTION, 
AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA
from pcmp.CLAIM_DISABILITY_MANAGEMENT cdm
left join pcmp.CLAIM_DISAB_MANG_DISAB_TYP typ on cdm.CLM_DISAB_MANG_DISAB_TYP_CD = typ.CLM_DISAB_MANG_DISAB_TYP_CD
where cdm.VOID_IND = 'n' and cdm.CLM_DISAB_MANG_DISAB_TYP_CD in ('offwkactrtw', 'offwkestrtw')
and DATE_TRUNC('DAY', cdm.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-RMV-RTW*/
select AGRE_ID, 'RTW DATE REMOVED' ACTIVITY_DESCRIPTION, 
COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CLAIM_DISABILITY_MANAGEMENT
where CLM_DISAB_MANG_DISAB_TYP_CD in ('offwkactrtw', 'offwkestrtw') and VOID_IND = 'y'
and COALESCE(DATE_TRUNC('DAY', AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-CHG-STOP-ACTV*/
select distinct c.AGRE_ID, 'SIU STOP ACTIVITY FLAG TURNED OFF' ACTIVITY_DESCRIPTION, cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT 
from pcmp.CLAIM c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
join 
(
select CUST_LIEN_REST_ID, CUST_ID, 
COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CUSTOMER_LIEN_RESTRICTION 
where VOID_IND = 'n' and LIEN_REST_TYP_CD = 'siu' and LIEN_REST_STS_TYP_CD = 'cls'
and COALESCE( DATE_TRUNC('DAY',AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur on p.CUST_ID = cur.cust_id
join
(
select CUST_LIEN_REST_ID from pcmp.CUSTOMER_LIEN_RESTRICTION_HIST
where VOID_IND = 'n' and LIEN_REST_TYP_CD = 'siu' and LIEN_REST_STS_TYP_CD = 'open'
and HIST_END_DTM is not null
and DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.CUST_LIEN_REST_ID = hist.CUST_LIEN_REST_ID 
where c.CLM_REL_SNPSHT_IND = 'n'
union
/*SIU-CHG-STOP-ACTV*/
select distinct c.AGRE_ID, 'SIU STOP ACTIVITY FLAG TURNED ON' ACTIVITY_DESCRIPTION, xy.AUDIT_USER_CREA_DTM, xy.AUDIT_USER_ID_CREA 
from pcmp.CLAIM c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD in ('clmt', 'dep', 'altpaye', 'bnfcy')
join 
(
select CUST_LIEN_REST_ID, CUST_ID, AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA
from pcmp.CUSTOMER_LIEN_RESTRICTION 
where VOID_IND = 'n' and LIEN_REST_TYP_CD = 'siu' and LIEN_REST_STS_TYP_CD = 'open'
and DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
select cur.CUST_LIEN_REST_ID, cur.CUST_ID, 
COALESCE(cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(cur.AUDIT_USER_ID_UPDT, cur.AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CUSTOMER_LIEN_RESTRICTION cur
join
(
select CUST_LIEN_REST_ID from pcmp.CUSTOMER_LIEN_RESTRICTION_HIST
where VOID_IND = 'n' and LIEN_REST_TYP_CD = 'siu' and LIEN_REST_STS_TYP_CD = 'cls'
and HIST_END_DTM is not null
and DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.CUST_LIEN_REST_ID = hist.CUST_LIEN_REST_ID 
where cur.VOID_IND = 'n' and cur.LIEN_REST_TYP_CD = 'siu' and cur.LIEN_REST_STS_TYP_CD = 'open'
and COALESCE( DATE_TRUNC('DAY',cur.AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', cur.AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) xy on xy.cust_id = p.CUST_ID
union
/*SIU-CHG-MMI*/
select cur.agre_id, 'CHANGE TO MMI' ACTIVITY_DESCRIPTION, cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT from
(
select cp.CLM_PRFL_ID, cp.AGRE_ID, cp.CLM_PRFL_ANSW_TEXT,
COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CLAIM_PROFILE cp
where VOID_IND = 'n' 
and   PRFL_STMT_ID in (6000229, 6000230, 6000231)
and   AGRE_ID in (select distinct agre_id from pcmp.CLAIM_DISABILITY_MANAGEMENT where VOID_IND = 'n' and CLM_DISAB_MANG_RSN_TYP_CD = 'mmi')
and   COALESCE( DATE_TRUNC('DAY',AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) cur
join
(
select cp.CLM_PRFL_ID, cp.AGRE_ID, cp.CLM_PRFL_ANSW_TEXT from pcmp.CLAIM_PROFILE_HISTORY cp
where VOID_IND = 'n' 
and   PRFL_STMT_ID in (6000229, 6000230, 6000231)
and   AGRE_ID in (select distinct agre_id from pcmp.CLAIM_DISABILITY_MANAGEMENT where VOID_IND = 'n' and CLM_DISAB_MANG_RSN_TYP_CD = 'mmi')
and   HIST_END_DTM is not null
and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) hist on cur.clm_prfl_id = hist.clm_prfl_id and nvl(cur.clm_prfl_answ_text, 'a') != nvl(hist.clm_prfl_answ_text, 'a')
union
/*SIU-ADD-MMI*/
select agre_id, 'ADD MMI' ACTIVITY_DESCRIPTION, AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA 
from pcmp.CLAIM_PROFILE cp
where VOID_IND = 'n' 
and   PRFL_STMT_ID in (6000229, 6000230, 6000231)
and   AGRE_ID in (select distinct agre_id from pcmp.CLAIM_DISABILITY_MANAGEMENT where VOID_IND = 'n' and CLM_DISAB_MANG_RSN_TYP_CD = 'mmi')
and   DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-CHG-DOI*/
select a.ACTV_CNTX_ID AGRE_ID, 'DATE OF INJURY CHANGE: '||c.CLM_OCCR_DTM ACTIVITY_DESCRIPTION, a.AUDIT_USER_CREA_DTM AUDIT_USER_UPDT_DTM, a.AUDIT_USER_ID_CREA AUDIT_USER_ID_UPDT
from pcmp.ACTIVITY a
join pcmp.ACTIVITY_DETAIL ad on a.ACTV_ID = ad.ACTV_ID
join pcmp.CLAIM c on a.ACTV_CNTX_ID = c.AGRE_ID and c.CLM_REL_SNPSHT_IND = 'n'
where a.cntx_typ_cd = 'clm'
and   a.SUBLOC_TYP_CD = 'clm_maint'
and   ad.actv_nm_typ_cd = 'clm_occr_dt'
and   ad.actv_actn_typ_cd = 'update'
and   DATE_TRUNC('DAY', a.AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
union
/*SIU-ADD-SUBRO*/
select cur.agre_id, 'SUBROGATION ADDED' ACTIVITY_DESCRIPTION, cur.AUDIT_USER_UPDT_DTM, cur.AUDIT_USER_ID_UPDT from
(
select AGRE_ID, COALESCE(AUDIT_USER_UPDT_DTM, AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, COALESCE(AUDIT_USER_ID_UPDT, AUDIT_USER_ID_CREA) AUDIT_USER_ID_UPDT
from pcmp.CLAIM 
where CLM_REL_SNPSHT_IND = 'n'
and   CLM_RCVR_TYP_CD = '05'
and   COALESCE(DATE_TRUNC('DAY',AUDIT_USER_UPDT_DTM), DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM)) >= (select RPT_PRVS_BSNS_DAY_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
) cur
join
(
select AGRE_ID, CLM_RCVR_TYP_CD from pcmp.CLAIM_HISTORY 
where CLM_REL_SNPSHT_IND = 'n'
and   (CLM_RCVR_TYP_CD <> '05' or CLM_RCVR_TYP_CD is null)
and   HIST_END_DTM is not null
and   DATE_TRUNC('DAY', HIST_END_DTM) >= (select RPT_PRVS_BSNS_DAY_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
) hist on cur.agre_id = hist.agre_id
union
/*SIU-NEW-CLAIM*/
select hist.AGRE_ID, 'NEW CLAIM FILED' ACTIVITY_DESCRIPTION, cur.AUDIT_USER_CREA_DTM, cur.AUDIT_USER_ID_CREA
from
(
select c.agre_id, p.cust_id, c.AUDIT_USER_CREA_DTM, c.AUDIT_USER_ID_CREA from
(
select AGRE_ID, AUDIT_USER_CREA_DTM, AUDIT_USER_ID_CREA
from pcmp.claim where CLM_REL_SNPSHT_IND = 'n'
and   DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
) c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'clmt'
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
) cur
join
(
select 
c.AGRE_ID, p.CUST_ID
from pcmp.claim c
join pcmp.PARTICIPATION p on c.AGRE_ID = p.AGRE_ID and p.PTCP_TYP_CD = 'clmt'
join pcmp.CLAIM_PARTICIPATION cp on p.PTCP_ID = cp.PTCP_ID and cp.CLM_PTCP_END_DT is null and cp.VOID_IND = 'n'
join pcmp.CUSTOMER_LIEN_RESTRICTION CLR on P.CUST_ID = CLR.CUST_ID and CLR.LIEN_REST_TYP_CD = 'siu' and CLR.LIEN_REST_STS_TYP_CD = 'open' and CLR.VOID_IND = 'n'
where CLM_REL_SNPSHT_IND = 'n'
) hist on cur.cust_id = hist.cust_id and cur.agre_id = hist.agre_id

/* Sep 2017 Release */
UNION
/*RULE#27*/
select a.AGRE_ID, 
'CHANGE IN CLAIMANT REPRESENTATIVE: '||d.CUST_NM_DRV_UPCS_NM ACTIVITY_DESCRIPTION,
c.AUDIT_USER_UPDT_DTM,
c.AUDIT_USER_ID_UPDT
from pcmp.CLAIM a
join pcmp.PARTICIPATION b on a.AGRE_ID = b.AGRE_ID
join pcmp.CLAIM_PARTICIPATION c on b.PTCP_ID = c.PTCP_ID
left join pcmp.CUSTOMER_NAME d on b.CUST_ID = d.CUST_ID and d.CUST_NM_TYP_CD in ('prsn_nm', 'busn_legal_nm') and d.VOID_IND = 'n' and d.CUST_NM_END_DT is null
where a.CLM_REL_SNPSHT_IND = 'n'
and b.PTCP_TYP_CD = 'clmt_atty'
and c.AUDIT_USER_UPDT_DTM is not null
and c.AUDIT_USER_UPDT_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
and to_char(c.AUDIT_USER_CREA_DTM, 'YYYY-MM-DD') <> TO_CHAR(c.AUDIT_USER_UPDT_DTM, 'YYYY-MM-DD')
UNION
/*RULE#28*/
select a.AGRE_ID, 
'NEW CLAIMANT REPRESENTATIVE ADDED: '||d.CUST_NM_DRV_UPCS_NM ACTIVITY_DESCRIPTION,
c.AUDIT_USER_CREA_DTM,
c.AUDIT_USER_ID_CREA
from pcmp.CLAIM a
join pcmp.PARTICIPATION b on a.AGRE_ID = b.AGRE_ID
join pcmp.CLAIM_PARTICIPATION c on b.PTCP_ID = c.PTCP_ID
left join pcmp.CUSTOMER_NAME d on b.CUST_ID = d.CUST_ID and d.CUST_NM_TYP_CD in ('prsn_nm', 'busn_legal_nm') and d.VOID_IND = 'n' and d.CUST_NM_END_DT is null
where a.CLM_REL_SNPSHT_IND = 'n'
and b.PTCP_TYP_CD = 'clmt_atty'
and c.AUDIT_USER_CREA_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
UNION
/*RULE#29*/
select a.AGRE_ID,
'CHANGE IN PROVIDER: '||d.CUST_NM_DRV_UPCS_NM ACTIVITY_DESCRIPTION,
c.AUDIT_USER_UPDT_DTM,
c.AUDIT_USER_ID_UPDT
from pcmp.CLAIM a
join pcmp.PARTICIPATION b on a.AGRE_ID = b.AGRE_ID
join pcmp.CLAIM_PARTICIPATION c on b.PTCP_ID = c.PTCP_ID
left join pcmp.CUSTOMER_NAME d on b.CUST_ID = d.CUST_ID and d.CUST_NM_TYP_CD in ('prsn_nm', 'busn_legal_nm') and d.VOID_IND = 'n' and d.CUST_NM_END_DT is null
where a.CLM_REL_SNPSHT_IND = 'n'
and b.PTCP_TYP_CD = 'prov'
and c.AUDIT_USER_UPDT_DTM is not null
and c.AUDIT_USER_UPDT_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
and to_char(c.AUDIT_USER_CREA_DTM, 'YYYY-MM-DD') <> TO_CHAR(c.AUDIT_USER_UPDT_DTM, 'YYYY-MM-DD')
UNION
/*RULE#30*/
select a.AGRE_ID,
'NEW PROVIDER ADDED: '||d.CUST_NM_DRV_UPCS_NM ACTIVITY_DESCRIPTION,
c.AUDIT_USER_CREA_DTM,
c.AUDIT_USER_ID_CREA
from pcmp.CLAIM a
join pcmp.PARTICIPATION b on a.AGRE_ID = b.AGRE_ID
join pcmp.CLAIM_PARTICIPATION c on b.PTCP_ID = c.PTCP_ID
left join pcmp.CUSTOMER_NAME d on b.CUST_ID = d.CUST_ID and d.CUST_NM_TYP_CD in ('prsn_nm', 'busn_legal_nm') and d.VOID_IND = 'n' and d.CUST_NM_END_DT is null
where a.CLM_REL_SNPSHT_IND = 'n'
and b.PTCP_TYP_CD = 'prov'
and c.AUDIT_USER_CREA_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
UNION
/*RULE#31*/
select a.AGRE_ID, 
'NEW PRIMARY ASSIGNMENT ADDED ON: '||to_char(b.ASGN_EFF_DT, 'MM/DD/YYYY')||', '||c.USER_DRV_UPCS_NM ||', '|| e.FNCT_ROLE_NM ||', '|| d.ORG_UNT_ABRV_NM  ACTIVITY_DESCRIPTION,
b.AUDIT_USER_CREA_DTM, b.AUDIT_USER_ID_CREA
from pcmp.claim a
join pcmp.ASSIGNMENT b on a.AGRE_ID = b.ASGN_CNTX_ID
left join pcmp.USERS c on b.USER_ID = c.USER_ID
left join pcmp.ORGANIZATIONAL_UNIT d on b.ORG_UNT_ID = d.ORG_UNT_ID
left join pcmp.FUNCTIONAL_ROLE e on b.FNCT_ROLE_ID = e.FNCT_ROLE_ID
where a.CLM_REL_SNPSHT_IND = 'n' 
and   b.APP_CNTX_TYP_CD = 'claim'
and   b.AUDIT_USER_CREA_DTM >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)

UNION
/*RULE#32*/
select 
TASK_CNTX_ID AGRE_ID, 
'IC-2 Filed' ACTIVITY_DESCRIPTION,
DATE_TRUNC('DAY',AUDIT_USER_CREA_DTM) AUDIT_USER_UPDT_DTM, 
AUDIT_USER_ID_CREA AUDIT_USER_ID_UPDT
from
(
select *, ROW_NUMBER() over (partition by TASK_ID order by HIST_EFF_DTM) RNK
from pcmp.TASK_HISTORY 
where TASK_NM = 'IC - APPLICATION FOR PERMANENT TOTAL DIS Filed'
and  DATE_TRUNC('DAY', AUDIT_USER_CREA_DTM) >= (select PRVS1_BSNS_DAY_DATE from TEMP_DATES where ACTUAL_DT = CURRENT_DATE)
)X where RNK = 1;

/*STEP-4: Create temp table to check for activilities on claims with SIU flag*/
CREATE TEMPORARY TABLE FDAR_TEMP_3  AS 
select 
A.SERVICE_OFFICE_NAME,
A.SIU_NAME,
A.CUST_NAME,
A.SSN,
A.ROLE_TYPE,
A.AGRE_ID,
A.CLAIM_NO,
DATE_TRUNC('DAY',B.AUDIT_USER_UPDT_DTM) CHANGED_DATE,
B.ACTIVITY_DESCRIPTION DESCRIPTION,
u.USER_DRV_UPCS_NM CHANGED_BY
from FDAR_TEMP_1 a
join FDAR_TEMP_2 b on a.AGRE_ID = b.AGRE_ID
left join pcmp.USERS u on B.AUDIT_USER_ID_UPDT = u.USER_ID;

/*STEP-5: Truncate and Insert into target table*/
TRUNCATE TABLE DW_REPORT.DW_CLAIM_FRAUD_DAILY_ACTIVITY_RPT;
  
INSERT  /*+DIRECT*/  INTO DW_REPORT.DW_CLAIM_FRAUD_DAILY_ACTIVITY_RPT
(SERVICE_OFFICE_NAME,
SIU_NAME,
CUST_NAME,
CUST_SSN,
PTCP_TYP_NAME,
AGRE_ID,
CLM_NO,
CREA_UPDT_DATE,
SIU_ACTIVITY_DESC,
CREA_UPDT_USER_NAME)
SELECT 
SERVICE_OFFICE_NAME,
SIU_NAME,
CUST_NAME,
SSN,
ROLE_TYPE,
AGRE_ID,
CLAIM_NO,
CHANGED_DATE,
DESCRIPTION,
CHANGED_BY
FROM FDAR_TEMP_3
GROUP BY 
SERVICE_OFFICE_NAME,
SIU_NAME,
CUST_NAME,
SSN,
ROLE_TYPE,
AGRE_ID,
CLAIM_NO,
CHANGED_DATE,
DESCRIPTION,
CHANGED_BY
ORDER BY AGRE_ID;
COMMIT;