/* Version #  1		 	:  	(Prod Release date 05/16/2017 ) */
/* Version #  2		 	:  	(Prod Release date 08/22/2017 ) */  
/* Version #  3		 	:  	(Prod Release date 09/26/2017 ) 
							 1.Date of injury (occurrence) is the determining factor if a claim is within the “4-year limit” for severity claims. 
							 2.	If Claim Type  = MO then
								a.	If LDW and ARTW, then determine days for each event, determine days for period and limit the period total to 7 days. (this is how we are handling it currently).
								b.	If no ARTW Then handle as above, but for the final event (with no ARTW) insert a cut-off, limited to 7 days (either based on LDW or DOI (if no LDW). (Don’t apply days into future periods). */



/* Table Description 		: 	This report is used to determine an employer’s frequency and severity performance measurements. This report calculates claim 
					counts and days absent. This is then used to calculate employer claims frequency and severity for Policy Summary Report.Then two 
					years of claim frequency and severity is used to determine the Safety Council Performance bonus. The output of this report is 
					used by S&H to create the policy file to be sent to R&P for PERFORMANCE bonus eligibility/calculations. One row per CLAIM by 
					CALENDAR YEAR or FISCAL YEAR.  Both Payroll (PDP) and no Payroll queries for both Fiscal and Calendar years can use this table. 
					Data for the current year plus the last 4 years. This summary table is built once for every QUARTER.*/				
							
						
/* L1 Dependency 		: 	DW_REPORT.DW_CLAIM
					DW_REPORT.DW_STATUS
					DW_REPORT.DW_CLAIM_POLICY_HISTORY
					DW_REPORT.DW_PARTICIPATION
					DW_REPORT.DW_CUSTOMER
					DW_REPORT.DW_PLCY_END_OF_CHAIN_CMBNS
					DW_REPORT.DW_EMPLOYER_DEMOGRAPHICS
					DW_REPORT.DATE_DIM
					DW_REPORT.DW_CLAIM_RTW */

/* SCHEDULING 			:       This table needs to be refreshed on 1st weekend of EVERY MONTH */



/* STEP 1: 
1.	Select claims where PS Claim Status = ‘accepted’ or Claim Status like ‘pending*’ 
2.	PS -- Claim Status Reason NOT in (‘dismissed’, ‘duplicate’, ‘denied/appeal period’, ‘ag settlement, ‘re-file’).
3.	Claim is Not Combined (CRNT_CMBND_FLAG = 'N') 
4.	Claim has current ‘insrd’ participation where customer name is not equals to 'No Insured Found'. (no policy on a claim)
5.  Identify end of chain policy and exclude 'si' policies.
*/

--\set ON_ERROR_STOP on
CREATE TEMPORARY TABLE RTW_TEMP_1  as
select 
a.CLM_AGRE_ID, 
a.CLM_NO,
date(a.CLM_OCCR_DTM) CLAIM_INJURY_DATE,
date(a.AUDIT_USER_CREA_DTM) CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
date(a.CLM_CLMT_LST_WK_DT) CLM_CLMT_LST_WK_DT,
date(clmt.PRSN_DTH_DTM) PRSN_DTH_DTM,
date(COD.SETTLEMENT_DATE) SETTLEMENT_DATE,
b.STT_TYP_CD, 
b.STT_TYP_NM, 
b.STS_TYP_CD,
b.STS_TYP_NM,
b.TRANS_RSN_TYP_CD,
b.TRANS_RSN_TYP_NM,
c.INS_PARTICIPANT, 
c.PLCY_NO,
c.PLCY_AGRE_ID,
c.BUSN_SEQ_NO,
clmt.CUST_NM_NM CLAIMANT_FULL_NAME,
eoc.EOC_PLCY_AGRE_ID,
eoc.EOC_CUST_ID_ACCT_HLDR,
eoc.EOC_PLCY_NO,
eoc.EOC_BSNS_SQNC_NO,
plcy.CRNT_PLCY_TYPE_CODE,
plcy.CRNT_PLCY_TYPE_UPRCS_CODE,
case when plcy.CRNT_PLCY_TYPE_UPRCS_CODE = 'PEC' then 'C' else 'F' end YEAR_TYP,
plcy.EMPLR_LEGAL_NAME,
plcy.EMPLR_PHYS_ADRS_LINE1,
plcy.EMPLR_PHYS_ADRS_LINE2,
plcy.EMPLR_PHYS_ADRS_CITY_NAME,
plcy.EMPLR_PHYS_ADRS_STATE_NAME,
plcy.EMPLR_PHYS_ADRS_POST_CODE
from dw_report.DW_CLAIM a
join dw_report.DW_STATUS b on a.STATUS_ID = b.STATUS_ID
join dw_report.DW_CLAIM_POLICY_HISTORY c on  a.CLM_AGRE_ID = c.CLM_AGRE_ID 
                                         and c.CRNT_PLCY_IND = 'y' 
                                         and c.INS_PARTICIPANT not in (800000, 1000004007, 1000042034)
left join dw_report.DW_PARTICIPATION ptcp on a.CLM_AGRE_ID = ptcp.AGRE_ID and ptcp.PTCP_TYP_CD = 'clmt' and ptcp.CRNT_PTCP_IND = 'y'
left join DW_REPORT.DW_CUSTOMER clmt on ptcp.CUST_ID = clmt.CUST_ID and clmt.CUST_NM_TYP_CD = 'prsn_nm' and clmt.CUST_NM_END_DT is null
join dw_report.DW_PLCY_END_OF_CHAIN_CMBNS eoc on c.PLCY_AGRE_ID = eoc.PLCY_AGRE_ID and c.PLCY_NO = eoc.PLCY_NO
join dw_report.DW_EMPLOYER_DEMOGRAPHICS plcy on eoc.EOC_PLCY_AGRE_ID = plcy.AGRE_ID and eoc.EOC_PLCY_NO = plcy.PLCY_NO
                                             and eoc.EOC_BSNS_SQNC_NO = plcy.BUSN_SEQ_NO
left join (
            SELECT AGRE_ID, MIN(CLM_OTHR_DT_EFF_DT) SETTLEMENT_DATE 
            FROM PCMP.CLAIM_OTHER_DATE
            WHERE VOID_IND = 'n'
            AND   CLM_DT_TYP_CD IN ('setlbth', 'setlindm')
            AND   CLM_OTHR_DT_END_DT IS NULL
            GROUP BY 1
          ) COD on a.clm_agre_id = COD.agre_id
where a.CLM_REL_SNPSHT_IND = 'n'
and   a.CLAIM_CMBND_IND = 'n'
and   (b.STS_TYP_CD = 'acpt' or b.STS_TYP_CD like 'pnd%')
and   b.TRANS_RSN_TYP_CD not in ('dsmssd', 'dup', 'dnyaplprd', 'ag_setlmnt', 'refile')
and   plcy.CRNT_PLCY_TYPE_CODE in ('pes', 'pec', 'bl', 'mif', 'pa')
;

/* Calculating date to indentify claims reported in the measurement year plus claims with injury dates in any of the four previous years */
CREATE TEMPORARY TABLE RTW_TEMP_A0  as
select 'C' YEAR_TYP, min(add_months(CRNT_YEAR_BGNG_DATE, -48)) CRNT_YEAR_BGNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
union
select 'F' YEAR_TYP, min(add_months(FSCL_YEAR_BGNG_DATE, -48)) FSCL_YEAR_BGNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
;

/*filter claims which fall within the measurement period year plus claims with injury dates in any of the four previous years
and filter claims that are entered after the previous quarter end date */
CREATE TEMPORARY TABLE RTW_TEMP_A1  as
select a.* from RTW_TEMP_1 A
join RTW_TEMP_A0 B ON A.YEAR_TYP = B.YEAR_TYP
WHERE A.CLAIM_ENTRY_DATE >= CRNT_YEAR_BGNG_DATE
AND A.CLAIM_ENTRY_DATE <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
;

/*EPM Periods*/
CREATE TEMPORARY TABLE RTW_TEMP_2  as
select distinct 'C' YEAR_TYP, YEAR_YYYY_NO, CRNT_YEAR_BGNG_DATE, CRNT_YEAR_ENDNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
union
select distinct 'F' YEAR_TYP, FISC_YYYY_NO, FSCL_YEAR_BGNG_DATE, FSCL_YEAR_ENDNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
;

/*Death Claims (NOI_CTG_TYP_CD = 'dth'). 
Days absent beginning are calculated from the day after injury and continuing "forever", for a maximum of 365 days in each of the measurement years*/
CREATE TEMPORARY TABLE RTW_TEMP_DEATH_CLAIMS  as
select
a.CLM_AGRE_ID, 
a.CLM_NO, 
a.CLAIMANT_FULL_NAME, 
a.YEAR_TYP, 
b.YEAR_YYYY_NO,
b.CRNT_YEAR_BGNG_DATE,
b.CRNT_YEAR_ENDNG_DATE,
nvl(c.DAYS_ABSENT, 0) DAYS_ABSENT,
case when date(a.CLAIM_ENTRY_DATE) between B.CRNT_YEAR_BGNG_DATE and B.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
a.claim_injury_date,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD,
a.STT_TYP_NM,
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO, 
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID, 
a.EOC_PLCY_AGRE_ID, 
a.EOC_CUST_ID_ACCT_HLDR, 
a.EOC_PLCY_NO, 
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE, 
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE, 
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME, 
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
from RTW_TEMP_A1 a 
join RTW_TEMP_2 b on a.year_typ = b.year_typ
left join
(
select a.clm_agre_id, b.year_yyyy_no, b.CRNT_YEAR_BGNG_DATE, b.CRNT_YEAR_ENDNG_DATE, count(b.actual_dt) DAYS_ABSENT, 'C' YEAR_TYP
from RTW_TEMP_A1 a
join 
(
select * from dw_report.DATE_DIM 
where ACTUAL_DT >= (select min(crnt_year_bgng_date) bgng from rtw_temp_2 WHERE year_typ = 'C')
and   ACTUAL_DT <= (select max(crnt_year_endng_date) endng from rtw_temp_2 WHERE year_typ = 'C')
) b on b.ACTUAL_DT > a.claim_injury_date and b.ACTUAL_DT <= date(nvl( DATEADD('DAY',365, a.prsn_dth_dtm) , DATEADD('DAY',365,current_date)))
where a.NOI_CTG_TYP_CD = 'dth'
group by a.clm_agre_id, b.year_yyyy_no, b.CRNT_YEAR_BGNG_DATE, b.CRNT_YEAR_ENDNG_DATE
UNION
select a.clm_agre_id, b.FISC_YYYY_NO, b.FSCL_YEAR_BGNG_DATE, b.FSCL_YEAR_ENDNG_DATE, count(b.actual_dt) DAYS_ABSENT, 'F' YEAR_TYP
from RTW_TEMP_A1 a
join 
(
select * from dw_report.DATE_DIM 
where ACTUAL_DT >= (select min(crnt_year_bgng_date) bgng from rtw_temp_2 WHERE year_typ = 'F')
and   ACTUAL_DT <= (select max(crnt_year_endng_date) endng from rtw_temp_2 WHERE year_typ = 'F')
) b on b.ACTUAL_DT > a.claim_injury_date and b.ACTUAL_DT <= date(nvl( DATEADD('DAY',365,a.prsn_dth_dtm), DATEADD('DAY',365,current_date )))
where a.NOI_CTG_TYP_CD = 'dth'
group by a.clm_agre_id, b.FISC_YYYY_NO, b.FSCL_YEAR_BGNG_DATE, b.FSCL_YEAR_ENDNG_DATE
) c on a.clm_agre_id = c.clm_agre_id and a.year_typ = c.year_typ and b.year_yyyy_no = c.year_yyyy_no
where a.NOI_CTG_TYP_CD = 'dth'
order by a.clm_agre_id, b.year_yyyy_no;

/*
  Adjusting days absent = 7 for medical only claims which doesn't have a row in DW_CLAIM_RTW table.
  EXCLUDING DEATH CLAIMS FROM MEDICAL ONLY
*/
CREATE TEMPORARY TABLE RTW_TEMP_MEDICAL_ONLY_A  as
select 
a.CLM_AGRE_ID,
a.CLM_NO,
a.CLAIMANT_FULL_NAME,
a.YEAR_TYP,
c.YEAR_YYYY_NO, 
c.CRNT_YEAR_BGNG_DATE, 
c.CRNT_YEAR_ENDNG_DATE,
case 
     when 
          a.CLAIM_INJURY_DATE between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE 
          and DATEADD('DAY',7,a.CLAIM_INJURY_DATE) between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE
     then datediff('d', a.CLAIM_INJURY_DATE, DATEADD('DAY',7, a.CLAIM_INJURY_DATE))
     when 
          a.CLAIM_INJURY_DATE between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE 
          and DATEADD('DAY',7,a.CLAIM_INJURY_DATE) not between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE 
     then datediff('d', a.CLAIM_INJURY_DATE, c.CRNT_YEAR_ENDNG_DATE)  
     when 
          a.CLAIM_INJURY_DATE not between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE 
          and DATEADD('DAY',7,a.CLAIM_INJURY_DATE) between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE 
     then datediff('d', c.CRNT_YEAR_BGNG_DATE, DATEADD('DAY',7, a.CLAIM_INJURY_DATE))+1
     else 0
end DAYS_ABSENT, 
case when date(a.CLAIM_ENTRY_DATE) between c.CRNT_YEAR_BGNG_DATE and c.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
a.CLAIM_INJURY_DATE,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD, 
a.STT_TYP_NM, 
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO,
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID,
a.EOC_PLCY_AGRE_ID,
a.EOC_CUST_ID_ACCT_HLDR,
a.EOC_PLCY_NO,
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE,
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE,
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME,
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1,
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2,
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME,
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME,
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
from RTW_TEMP_A1 A
left join 
(
select distinct 'C' YEAR_TYP, YEAR_YYYY_NO, CRNT_YEAR_BGNG_DATE, CRNT_YEAR_ENDNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
union
select distinct 'F' YEAR_TYP, FISC_YYYY_NO, FSCL_YEAR_BGNG_DATE, FSCL_YEAR_ENDNG_DATE from DW_REPORT.DATE_DIM
where ACTUAL_DT <= (select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE)
and ACTUAL_DT >= (select add_months((select PRVS_QTR_ENDNG_DATE from DW_REPORT.DATE_DIM where ACTUAL_DT = CURRENT_DATE),-48) from dual)
) c on a.YEAR_TYP = c.YEAR_TYP
where a.clm_typ_cd = 'medonly'
AND   A.NOI_CTG_TYP_CD <> 'dth'
and  not exists (select clm_no from dw_report.DW_CLAIM_RTW where a.clm_no = DW_CLAIM_RTW.CLM_NO)
;


/*Adjusting days absent = 7 for medical only claims which does have rows in DW_CLAIM_RTW table.
  EXCLUDING DEATH CLAIMS FROM MEDICAL ONLY*/
CREATE TEMPORARY TABLE RTW_TEMP_MEDICAL_ONLY_B  as
select
a.CLM_AGRE_ID, 
a.CLM_NO, 
a.CLAIMANT_FULL_NAME, 
a.YEAR_TYP, 
b.YEAR_YYYY_NO,
b.CRNT_YEAR_BGNG_DATE,
b.CRNT_YEAR_ENDNG_DATE,
nvl(case when c.DAYS_ABSENT > 7 then 7 else c.DAYS_ABSENT end, 0) DAYS_ABSENT,
case when date(a.CLAIM_ENTRY_DATE) between B.CRNT_YEAR_BGNG_DATE and B.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
a.claim_injury_date,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD,
a.STT_TYP_NM,
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO, 
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID, 
a.EOC_PLCY_AGRE_ID, 
a.EOC_CUST_ID_ACCT_HLDR, 
a.EOC_PLCY_NO, 
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE, 
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE, 
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME, 
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
from RTW_TEMP_A1 a 
join RTW_TEMP_2 b on a.year_typ = b.year_typ
left join
(
select a.clm_agre_id, b.year_yyyy_no, b.CRNT_YEAR_BGNG_DATE, b.CRNT_YEAR_ENDNG_DATE, count(distinct b.actual_dt) DAYS_ABSENT, 'C' YEAR_TYP
from RTW_TEMP_A1 a
/* Added Version # 3  Release "DW_REPORT.DW_CLAIM_RTW" */
join (SELECT CLM_NO, LDW, CASE WHEN DATEDIFF('D', LDW, ARTW) > 7 THEN DATEADD('DAY',8, LDW) ELSE ARTW END ARTW FROM DW_REPORT.DW_CLAIM_RTW) rtw on a.clm_no = rtw.CLM_NO 
join 
(
select * from dw_report.DATE_DIM 
where ACTUAL_DT >= (select min(crnt_year_bgng_date) bgng from rtw_temp_2 WHERE year_typ = 'C')
and   ACTUAL_DT <= (select max(crnt_year_endng_date) endng from rtw_temp_2 WHERE year_typ = 'C')
) b on b.ACTUAL_DT > rtw.LDW and b.ACTUAL_DT < rtw.ARTW
where a.clm_typ_cd = 'medonly' AND   A.NOI_CTG_TYP_CD <> 'dth'
group by a.clm_agre_id, b.year_yyyy_no, b.CRNT_YEAR_BGNG_DATE, b.CRNT_YEAR_ENDNG_DATE
UNION
select a.clm_agre_id, b.FISC_YYYY_NO, b.FSCL_YEAR_BGNG_DATE, b.FSCL_YEAR_ENDNG_DATE, count(b.actual_dt) DAYS_ABSENT, 'F' YEAR_TYP
from RTW_TEMP_A1 a
/*Added Version # 3  Release "DW_REPORT.DW_CLAIM_RTW" */
join (SELECT CLM_NO, LDW, CASE WHEN DATEDIFF('D', LDW, ARTW) > 7 THEN DATEADD(DAY,8,LDW) ELSE ARTW END ARTW FROM DW_REPORT.DW_CLAIM_RTW) rtw on a.clm_no = rtw.CLM_NO 
join 
(
select * from dw_report.DATE_DIM 
where ACTUAL_DT >= (select min(crnt_year_bgng_date) bgng from rtw_temp_2 WHERE year_typ = 'F')
and   ACTUAL_DT <= (select max(crnt_year_endng_date) endng from rtw_temp_2 WHERE year_typ = 'F')
) b on b.ACTUAL_DT > rtw.LDW and b.ACTUAL_DT < rtw.ARTW
where  a.clm_typ_cd = 'medonly' AND   A.NOI_CTG_TYP_CD <> 'dth'
group by a.clm_agre_id, b.FISC_YYYY_NO, b.FSCL_YEAR_BGNG_DATE, b.FSCL_YEAR_ENDNG_DATE
) c on a.clm_agre_id = c.clm_agre_id and a.year_typ = c.year_typ and b.year_yyyy_no = c.year_yyyy_no
where a.clm_typ_cd = 'medonly' AND   A.NOI_CTG_TYP_CD <> 'dth'
and  not exists (select clm_no from RTW_TEMP_MEDICAL_ONLY_A where a.clm_no = RTW_TEMP_MEDICAL_ONLY_A.CLM_NO)
order by a.clm_agre_id, b.year_yyyy_no
;

/*All medical only claims*/
CREATE TEMPORARY TABLE RTW_TEMP_MEDICAL_ONLY  as
select * from RTW_TEMP_MEDICAL_ONLY_A
union
select * from RTW_TEMP_MEDICAL_ONLY_B;

/*Exception: 1 - Identifying OD claims with no last day work*/
CREATE TEMPORARY TABLE OD_CLAIMS_NO_LST_DAY_WK  AS
WITH 
Query1 AS 
( 
  SELECT
  A.AGRE_ID
  FROM PCMP.CLAIM A
  WHERE A.CLM_REL_SNPSHT_IND = 'n'
  GROUP BY 
  A.AGRE_ID
),
Query2 AS 
(
  SELECT
  C.AGRE_ID,
  E.CLM_DISAB_MANG_DISAB_TYP_CD
  FROM PCMP.CLAIM C
  LEFT JOIN PCMP.CLAIM_DISABILITY_MANAGEMENT E ON E.AGRE_ID = C.AGRE_ID 
  WHERE C.CLM_REL_SNPSHT_IND = 'n'
  AND   E.VOID_IND = 'n'
  AND   E.CLM_DISAB_MANG_DISAB_TYP_CD = 'working' 
  AND   NOT ( E.CLM_DISAB_MANG_END_DT IS NULL ) 
  GROUP BY 
  C.AGRE_ID, 
  E.CLM_DISAB_MANG_DISAB_TYP_CD
) 
  SELECT
  Query1.AGRE_ID, 
  Query2.CLM_DISAB_MANG_DISAB_TYP_CD
  FROM Query1
  LEFT JOIN Query2 ON Query1.AGRE_ID = Query2.AGRE_ID 
  WHERE Query2.CLM_DISAB_MANG_DISAB_TYP_CD IS NULL 
  GROUP BY 
  Query1.AGRE_ID, 
  Query2.CLM_DISAB_MANG_DISAB_TYP_CD
;

/*Assign DAYS_ABSENT = 0 for OD CLAIMS with no last day worked*/
CREATE TEMPORARY TABLE RTW_TEMP_LT_EXCEPTION_1  AS
SELECT 
a.CLM_AGRE_ID, 
a.CLM_NO, 
a.CLAIMANT_FULL_NAME, 
a.YEAR_TYP, 
C.YEAR_YYYY_NO,
C.CRNT_YEAR_BGNG_DATE,
C.CRNT_YEAR_ENDNG_DATE,
0 DAYS_ABSENT,
case when date(a.CLAIM_ENTRY_DATE) between C.CRNT_YEAR_BGNG_DATE and C.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
a.claim_injury_date,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD,
a.STT_TYP_NM,
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO, 
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID, 
a.EOC_PLCY_AGRE_ID, 
a.EOC_CUST_ID_ACCT_HLDR, 
a.EOC_PLCY_NO, 
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE, 
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE, 
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME, 
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
FROM RTW_TEMP_A1 A
JOIN (SELECT DISTINCT AGRE_ID FROM OD_CLAIMS_NO_LST_DAY_WK) B ON A.CLM_AGRE_ID = B.AGRE_ID
JOIN RTW_TEMP_2 C ON A.YEAR_TYP = C.YEAR_TYP
WHERE CLM_TYP_CD = 'losttm'
AND   NOI_CTG_TYP_CD = 'occ_dis'
;

/*Exception: 2 - Identifying claims with no last day work and no pay plan other than %PP*/
CREATE TEMPORARY TABLE LT_CLAIMS_NO_LDW_PP_STEP_1  as
WITH 
Query1 AS 
( 
  SELECT
  A.AGRE_ID, 
  B.BNFT_TYP_CD
  FROM PCMP.CLAIM A
  JOIN PCMP.INDEMNITY_PAYMENT B ON A.AGRE_ID = B.AGRE_ID 
  WHERE A.CLM_REL_SNPSHT_IND = 'n'
  AND   B.BNFT_TYP_CD IN ('ppd-oh', 'ppdp-oh') 
  AND   B.VOID_IND = 'n' 
  GROUP BY 
  A.AGRE_ID, 
  B.BNFT_TYP_CD
),	
Query2 AS 
(
  SELECT
  C.AGRE_ID, 
  D.BNFT_TYP_CD, 
  E.CLM_DISAB_MANG_DISAB_TYP_CD
  FROM PCMP.CLAIM C
  JOIN PCMP.INDEMNITY_PAYMENT D ON C.AGRE_ID = D.AGRE_ID
  LEFT JOIN PCMP.CLAIM_DISABILITY_MANAGEMENT E ON E.AGRE_ID = C.AGRE_ID 
  WHERE C.CLM_REL_SNPSHT_IND = 'n'
  AND   D.VOID_IND = 'n' 
  AND   D.BNFT_TYP_CD IN ('ppd-oh', 'ppdp-oh') 
  AND   E.VOID_IND = 'n'
  AND   E.CLM_DISAB_MANG_DISAB_TYP_CD = 'working' 
  AND   NOT ( E.CLM_DISAB_MANG_END_DT IS NULL ) 
  GROUP BY 
  C.AGRE_ID, 
  D.BNFT_TYP_CD, 
  E.CLM_DISAB_MANG_DISAB_TYP_CD
) ,
Query3 AS 
(
  SELECT
  F.AGRE_ID, 
  G.BNFT_TYP_CD
  FROM PCMP.CLAIM F
  JOIN PCMP.INDEMNITY_PAYMENT G ON F.AGRE_ID = G.AGRE_ID 
  WHERE F.CLM_REL_SNPSHT_IND = 'n'
  AND   NOT (G.BNFT_TYP_CD IN ('ppd-oh', 'ppdp-oh')) 
  AND   G.VOID_IND = 'n' 
  GROUP BY 
  F.AGRE_ID, 
  G.BNFT_TYP_CD
),
Query4 AS 
(
  SELECT
  Query1.AGRE_ID, 
  Query1.BNFT_TYP_CD, 
  Query2.CLM_DISAB_MANG_DISAB_TYP_CD
  FROM Query1
  LEFT JOIN Query2 ON Query1.AGRE_ID = Query2.AGRE_ID 
  WHERE Query2.CLM_DISAB_MANG_DISAB_TYP_CD IS NULL 
  GROUP BY 
  Query1.AGRE_ID, 
  Query1.BNFT_TYP_CD, 
  Query2.CLM_DISAB_MANG_DISAB_TYP_CD
)
SELECT
Query4.AGRE_ID, 
Query4.BNFT_TYP_CD, 
Query3.BNFT_TYP_CD AS Benefit_Type_Name1
FROM Query4
LEFT OUTER JOIN Query3 ON Query4.AGRE_ID = Query3.AGRE_ID 
WHERE Query3.BNFT_TYP_CD IS NULL 
GROUP BY 
Query4.AGRE_ID, 
Query4.BNFT_TYP_CD, 
Query3.BNFT_TYP_CD
ORDER BY Query4.AGRE_ID DESC
;

/*Assign DAYS_ABSENT = 0 for CLAIMS with no last day worked and no pay plan other than %PP*/
CREATE TEMPORARY TABLE RTW_TEMP_LT_EXCEPTION_2  AS
SELECT 
a.CLM_AGRE_ID, 
a.CLM_NO, 
a.CLAIMANT_FULL_NAME, 
a.YEAR_TYP, 
C.YEAR_YYYY_NO,
C.CRNT_YEAR_BGNG_DATE,
C.CRNT_YEAR_ENDNG_DATE,
0 DAYS_ABSENT,
case when date(a.CLAIM_ENTRY_DATE) between C.CRNT_YEAR_BGNG_DATE and C.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
a.claim_injury_date,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD,
a.STT_TYP_NM,
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO, 
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID, 
a.EOC_PLCY_AGRE_ID, 
a.EOC_CUST_ID_ACCT_HLDR, 
a.EOC_PLCY_NO, 
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE, 
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE, 
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME, 
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
FROM RTW_TEMP_A1 A
JOIN (SELECT DISTINCT AGRE_ID FROM LT_CLAIMS_NO_LDW_PP_STEP_1) B ON A.CLM_AGRE_ID = B.AGRE_ID
JOIN RTW_TEMP_2 C ON A.YEAR_TYP = C.YEAR_TYP
WHERE CLM_TYP_CD = 'losttm'
AND   NOI_CTG_TYP_CD <> 'dth'
AND   A.CLM_AGRE_ID NOT IN (SELECT DISTINCT CLM_AGRE_ID FROM RTW_TEMP_LT_EXCEPTION_1)
;

/* Rest of all the losttime claims with nature of injury not equals to death
   Days absent calculation should stop at the earliest of End of Meausrement year or Claimants Death date or Settlement Date or Actual RTW.
*/
CREATE TEMPORARY TABLE RTW_TEMP_LT_CLAIMS_1  as
select 
a.CLM_AGRE_ID, 
a.CLM_NO, 
a.CLAIMANT_FULL_NAME, 
a.YEAR_TYP, 
DATE(NVL(CLM_CLMT_LST_WK_DT, CLAIM_INJURY_DATE)) START_DATE,
LEAST( DATE(END_OF_MSRMN_PRD),
       nvl(DATE(PRSN_DTH_DTM), '9999-12-31'), 
       nvl(DATE(SETTLEMENT_DATE), '9999-12-31'), 
       nvl(b.ARTW, '9999-12-31')) STOP_DATE,
date(d.LDW) LDW,
date(d.ARTW) ARTW,
a.claim_injury_date,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD,
a.STT_TYP_NM,
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO, 
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID, 
a.EOC_PLCY_AGRE_ID, 
a.EOC_CUST_ID_ACCT_HLDR, 
a.EOC_PLCY_NO, 
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE, 
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE, 
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME, 
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
from RTW_TEMP_A1 a
left join (select CLM_NO, MAX(date(ARTW)) ARTW from dw_report.DW_CLAIM_RTW group by 1) b on a.clm_no = b.clm_no
left join (SELECT YEAR_TYP, MAX(CRNT_YEAR_ENDNG_DATE) END_OF_MSRMN_PRD FROM RTW_TEMP_2 GROUP BY 1) c on a.year_typ = c.year_typ
left join dw_report.DW_CLAIM_RTW d on a.clm_no = d.CLM_NO 
where clm_typ_cd = 'losttm' 
and   noi_ctg_typ_cd <> 'dth'
and   NOT EXISTS (SELECT CLM_AGRE_ID FROM RTW_TEMP_LT_EXCEPTION_1 WHERE RTW_TEMP_LT_EXCEPTION_1.CLM_AGRE_ID = A.CLM_AGRE_ID)
and   NOT EXISTS (SELECT CLM_AGRE_ID FROM RTW_TEMP_LT_EXCEPTION_2 WHERE RTW_TEMP_LT_EXCEPTION_2.CLM_AGRE_ID = A.CLM_AGRE_ID)
;


/* Adjusting Start date and stop date for days absent calcuation when there is no record in DW_CLAIM_RTW table.
   Adjusting Start date and stop date for days absent calcuation at earliest of End of Meausrement year or Claimants Death date or Settlement Date or Actual RTW.
*/
CREATE TEMPORARY TABLE RTW_TEMP_LT_CLAIMS_2  as
select 
CLM_AGRE_ID, 
CLM_NO, 
CLAIMANT_FULL_NAME, 
YEAR_TYP, 
start_date+1 START_DATE,
case when stop_date = END_OF_MSRMN_PRD then stop_date else stop_date-1 end STOP_DATE,
claim_injury_date,
CLAIM_ENTRY_DATE,
CLM_TYP_CD,
CLM_TYP_NM,
NOI_CTG_TYP_CD,
NOI_CTG_TYP_NM,
CLM_CLMT_LST_WK_DT,
PRSN_DTH_DTM,
STT_TYP_CD,
STT_TYP_NM,
STS_TYP_CD,
STS_TYP_NM,
TRANS_RSN_TYP_CD,
TRANS_RSN_TYP_NM,
PLCY_NO, 
CUST_ID_ACCT_HLDR, 
PLCY_AGRE_ID, 
EOC_PLCY_AGRE_ID, 
EOC_CUST_ID_ACCT_HLDR, 
EOC_PLCY_NO, 
EOC_PLCY_TYPE_CODE, 
EOC_PLCY_TYPE_UPRCS_CODE, 
EOC_EMPLR_LEGAL_NAME, 
EOC_EMPLR_PHYS_ADRS_LINE1, 
EOC_EMPLR_PHYS_ADRS_LINE2, 
EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
EOC_EMPLR_PHYS_ADRS_POST_CODE
from
(
SELECT 
a.CLM_AGRE_ID, 
a.CLM_NO, 
a.CLAIMANT_FULL_NAME, 
a.YEAR_TYP, 
c.END_OF_MSRMN_PRD,
CASE WHEN LDW IS NULL AND ARTW IS NULL THEN START_DATE ELSE LDW END START_DATE,
CASE WHEN LDW IS NULL AND ARTW IS NULL THEN STOP_DATE ELSE 
                                                            CASE WHEN STOP_DATE < ARTW THEN STOP_DATE    
                                                            ELSE DECODE(ARTW, '9999-12-31', c.END_OF_MSRMN_PRD, ARTW) END END STOP_DATE,
a.LDW,
a.ARTW,
a.claim_injury_date,
a.CLAIM_ENTRY_DATE,
a.CLM_TYP_CD,
a.CLM_TYP_NM,
a.NOI_CTG_TYP_CD,
a.NOI_CTG_TYP_NM,
a.CLM_CLMT_LST_WK_DT,
a.PRSN_DTH_DTM,
a.STT_TYP_CD,
a.STT_TYP_NM,
a.STS_TYP_CD,
a.STS_TYP_NM,
a.TRANS_RSN_TYP_CD,
a.TRANS_RSN_TYP_NM,
a.PLCY_NO, 
a.CUST_ID_ACCT_HLDR, 
a.PLCY_AGRE_ID, 
a.EOC_PLCY_AGRE_ID, 
a.EOC_CUST_ID_ACCT_HLDR, 
a.EOC_PLCY_NO, 
a.EOC_PLCY_TYPE_CODE, 
a.EOC_PLCY_TYPE_UPRCS_CODE, 
a.EOC_EMPLR_LEGAL_NAME, 
a.EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EOC_EMPLR_PHYS_ADRS_POST_CODE
FROM RTW_TEMP_LT_CLAIMS_1 a
left join (SELECT YEAR_TYP, MAX(CRNT_YEAR_ENDNG_DATE) END_OF_MSRMN_PRD FROM RTW_TEMP_2 GROUP BY 1) c on a.year_typ = c.year_typ
)x
where datediff('d', start_date, stop_date) > 1;

/* Creating a row for all the EPM years by joining to RTW_TEMP_2 based on the year type*/
CREATE TEMPORARY TABLE RTW_TEMP_LT_CLAIMS_3  as
SELECT
DISTINCT
CLM_AGRE_ID, 
CLM_NO, 
CLAIMANT_FULL_NAME, 
A.YEAR_TYP, 
B.YEAR_YYYY_NO,
B.CRNT_YEAR_BGNG_DATE,
B.CRNT_YEAR_ENDNG_DATE,
claim_injury_date,
CLAIM_ENTRY_DATE,
CLM_TYP_CD,
CLM_TYP_NM,
NOI_CTG_TYP_CD,
NOI_CTG_TYP_NM,
CLM_CLMT_LST_WK_DT,
PRSN_DTH_DTM,
STT_TYP_CD,
STT_TYP_NM,
STS_TYP_CD,
STS_TYP_NM,
TRANS_RSN_TYP_CD,
TRANS_RSN_TYP_NM,
PLCY_NO, 
CUST_ID_ACCT_HLDR, 
PLCY_AGRE_ID, 
EOC_PLCY_AGRE_ID, 
EOC_CUST_ID_ACCT_HLDR, 
EOC_PLCY_NO, 
EOC_PLCY_TYPE_CODE, 
EOC_PLCY_TYPE_UPRCS_CODE, 
EOC_EMPLR_LEGAL_NAME, 
EOC_EMPLR_PHYS_ADRS_LINE1, 
EOC_EMPLR_PHYS_ADRS_LINE2, 
EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
EOC_EMPLR_PHYS_ADRS_POST_CODE
from RTW_TEMP_LT_CLAIMS_2 A
LEFT JOIN RTW_TEMP_2 B ON A.YEAR_TYP = B.YEAR_TYP
;

/*Calculation days absent using date dim*/
CREATE TEMPORARY TABLE RTW_TEMP_LT_CLAIMS  as
SELECT 
A.CLM_AGRE_ID, 
A.CLM_NO, 
A.CLAIMANT_FULL_NAME, 
A.YEAR_TYP, 
A.YEAR_YYYY_NO,
A.CRNT_YEAR_BGNG_DATE,
A.CRNT_YEAR_ENDNG_DATE,
NVL(B.DAYS_ABSENT, 0) DAYS_ABSENT,
case when date(a.CLAIM_ENTRY_DATE) between A.CRNT_YEAR_BGNG_DATE and A.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
A.claim_injury_date,
A.CLAIM_ENTRY_DATE,
A.CLM_TYP_CD,
A.CLM_TYP_NM,
A.NOI_CTG_TYP_CD,
A.NOI_CTG_TYP_NM,
A.CLM_CLMT_LST_WK_DT,
A.PRSN_DTH_DTM,
A.STT_TYP_CD,
A.STT_TYP_NM,
A.STS_TYP_CD,
A.STS_TYP_NM,
A.TRANS_RSN_TYP_CD,
A.TRANS_RSN_TYP_NM,
A.PLCY_NO, 
A.CUST_ID_ACCT_HLDR, 
A.PLCY_AGRE_ID, 
A.EOC_PLCY_AGRE_ID, 
A.EOC_CUST_ID_ACCT_HLDR, 
A.EOC_PLCY_NO, 
A.EOC_PLCY_TYPE_CODE, 
A.EOC_PLCY_TYPE_UPRCS_CODE, 
A.EOC_EMPLR_LEGAL_NAME, 
A.EOC_EMPLR_PHYS_ADRS_LINE1, 
A.EOC_EMPLR_PHYS_ADRS_LINE2, 
A.EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
A.EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
A.EOC_EMPLR_PHYS_ADRS_POST_CODE
FROM RTW_TEMP_LT_CLAIMS_3 A
LEFT JOIN 
(
SELECT 
CLM_AGRE_ID, 
B.YEAR_YYYY_NO, b.CRNT_YEAR_BGNG_DATE, b.CRNT_YEAR_ENDNG_DATE, count(distinct b.actual_dt) DAYS_ABSENT, 'C' YEAR_TYP 
FROM RTW_TEMP_LT_CLAIMS_2 A
JOIN DW_REPORT.DATE_DIM B ON B.ACTUAL_DT BETWEEN A.START_DATE AND A.STOP_DATE
GROUP BY 
CLM_AGRE_ID, 
B.YEAR_YYYY_NO, b.CRNT_YEAR_BGNG_DATE, b.CRNT_YEAR_ENDNG_DATE
UNION
SELECT 
CLM_AGRE_ID,  
B.FISC_YYYY_NO, b.FSCL_YEAR_BGNG_DATE, b.FSCL_YEAR_ENDNG_DATE, count(distinct b.actual_dt) DAYS_ABSENT, 'F' YEAR_TYP
FROM RTW_TEMP_LT_CLAIMS_2 A
JOIN DW_REPORT.DATE_DIM B ON B.ACTUAL_DT BETWEEN A.START_DATE AND A.STOP_DATE
GROUP BY 
CLM_AGRE_ID,  
B.FISC_YYYY_NO, b.FSCL_YEAR_BGNG_DATE, b.FSCL_YEAR_ENDNG_DATE
) B ON A.CLM_AGRE_ID = B.CLM_AGRE_ID AND A.YEAR_YYYY_NO = B.YEAR_YYYY_NO AND A.YEAR_TYP = B.YEAR_TYP
;

/* Unioning all the claims from above steps*/
CREATE TEMPORARY TABLE RTW_TEMP_CLAIMS  AS
SELECT * FROM RTW_TEMP_DEATH_CLAIMS
UNION
SELECT * FROM RTW_TEMP_MEDICAL_ONLY
UNION
SELECT * FROM RTW_TEMP_LT_EXCEPTION_1
UNION
SELECT * FROM RTW_TEMP_LT_EXCEPTION_2
UNION
SELECT * FROM RTW_TEMP_LT_CLAIMS
;

/*Assigning days absent = 0 for all the remaining orphan claims*/
CREATE TEMPORARY TABLE ORPHAN_CLAIMS  AS
SELECT 
A.CLM_AGRE_ID, 
A.CLM_NO, 
A.CLAIMANT_FULL_NAME, 
A.YEAR_TYP, 
B.YEAR_YYYY_NO,
B.CRNT_YEAR_BGNG_DATE,
B.CRNT_YEAR_ENDNG_DATE,
0 DAYS_ABSENT,
case when date(a.CLAIM_ENTRY_DATE) between B.CRNT_YEAR_BGNG_DATE and B.CRNT_YEAR_ENDNG_DATE then 1 else 0 end CLAIMS,
A.claim_injury_date,
A.CLAIM_ENTRY_DATE,
A.CLM_TYP_CD,
A.CLM_TYP_NM,
A.NOI_CTG_TYP_CD,
A.NOI_CTG_TYP_NM,
A.CLM_CLMT_LST_WK_DT,
A.PRSN_DTH_DTM,
A.STT_TYP_CD,
A.STT_TYP_NM,
A.STS_TYP_CD,
A.STS_TYP_NM,
A.TRANS_RSN_TYP_CD,
A.TRANS_RSN_TYP_NM,
A.PLCY_NO, 
a.INS_PARTICIPANT CUST_ID_ACCT_HLDR, 
A.PLCY_AGRE_ID, 
A.EOC_PLCY_AGRE_ID, 
A.EOC_CUST_ID_ACCT_HLDR, 
A.EOC_PLCY_NO, 
a.CRNT_PLCY_TYPE_CODE EOC_PLCY_TYPE_CODE, 
a.CRNT_PLCY_TYPE_UPRCS_CODE EOC_PLCY_TYPE_UPRCS_CODE, 
a.EMPLR_LEGAL_NAME EOC_EMPLR_LEGAL_NAME, 
a.EMPLR_PHYS_ADRS_LINE1 EOC_EMPLR_PHYS_ADRS_LINE1, 
a.EMPLR_PHYS_ADRS_LINE2 EOC_EMPLR_PHYS_ADRS_LINE2, 
a.EMPLR_PHYS_ADRS_CITY_NAME EOC_EMPLR_PHYS_ADRS_CITY_NAME, 
a.EMPLR_PHYS_ADRS_STATE_NAME EOC_EMPLR_PHYS_ADRS_STATE_NAME, 
a.EMPLR_PHYS_ADRS_POST_CODE EOC_EMPLR_PHYS_ADRS_POST_CODE
FROM RTW_TEMP_A1 A 
LEFT JOIN RTW_TEMP_2 B ON A.YEAR_TYP = B.YEAR_TYP
WHERE NOT EXISTS (SELECT CLM_AGRE_ID FROM RTW_TEMP_CLAIMS B WHERE A.CLM_AGRE_ID = B.CLM_AGRE_ID)
;

/*All Claims*/
CREATE TEMPORARY TABLE ALL_CLAIMS  AS
SELECT * FROM RTW_TEMP_CLAIMS
UNION
SELECT * FROM ORPHAN_CLAIMS
;

/*Calculating payroll for all the end of chain policies by year and policy type*/
CREATE TEMPORARY TABLE EOC_PAYROLL  as
select * from
(SELECT 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
EFF_YYYY PAYROLL_YEAR,
sum(WC_COV_PREM_BS_VAL) PAYROLL_AMOUNT
FROM (
SELECT 
p.AGRE_ID,
PP.PLCY_NO,
p.CUST_ID_ACCT_HLDR,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT,
WCP.WC_COV_PREM_BS_VAL,
plcytyp.CTL_ELEM_SUB_TYP_CD,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd.YEAR_YYYY_NO else dd.FISC_YYYY_NO END EFF_YYYY,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd1.YEAR_YYYY_NO else dd1.FISC_YYYY_NO END END_YYYY
FROM pcmp.POLICY P
join PCMP.POLICY_PERIOD PP on p.AGRE_ID = pp.AGRE_ID and pp.VOID_IND = 'n'
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON PP.PLCY_PRD_ID=PCE.PLCY_PRD_ID AND PCE.CTL_ELEM_TYP_CD = 'rpt_freq'
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE C ON C.CTL_ELEM_SUB_TYP_ID=PCE.CTL_ELEM_SUB_TYP_ID AND C.CTL_ELEM_SUB_TYP_NM != 'Payment Plan'
INNER JOIN PCMP.PREMIUM_PERIOD PR ON PP.PLCY_PRD_ID=PR.PLCY_PRD_ID AND PR.PREM_TYP_CD='r' AND PR.VOID_IND='n'
LEFT JOIN PCMP.WC_COVERAGE_PREMIUM WCP ON pr.PREM_PRD_ID = wcp.PREM_PRD_ID AND WCP.WC_COV_PREM_VOID_IND = 'n'
join (
        select  pp1.AGRE_ID, pp1.PLCY_NO, pp1.PLCY_PRD_ID, cest.CTL_ELEM_SUB_TYP_CD, cest.CTL_ELEM_SUB_TYP_NM
        from pcmp.POLICY_PERIOD pp1 
        join pcmp.AGREEMENT a1 on pp1.AGRE_ID = a1.AGRE_ID and a1.AGRE_TYP_CD = 'plcy'
        join pcmp.POLICY_CONTROL_ELEMENT pce on pp1.PLCY_PRD_ID = pce.PLCY_PRD_ID and pce.CTL_ELEM_TYP_CD = 'plcy_typ' and pce.VOID_IND = 'n'
        join pcmp.CONTROL_ELEMENT_SUB_TYPE cest on pce.CTL_ELEM_SUB_TYP_ID = cest.CTL_ELEM_SUB_TYP_ID and cest.CTL_ELEM_SUB_TYP_CD in ('pes', 'pec', 'bl', 'mif', 'pa')
        where pp1.VOID_IND = 'n'
     ) plcytyp on p.AGRE_ID = plcytyp.AGRE_ID and PP.PLCY_NO = plcytyp.PLCY_NO and PP.PLCY_PRD_ID = plcytyp.PLCY_PRD_ID
join dw_report.DATE_DIM dd on pp.PLCY_PRD_EFF_DT = dd.ACTUAL_DT
join dw_report.DATE_DIM dd1 on DATEADD(DAY,-1,pp.PLCY_PRD_END_DT) = dd1.ACTUAL_DT
where p.QUOT_NO is null and p.VOID_IND = 'n' and p.CUST_ID_ACCT_HLDR = wcp.CUST_ID_COV 
order by PP.PLCY_NO,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT
) X
WHERE 
EFF_YYYY = END_YYYY
group by 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
PAYROLL_YEAR
order by 
PLCY_NO,
PAYROLL_YEAR
) retrospective
union
select * from
(SELECT 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
EFF_YYYY PAYROLL_YEAR,
sum(WC_COV_PREM_BS_VAL) PAYROLL_AMOUNT
FROM (
SELECT 
p.AGRE_ID,
PP.PLCY_NO,
p.CUST_ID_ACCT_HLDR,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT,
WCP.WC_COV_PREM_BS_VAL,
plcytyp.CTL_ELEM_SUB_TYP_CD,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd.YEAR_YYYY_NO else dd.FISC_YYYY_NO END EFF_YYYY,
case when plcytyp.CTL_ELEM_SUB_TYP_CD = 'pec' then dd1.YEAR_YYYY_NO else dd1.FISC_YYYY_NO END END_YYYY
FROM pcmp.POLICY P
join PCMP.POLICY_PERIOD PP on p.AGRE_ID = pp.AGRE_ID and pp.VOID_IND = 'n'
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON PP.PLCY_PRD_ID=PCE.PLCY_PRD_ID AND PCE.CTL_ELEM_TYP_CD = 'rpt_freq'
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE C ON C.CTL_ELEM_SUB_TYP_ID=PCE.CTL_ELEM_SUB_TYP_ID AND C.CTL_ELEM_SUB_TYP_NM = 'Payment Plan'
INNER JOIN PCMP.PREMIUM_PERIOD PR ON PP.PLCY_PRD_ID=PR.PLCY_PRD_ID AND PR.PREM_TYP_CD='a' AND PR.VOID_IND='n'
INNER JOIN PCMP.POLICY_PERIOD_AUDIT_DETAIL PAD ON PP.PLCY_PRD_ID=PAD.PLCY_PRD_ID AND PAD.PLCY_AUDT_TYP_CD in ('tu', 'fld') AND PAD.VOID_IND='n'
INNER JOIN PCMP.POLICY_PERIOD_AUDIT_STATUS PPAS on PAD.PLCY_PRD_AUDT_DTL_ID = PPAS.PLCY_PRD_AUDT_DTL_ID AND PPAS.VOID_IND = 'n' and PPAS.PLCY_AUDT_STS_TYP_CD = 'comp'
LEFT JOIN PCMP.WC_COVERAGE_PREMIUM WCP ON PR.PREM_PRD_ID=WCP.PREM_PRD_ID AND WCP.WC_COV_PREM_VOID_IND = 'n' 
join (
        select  pp1.AGRE_ID, pp1.PLCY_NO, pp1.PLCY_PRD_ID, cest.CTL_ELEM_SUB_TYP_CD, cest.CTL_ELEM_SUB_TYP_NM
        from pcmp.POLICY_PERIOD pp1 
        join pcmp.AGREEMENT a1 on pp1.AGRE_ID = a1.AGRE_ID and a1.AGRE_TYP_CD = 'plcy'
        join pcmp.POLICY_CONTROL_ELEMENT pce on pp1.PLCY_PRD_ID = pce.PLCY_PRD_ID and pce.CTL_ELEM_TYP_CD = 'plcy_typ' and pce.VOID_IND = 'n'
        join pcmp.CONTROL_ELEMENT_SUB_TYPE cest on pce.CTL_ELEM_SUB_TYP_ID = cest.CTL_ELEM_SUB_TYP_ID and cest.CTL_ELEM_SUB_TYP_CD in ('pes', 'pec', 'bl', 'mif', 'pa')
        where pp1.VOID_IND = 'n'
     ) plcytyp on p.AGRE_ID = plcytyp.AGRE_ID and PP.PLCY_NO = plcytyp.PLCY_NO and PP.PLCY_PRD_ID = plcytyp.PLCY_PRD_ID
join dw_report.DATE_DIM dd on pp.PLCY_PRD_EFF_DT = dd.ACTUAL_DT
join dw_report.DATE_DIM dd1 on DATEADD(DAY,-1,pp.PLCY_PRD_END_DT) = dd1.ACTUAL_DT
where p.QUOT_NO is null and p.VOID_IND = 'n' and p.CUST_ID_ACCT_HLDR = wcp.CUST_ID_COV 
order by PP.PLCY_NO,
PP.PLCY_PRD_ID,
PP.PLCY_PRD_EFF_DT,
PP.PLCY_PRD_END_DT
) X
WHERE 
EFF_YYYY = END_YYYY
group by 
AGRE_ID,
PLCY_NO,
CUST_ID_ACCT_HLDR,
CTL_ELEM_SUB_TYP_CD,
PAYROLL_YEAR
order by 
PLCY_NO,
PAYROLL_YEAR
) prospective
;

CREATE TEMPORARY TABLE DW_EPM_CLAIM_SUMMARY  AS
select 
a.CLM_AGRE_ID, 
a.CLM_NO,
a.CLAIMANT_FULL_NAME,
a.YEAR_TYP YEAR_TYPE_IND,
CASE 
     WHEN a.YEAR_TYP = 'C' THEN 'CALENDER'
     WHEN a.YEAR_TYP = 'F' THEN 'FISCAL'
END YEAR_TYPE_NAME,
a.YEAR_YYYY_NO EPM_YEAR,
a.CRNT_YEAR_BGNG_DATE EPM_YEAR_BGNG_DATE, 
a.CRNT_YEAR_ENDNG_DATE EPM_YEAR_ENDNG_DATE,
a.DAYS_ABSENT DAYS_ABSNT_TTL_CNT,
a.CLAIM_ENTRY_DATE,
a.CLAIMS CLM_ENTRD_IND, 
a.PLCY_AGRE_ID,
a.CUST_ID_ACCT_HLDR,
a.PLCY_NO,
a.EOC_PLCY_AGRE_ID,
a.EOC_CUST_ID_ACCT_HLDR,
a.EOC_PLCY_NO,
a.EOC_PLCY_TYPE_CODE,
a.EOC_PLCY_TYPE_UPRCS_CODE,
a.EOC_EMPLR_LEGAL_NAME,
a.EOC_EMPLR_PHYS_ADRS_LINE1,
a.EOC_EMPLR_PHYS_ADRS_LINE2,
a.EOC_EMPLR_PHYS_ADRS_CITY_NAME,
a.EOC_EMPLR_PHYS_ADRS_STATE_NAME,
a.EOC_EMPLR_PHYS_ADRS_POST_CODE,
nvl(b.payroll_amount, 0) EOC_PYRL_AMT,
CURRENT_DATE DW_CREATE_DTM,
CURRENT_DATE DW_UPDATE_DTM,
CLAIM_INJURY_DATE /*Added this column Version # 3  Release*/
from ALL_CLAIMS a
left join EOC_PAYROLL b on a.EOC_PLCY_AGRE_ID = b.AGRE_ID and a.EOC_CUST_ID_ACCT_HLDR = b.CUST_ID_ACCT_HLDR 
                       and a.EOC_PLCY_NO = b.plcy_no and a.year_yyyy_no = b.payroll_year
;

CREATE TEMPORARY TABLE DW_EPM_CLAIM_SUMMARY_1  AS
select
CLM_AGRE_ID,
CLM_NO,
CLAIMANT_FULL_NAME,
YEAR_TYPE_IND,
YEAR_TYPE_NAME,
EPM_YEAR,
EPM_YEAR_BGNG_DATE,
EPM_YEAR_ENDNG_DATE,
case when EPM_YEAR_BGNG_DATE > YR_BGN_DT then 0 else DAYS_ABSNT_TTL_CNT end DAYS_ABSNT_TTL_CNT,
CLAIM_ENTRY_DATE,
CLM_ENTRD_IND,
PLCY_AGRE_ID,
CUST_ID_ACCT_HLDR,
PLCY_NO,
EOC_PLCY_AGRE_ID,
EOC_CUST_ID_ACCT_HLDR,
EOC_PLCY_NO,
EOC_PLCY_TYPE_CODE,
EOC_PLCY_TYPE_UPRCS_CODE,
EOC_EMPLR_LEGAL_NAME,
EOC_EMPLR_PHYS_ADRS_LINE1,
EOC_EMPLR_PHYS_ADRS_LINE2,
EOC_EMPLR_PHYS_ADRS_CITY_NAME,
EOC_EMPLR_PHYS_ADRS_STATE_NAME,
EOC_EMPLR_PHYS_ADRS_POST_CODE,
EOC_PYRL_AMT,
DW_CREATE_DTM,
DW_UPDATE_DTM
from 
(
select *,
case when a.YEAR_TYPE_IND = 'C' then ADD_MONTHS(b.CRNT_YEAR_BGNG_DATE, 48)  else  ADD_MONTHS(b.FSCL_YEAR_BGNG_DATE, 48) end YR_BGN_DT,
case when a.YEAR_TYPE_IND = 'C' then ADD_MONTHS(b.CRNT_YEAR_ENDNG_DATE, 48)  else  ADD_MONTHS(b.FSCL_YEAR_ENDNG_DATE, 48) end YR_END_DT
from DW_EPM_CLAIM_SUMMARY a
join dw_report.DATE_DIM b on a.CLAIM_INJURY_DATE = b.ACTUAL_DT /* Added this column Version # 3  Release, Replaced “a.CLAIM_ENTRY_DATE” with “a.CLAIM_INJURY_DATE”.*/
) abc;

truncate table DW_REPORT.DW_EPM_CLAIM_SUMMARY;

/* STEP 7: 
   Inserting data into table
*/

INSERT
/*+DIRECT*/
INTO
DW_REPORT.DW_EPM_CLAIM_SUMMARY
(CLM_AGRE_ID, CLM_NO, CLAIMANT_FULL_NAME, YEAR_TYPE_IND, YEAR_TYPE_NAME, EPM_YEAR, EPM_YEAR_BGNG_DATE, EPM_YEAR_ENDNG_DATE, DAYS_ABSNT_TTL_CNT, CLAIM_ENTRY_DATE, CLM_ENTRD_IND, PLCY_AGRE_ID, CUST_ID_ACCT_HLDR, PLCY_NO, EOC_PLCY_AGRE_ID, EOC_CUST_ID_ACCT_HLDR, EOC_PLCY_NO, EOC_PLCY_TYPE_CODE, EOC_PLCY_TYPE_UPRCS_CODE, EOC_EMPLR_LEGAL_NAME, EOC_EMPLR_PHYS_ADRS_LINE1, EOC_EMPLR_PHYS_ADRS_LINE2, EOC_EMPLR_PHYS_ADRS_CITY_NAME, EOC_EMPLR_PHYS_ADRS_STATE_NAME, EOC_EMPLR_PHYS_ADRS_POST_CODE, EOC_PYRL_AMT, DW_CREATE_DTM, DW_UPDATE_DTM)
select * from DW_EPM_CLAIM_SUMMARY_1;


COMMIT;
