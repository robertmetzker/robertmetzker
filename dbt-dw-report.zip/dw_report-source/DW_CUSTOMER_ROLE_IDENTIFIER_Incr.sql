--\set ON_ERROR_STOP on
--TRUNCATE AND INSERT ROWS
TRUNCATE TABLE DW_REPORT.DW_CUSTOMER_ROLE_IDENTIFIER;
INSERT
    /*+DIRECT*/
    INTO
        DW_REPORT.DW_CUSTOMER_ROLE_IDENTIFIER(
            CUST_ROLE_ID,
            CUST_ID,
            ID_TYP_CD,
            CUST_ROLE_TYP_CD,
            LOB_TYP_CD,
            STT_ID,
            LIC_TYP_CD,
            CUST_ROLE_ID_EFF_DT,
            CUST_ROLE_ID_END_DT,
            CUST_ROLE_ID_VAL_STR,
            VOID_IND,
            DW_CREATE_DTTM,
            DW_UPDATE_DTTM,
			AUDIT_USER_ID_CREA,
			AUDIT_USER_CREA_DTM,
			AUDIT_USER_ID_UPDT,
			AUDIT_USER_UPDT_DTM
        )(
            SELECT
                CRI.CUST_ROLE_ID_ID AS CUST_ROLE_ID,
                CRI.CUST_ID,
                CASE
                    WHEN CRI.ID_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CRI.ID_TYP_CD
                END ID_TYP_CD,
                CASE
                    WHEN CRI.CUST_ROLE_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CRI.CUST_ROLE_TYP_CD
                END CUST_ROLE_TYP_CD,
                CASE
                    WHEN CRI.LOB_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CRI.LOB_TYP_CD
                END LOB_TYP_CD,
                CRI.STT_ID,
                CASE
                    WHEN CRI.LIC_TYP_CD IS NULL
                    THEN '-1'
                    ELSE CRI.LIC_TYP_CD
                END LIC_TYP_CD,
                CRI.CUST_ROLE_ID_EFF_DT,
                CRI.CUST_ROLE_ID_END_DT,
                CRI.CUST_ROLE_ID_VAL_STR,
                CRI.VOID_IND,
                CURRENT_DATE AS DW_CREATE_DTTM,
                CURRENT_DATE AS DW_UPDATE_DTTM,
				CRI.AUDIT_USER_ID_CREA,
				CRI.AUDIT_USER_CREA_DTM,
				CRI.AUDIT_USER_ID_UPDT,
				CRI.AUDIT_USER_UPDT_DTM
            FROM
                PCMP.CUSTOMER_ROLE_IDENTIFIER CRI
        );COMMIT;