{{ config(materialized='table', transient=false ) }}

-- SRC LAYER
WITH
N		as ( select * from {{ source('PCMP','NOTE') }} ),
na		as ( select * from {{ source('PCMP','NOTE_APPLICATION_DETAIL_LEVEL') }} ),
adl		as ( select * from {{ source('PCMP','APPLICATION_DETAIL_LEVEL') }} ),
MSTR	as ( select * from {{ source('DW_REPORT','DW_REPORT_MSTR_TYPCODE_DIM') }} ),
pp		as ( select * from {{ source('PCMP','POLICY_PERIOD') }} ),
a		as ( select * from {{ source('PCMP','AGREEMENT') }} ),
NT		as ( select * from {{ source('PCMP','NOTE_TEXT') }} ),
NTP		as ( select * from {{ source('PCMP','NOTE_TYPE') }} ),
NCAT	as ( select * from {{ source('PCMP','NOTE_CALL_TYPE') }} ),
NCFT	as ( select * from {{ source('PCMP','NOTE_CALL_FROM_TYPE') }} ),


/*
use database RPD1;
WITH
N		AS ( select * from PCMP.NOTE),
na		AS ( select * from PCMP.NOTE_APPLICATION_DETAIL_LEVEL),
adl		AS ( select * from PCMP.APPLICATION_DETAIL_LEVEL),
MSTR	AS ( select * from DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM),
pp		AS ( select * from PCMP.POLICY_PERIOD),
a		AS ( select * from PCMP.AGREEMENT),
NT		AS ( select * from PCMP.NOTE_TEXT),
NTP		AS ( select * from PCMP.NOTE_TYPE),
NCAT	AS ( select * from PCMP.NOTE_CALL_TYPE),
NCFT	AS ( select * from PCMP.NOTE_CALL_FROM_TYPE),
*/

-- BUSINESS RULES/LOGIC
  /* Prod release Prod Release date 02/21/2017   */
  /* Prod release - vERSION #2  Prod Release date 06/26/2018
	        1. Remove filter for NOTE_TYP_CD, which will add Phone Calls into the table.
		2. Add fields to distinguish between Notes and Phone Calls. (NOTE_TYP_CD and NOTE_TYP_NM)
		3. Add fields specific for Phone calls. (NOTE_CALL_TYP_CD, NOTE_CALL_TYP_NM, NOTE_CALL_FR_TYP_CD, NOTE_CALL_FR_TYP_NM, NOTE_CLLR_PRSN_NM)
  */
    
  /* Source Tables 		: PCMP.NOTE
 				  PCMP.POLICY_PERIOD
				  PCMP.APPLICATION_DETAIL_LEVEL
				  PCMP.NOTE_CATEGORY_TYPE
				  PCMP.NOTE_TEXT
					PCMP.NOTE_TYPE
					PCMP.NOTE_CALL_TYPE
					PCMP.NOTE_CALL_FROM_TYPE

								 */
								
 
/* L1 Dependency 		: 	DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM */



--\set ON_ERROR_STOP on
NCT	AS
(	SELECT * 
	FROM MSTR 
	WHERE SRC_TBL_NAME = 'NOTE_CATEGORY_TYPE'
),

pp1 AS
(
	SELECT DISTINCT 
	pp.PLCY_PRD_ID, 
	pp.PLCY_NO, 
	pp.AGRE_ID, 
	pp.PLCY_PRD_EFF_DT, 
	pp.PLCY_PRD_END_DT 
	FROM pp
	INNER JOIN a ON pp.AGRE_ID = a.AGRE_ID AND a.AGRE_TYP_CD = 'plcy'
),

pp2 AS
(
	SELECT DISTINCT 
	pp.AGRE_ID, 
	pp.PLCY_NO 
	FROM pp
	INNER JOIN a ON pp.AGRE_ID = a.AGRE_ID AND a.AGRE_TYP_CD = 'plcy'
)


SELECT 
	N.NOTE_ID																					AS					NOTE_ID,
	coalesce(pp1.AGRE_ID, pp2.AGRE_ID) 															as 					PLCY_AGRE_ID, 
	coalesce(pp1.PLCY_NO, pp2.PLCY_NO) 															as 					PLCY_NO, 
	pp1.PLCY_PRD_ID 																			AS					PLCY_PRD_ID,
	DATE(pp1.PLCY_PRD_EFF_DT) 																	as 					PLCY_PRD_EFF_DATE, 
	DATE(pp1.PLCY_PRD_END_DT) 																	as 					PLCY_PRD_END_DATE,
	CASE WHEN N.APP_DTL_LVL_CD IS NULL THEN '-1' ELSE N.APP_DTL_LVL_CD END      				AS 					APP_DTL_LVL_CD,
	adl.APP_DTL_LVL_NM																			AS					APP_DTL_LVL_NM,
	CASE WHEN N.NOTE_CTG_TYP_CD IS NULL THEN '-1' ELSE N.NOTE_CTG_TYP_CD END      				AS 					NOTE_CTG_TYP_CD,
	NCT.SRC_CODE_TEXT 																			AS 					NOTE_CTG_TYP_NM,
	N.NOTE_SBJ_TEXT 																			AS					NOTE_SBJ_TEXT,	
	N.NOTE_HI_PRTY_IND																			AS					NOTE_HI_PRTY_IND,
	N.NOTE_NO_PRNT_IND 																			AS 					NOTE_NO_PRINT_IND,			
	N.NOTE_PUB_IND																				AS					NOTE_PUB_IND,
	N.NOTE_CNFDTL_IND																			AS					NOTE_CNFDTL_IND,
	N.NOTE_EDI_REF_NO																			AS					NOTE_EDI_REF_NO,
	NT.NOTE_TEXT_ID 																			AS					NOTE_TEXT_ID,
	NT.NOTE_TEXT_TEXT																			AS					NOTE_TEXT_TEXT,
	N.AUDIT_USER_ID_CREA 																		AS 					NOTE_AUDIT_USER_ID_CREA, 
	N.AUDIT_USER_CREA_DTM 																		AS 					NOTE_AUDIT_USER_CREA_DTM, 
	N.AUDIT_USER_ID_UPDT 																		AS 					NOTE_AUDIT_USER_ID_UPDT,
	N.AUDIT_USER_UPDT_DTM 																		AS 					NOTE_AUDIT_USER_UPDT_DTM,
	NT.AUDIT_USER_ID_CREA 																		AS 					TEXT_AUDIT_USER_ID_CREA, 
	NT.AUDIT_USER_CREA_DTM 																		AS 					TEXT_AUDIT_USER_CREA_DTM, 
	NT.AUDIT_USER_ID_UPDT																		AS 					TEXT_AUDIT_USER_ID_UPDT,
	NT.AUDIT_USER_UPDT_DTM 																		AS 					TEXT_AUDIT_USER_UPDT_DTM,
	CURRENT_DATE 																				AS 					DW_CREATE_DTM,
	CURRENT_DATE 																				AS 					DW_UDPATE_DTM,
	CASE WHEN N.NOTE_TYP_CD IS NULL THEN '-1' ELSE N.NOTE_TYP_CD END 							AS 					NOTE_TYP_CD,
	NTP.NOTE_TYP_NM 																			AS 					NOTE_TYP_NM,
	CASE WHEN N.NOTE_CALL_TYP_CD IS NULL THEN '-1' ELSE N.NOTE_CALL_TYP_CD END 					AS 					NOTE_CALL_TYP_CD,
	NCAT.NOTE_CALL_TYP_NM 																		AS 					NOTE_CALL_TYP_NM,
	CASE WHEN N.NOTE_CALL_FR_TYP_CD IS NULL THEN '-1' ELSE N.NOTE_CALL_FR_TYP_CD END 			AS 					NOTE_CALL_FR_TYP_CD,
	NCFT.NOTE_CALL_FR_TYP_NM 																	AS 					NOTE_CALL_FR_TYP_NM,
	N.NOTE_CLLR_PRSN_NM 																		AS 					NOTE_CLLR_PRSN_NM
FROM 				N
INNER JOIN  		na 		ON n.NOTE_ID 				= na.NOTE_ID
LEFT OUTER JOIN 	adl 	ON n.APP_DTL_LVL_CD 		= adl.APP_DTL_LVL_CD
LEFT OUTER JOIN 	NCT 	ON N.NOTE_CTG_TYP_CD 		= NCT.SRC_CODE
LEFT OUTER JOIN 	pp1 	ON na.PLCY_PRD_ID 			= pp1.PLCY_PRD_ID
LEFT OUTER JOIN 	pp2 	ON na.AGRE_ID_DRV 			= pp2.AGRE_ID
LEFT OUTER JOIN 	NT 		ON n.NOTE_ID 				= NT.NOTE_ID 				AND NT.NOTE_TEXT_NO = 1
LEFT OUTER JOIN 	NTP 	ON N.NOTE_TYP_CD 			= NTP.NOTE_TYP_CD 			AND NTP.NOTE_TYP_VOID_IND = 'n'
LEFT OUTER JOIN 	NCAT 	ON N.NOTE_CALL_TYP_CD 		= NCAT.NOTE_CALL_TYP_CD 	AND NCAT.NOTE_CALL_TYP_VOID_IND = 'n'
LEFT OUTER JOIN 	NCFT 	ON N.NOTE_CALL_FR_TYP_CD 	= NCFT.NOTE_CALL_FR_TYP_CD 	AND NCFT.NOTE_CALL_FR_TYP_VOID_IND ='n'
WHERE 
	n.APP_DTL_LVL_CD like 'Policy%' 
	AND n.NOTE_VOID_IND = 'n'
;		