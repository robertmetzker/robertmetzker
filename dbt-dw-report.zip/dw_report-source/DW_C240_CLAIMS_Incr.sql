
--\set ON_ERROR_STOP on
/* Step ONE - find C240 Claims (sequence of steps 1 through 4 is important)
  1.	Find all C240 tasks created the previous seven days (ending midnight Saturday) where the task status is NOT duplicate or processing error
		All claims found default to 'y' for C240_CLAIMS_FLAG; these are the PRIMARY C240 Claims*/
CREATE TEMPORARY TABLE TEMP_C240_A  AS 
select  DISTINCT 
       p.cust_id, c.agre_id, c.clm_no, 'y' AS C240_CLAIMS_FLAG, date(to_char(c.clm_occr_dtm,'YYYY-MM-DD HH:MM:SS')) clm_occr_dtm, date(to_char(t.audit_user_crea_dtm,'YYYY-MM-DD HH:MM:SS')) TASK_CREA_DTM 
from PCMP.TASK t, PCMP.task_category_app_cntx_xref x, PCMP.task_category_type cat, PCMP.claim c, PCMP.participation p, PCMP.claim_participation cp
         where
           t.task_ctg_app_cntx_xref_id=x.task_ctg_app_cntx_xref_id
         and x.task_ctg_typ_cd=cat.task_ctg_typ_cd
         and cat.task_ctg_typ_cd not in ('appdup', 'appproerr')  
         AND T.TASK_NM_DRV_UPCS_NM like  '%C240%'
         and t.task_cntx_id=c.agre_id
         and c.agre_id=p.agre_id
         and p.ptcp_typ_cd='clmt'
         and p.ptcp_id=cp.ptcp_id
         and cp.clm_ptcp_end_dt is null
         and c.clm_rel_snpsht_ind='n'
         and t.void_ind='n'
         and x.void_ind='n'
         and cat.void_ind='n'
         and cp.void_ind='n';
/* 2.	Exclude from this list any claimant having a claim with an LSS org unit assignment in effect when the task was created. */
CREATE TEMPORARY TABLE TEMP_C240_B  AS 
/* 123 lss with task create date between assignment dates */
SELECT T.cust_id, T.agre_id, T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.TASK_CREA_DTM, 
    ou.org_unt_nm, 
    date(to_char(A.AUDIT_USER_CREA_DTM,'YYYY-MM-DD HH:MM:SS')) AS ASSGN_USER_CREA_DTM, 
    date(to_char(A.AUDIT_USER_UPDT_DTM,'YYYY-MM-DD HH:MM:SS')) AS ASSGN_USER_UPDT_DTM,
   (select CC.CLM_COV_OVRRD_TYP_CD 
    from  PCMP.PARTICIPATION P LEFT JOIN 
          PCMP.CLAIM_PARTICIPATION CP ON CP.PTCP_ID=P.PTCP_ID LEFT JOIN 
          PCMP.CLAIM_PARTICIPATION_INSRD CPI ON CPI.CLM_PTCP_ID=CP.CLM_PTCP_ID LEFT JOIN 
          PCMP.CLAIM_COVERAGE CC ON CC.CLM_PTCP_INSRD_ID=CPI.CLM_PTCP_INSRD_ID 
    where P.AGRE_ID=T.AGRE_ID and 
          cp.clm_ptcp_pri_ind='y' AND 
          CC.VOID_IND='n' and 
          cpi.void_ind='n' and 
          cp.void_ind='n' and 
          p.ptcp_typ_cd='insrd') CLAIM_COVERAGE_OVERRIDE
FROM    TEMP_C240_A T
left join 
    PCMP.ASSIGNMENT A on 
        a.asgn_cntx_id=t.agre_id and 
        a.AUDIT_USER_CREA_DTM <= T.TASK_CREA_DTM and 
         date(to_char(nvl(a.AUDIT_USER_UPDT_DTM, CURRENT_DATE+1),'YYYY-MM-DD HH:MM:SS')) >=    date(to_char(T.TASK_CREA_DTM,'YYYY-MM-DD HH:MM:SS')) and 
   			(a.AUDIT_USER_UPDT_DTM IS NULL OR date(to_char(a.AUDIT_USER_UPDT_DTM,'YYYY-MM-DD HH:MM:SS')) >=   date(to_char(T.TASK_CREA_DTM,'YYYY-MM-DD HH:MM:SS'))) and
            a.app_cntx_typ_cd='claim' and 
        a.asgn_pri_ownr_ind='y' 
left join 
    PCMP.ORGANIZATIONAL_UNIT OU on 
       ou.org_unt_id=a.org_unt_id and 
       ou.org_unt_nm LIKE '%LSS%' 
WHERE   (ou.org_unt_nm IS NULL) ;
/* 3.	Exclude from this list any claim where 
		a.	Policy  type = SI, AND
		b.	Claim-level Coverage Override NOT = ' SI Default - BWC Pays ', AND
		c.	Policy Number NOT = 20000999
add description of meaning for policy 20000999 */
CREATE TEMPORARY TABLE TEMP_C240_C   AS 
SELECT DISTINCT 
       T.cust_id, T.agre_id, T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.TASK_CREA_DTM, 
	   T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM, T.CLAIM_COVERAGE_OVERRIDE,
       CS.CS_PLCY_NO POLICY_NO, CS.PLCY_PRD_ID, cest.ctl_elem_sub_typ_cd  POLICY_TYPE
FROM TEMP_C240_B T
LEFT JOIN PCMP.CLAIM_SUMMARY CS ON T.CLM_NO=CS.CS_CLM_NO
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON PCE.PLCY_PRD_ID=CS.PLCY_PRD_ID
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE CEST ON CEST.CTL_ELEM_SUB_TYP_ID=PCE.CTL_ELEM_SUB_TYP_ID
WHERE CS.CS_PLCY_NO IS NOT NULL 
AND PCE.CTL_ELEM_TYP_CD='plcy_typ'
AND (CEST.CTL_ELEM_SUB_TYP_CD <> 'si' OR T.CLAIM_COVERAGE_OVERRIDE='sibwcpays' OR CS.CS_PLCY_NO = '20000999')
AND PCE.VOID_IND='n';
/* 4.	For each claimant remaining, isolate the claim with the latest Date of Occurrence */
CREATE TEMPORARY TABLE TEMP_C240_D_1   AS 
select 
SQ.cust_id, SQ.agre_id, SQ.clm_no, SQ.C240_CLAIMS_FLAG, SQ.clm_occr_dtm, SQ.TASK_CREA_DTM, 'y' PRIMARY_FLAG,
     SQ.org_unt_nm, SQ.ASSGN_USER_CREA_DTM, SQ.ASSGN_USER_UPDT_DTM, SQ.CLAIM_COVERAGE_OVERRIDE,
       SQ.POLICY_NO, SQ.PLCY_PRD_ID, SQ.POLICY_TYPE
from (
SELECT DISTINCT 
       T.cust_id, T.agre_id, T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.TASK_CREA_DTM, 'y' PRIMARY_FLAG,
     T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM, T.CLAIM_COVERAGE_OVERRIDE,
       T.POLICY_NO, T.PLCY_PRD_ID, T.POLICY_TYPE,
       ROW_number () over(partition by cust_id order by task_crea_dtm desc) as Rank_Task
FROM TEMP_C240_C T 
where  t.clm_occr_dtm = (select max(b1.clm_occr_dtm) from temp_c240_C b1 where b1.cust_id=t.cust_id)
) SQ where Rank_Task = 1;
CREATE TEMPORARY TABLE TEMP_C240_D   AS 
SELECT 
T.cust_id, T.agre_id, T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.TASK_CREA_DTM, 'y' PRIMARY_FLAG,
     T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM, T.CLAIM_COVERAGE_OVERRIDE,
       T.POLICY_NO, T.PLCY_PRD_ID, T.POLICY_TYPE
FROM TEMP_C240_D_1 T
UNION
SELECT DISTINCT 
       T.cust_id, T.agre_id, T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.TASK_CREA_DTM, 'n' PRIMARY_FLAG,
     T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM, T.CLAIM_COVERAGE_OVERRIDE,
       T.POLICY_NO, T.PLCY_PRD_ID, T.POLICY_TYPE
FROM TEMP_C240_C T 
where 
 NOT EXISTS ( SELECT 1 FROM TEMP_C240_D_1 D1 WHERE D1.CUST_ID = T.CUST_ID AND D1.AGRE_ID = T.AGRE_ID);
/*Step TWO - find Claims (sequence of steps 6 through 9 is NOT important; e.g., step 9 could be combined in the same sub-query with step 5)
  5.	Customer ID = C240 Customer ID, Claim Number NOT = C240 Claim Number
		All claims found default to 'n' for C240_CLAIMS_FLAG; these are the ASSOCIATED C240 Claims */
CREATE TEMPORARY TABLE TEMP_C240_AN   AS 
select t.cust_id, t.POLICY_NO as C240_POLICY_NO, c.agre_id,  c.clm_no, 'n' AS C240_CLAIMS_FLAG, c.clm_occr_dtm, 
T.task_crea_dtm, 'n' PRIMARY_FLAG, T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM
from TEMP_C240_D T, PCMP.participation p, PCMP.claim c
WHERE  
T.cust_id=p.cust_id
and p.ptcp_typ_cd='clmt'
and p.agre_id=c.agre_id/*and T.clm_no<>c.clm_no */
and NOT EXISTS ( SELECT 1 FROM TEMP_C240_D D WHERE D.CUST_ID = P.CUST_ID AND D.AGRE_ID = C.AGRE_ID) 
and t.task_crea_dtm = (select max(tx.task_crea_dtm) from temp_c240_c tx where tx.cust_id=t.cust_id)
UNION
select t.cust_id, t.POLICY_NO as C240_POLICY_NO, c.agre_id,  c.clm_no, 'n' AS C240_CLAIMS_FLAG, c.clm_occr_dtm, 
T.task_crea_dtm, 'n' PRIMARY_FLAG, T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM
from TEMP_C240_D T, PCMP.participation p, PCMP.claim c
WHERE  
T.cust_id=p.cust_id
and p.ptcp_typ_cd='clmt'
and p.agre_id=c.agre_id /*and T.clm_no<>c.clm_no */
and NOT EXISTS ( SELECT 1 FROM TEMP_C240_D D WHERE D.CUST_ID = P.CUST_ID AND D.AGRE_ID = C.AGRE_ID) 
and ((t.task_crea_dtm < (select max(tx.task_crea_dtm) from temp_c240_c tx where tx.cust_id=t.cust_id)) OR (t.task_crea_dtm > (select max(tx.task_crea_dtm) from temp_c240_c tx where tx.cust_id=t.cust_id)))
order by 1;
/* retrieve for associated claims the components necessary to evaluate policy type (#6 of Step 2)  */
CREATE TEMPORARY TABLE TEMP_C240_BN   AS   
SELECT DISTINCT 
       T.cust_id, T.C240_POLICY_NO, T.agre_id,  T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.task_crea_dtm, t.PRIMARY_FLAG, 
	   T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM, 
( select CC.CLM_COV_OVRRD_TYP_CD from  
 PCMP.PARTICIPATION P 
LEFT JOIN PCMP.CLAIM_PARTICIPATION CP ON CP.PTCP_ID=P.PTCP_ID
LEFT JOIN PCMP.CLAIM_PARTICIPATION_INSRD CPI ON CPI.CLM_PTCP_ID=CP.CLM_PTCP_ID
LEFT JOIN PCMP.CLAIM_COVERAGE CC ON CC.CLM_PTCP_INSRD_ID=CPI.CLM_PTCP_INSRD_ID
where P.AGRE_ID=T.AGRE_ID
and cp.clm_ptcp_pri_ind='y'
AND CC.VOID_IND='n'
and cpi.void_ind='n'
and cp.void_ind='n'
and p.ptcp_typ_cd='insrd'
) CLAIM_COVERAGE_OVERRIDE,
CS.CS_PLCY_NO non_C240_POLICY_NO, CS.PLCY_PRD_ID, cest.ctl_elem_sub_typ_cd  POLICY_TYPE
FROM TEMP_C240_AN T
LEFT JOIN PCMP.CLAIM_SUMMARY CS ON T.CLM_NO=CS.CS_CLM_NO
INNER JOIN PCMP.POLICY_CONTROL_ELEMENT PCE ON PCE.PLCY_PRD_ID=CS.PLCY_PRD_ID
INNER JOIN PCMP.CONTROL_ELEMENT_SUB_TYPE CEST ON CEST.CTL_ELEM_SUB_TYP_ID=PCE.CTL_ELEM_SUB_TYP_ID
WHERE CS.CS_PLCY_NO IS NOT NULL
AND PCE.CTL_ELEM_TYP_CD='plcy_typ'
AND PCE.VOID_IND='n';
/*	6.	Exclude any associated claim where 
		a.	Statutory Date < system date, AND
		b.	Claim State NOT = 'Open'
	7.	Exclude any associated claim where
		a.	Policy  type = SI, AND
		b.	Claim-level Coverage Override NOT = ' SI Default - BWC Pays ', AND
		c.	C240 Claim's Policy Number NOT = 20000999
	8.	Exclude any claim with status & status reason combinations equivalent to "disallowed", "disallow/appeal", "dismissed", or "settled both".
	9.	Exclude combined claims. */
CREATE TEMPORARY TABLE TEMP_C240_CN   AS 
select T.cust_id, T.C240_POLICY_NO, T.agre_id,  T.clm_no, T.C240_CLAIMS_FLAG, T.clm_occr_dtm, T.task_crea_dtm, 
	   T.PRIMARY_FLAG,T.org_unt_nm, T.ASSGN_USER_CREA_DTM, T.ASSGN_USER_UPDT_DTM, 
       T.CLAIM_COVERAGE_OVERRIDE, T.non_C240_POLICY_NO, T.PLCY_PRD_ID, T.POLICY_TYPE
from TEMP_C240_BN T, pcmp.CLAIM_ADDITIONAL_DETAIL cad, pcmp.CLAIM_CLAIM_STATUS ccs
where cad.AGRE_ID=t.agre_id 
and ccs.AGRE_ID=t.agre_id
and (cad.CLM_STATU_LMT_DT > CURRENT_DATE OR ccs.CLM_STt_TYP_CD='opn')
and (t.policy_type <> 'si' OR t.claim_coverage_override = 'sibwcpays' OR t.C240_POLICY_NO='20000999')
and 
(ccs.clm_sts_typ_cd, ccs.clm_trans_rsn_typ_cd) not in
(('acpt','dup'),
('dny','ag_setlmnt'),
('dny','conv'),
('dny','dny'),
('dny','dup'),
('dny','reqpnd'),
('exproccr','dup'),
('pndcondbnft','ag_setlmnt'),
('pnd','dnyaplprd'),
('pndcov','dnyaplprd'),
('acpt','dsmssd'),
('dny','dsmssd'),
('exproccr','dsmssd'),
('acpt','setlboth'),
('exproccr','conv'),
('incompoccr','clmrec'),
('sbmt','clmrecweb'))
and not exists
(select 1 from PCMP.claim_alias_number can where can.agre_id=t.agre_id)
and not exists
(select 1 from PCMP.claim_alias_number can where can.clm_alias_no_no=t.clm_no);
/* do not use "select *"; spell out columns to ensure consistent data types and contents */
/* 10. Create a temp table with all identified c240 claims along with associated claims */


CREATE TEMPORARY TABLE C240_CLAIMS_TEMP_RPT1  AS
SELECT  T.agre_id,  
T.TASK_CREA_DTM,
T.PRIMARY_FLAG, 
T.cust_id, 
T.POLICY_NO,     
T.org_unt_nm,  
T.C240_CLAIMS_FLAG
FROM TEMP_C240_D T
UNION
SELECT TN.agre_id,
DATE(NULL) AS task_crea_dtm,
TN.PRIMARY_FLAG, 
TN.cust_id, 
TN.non_C240_POLICY_NO, 
TN.org_unt_nm, 
TN.C240_CLAIMS_FLAG
FROM TEMP_C240_CN TN;
/* 11. Per Reporting need a new indicator 'reporting_ind' is being created and following steps populates the indicator column for c240 claim rows
       First rpt2 temp table identifies the rows that needed to be marked as y for reporting and next temp table rpt3 populates all c240 rows*/  
CREATE TEMPORARY TABLE C240_CLAIMS_TEMP_RPT2  AS 
SELECT agre_id,
CUST_ID,
POLICY_NO,
ORG_UNT_NM, 
MIN(TASK_CREA_DTM) AS TASK_CREA_DTM,
'y' AS REPORTING_IND 
FROM C240_CLAIMS_TEMP_RPT1 C
JOIN (SELECT PRVS_WEEK_BGNG_DATE - 1 AS PRVS_WEEK_BGNG_DATE,
PRVS_WEEK_ENDNG_DATE - 1 AS PRVS_WEEK_ENDNG_DATE FROM DW_REPORT.DATE_DIM WHERE ACTUAL_DT = CURRENT_DATE
) D
ON C.TASK_CREA_DTM BETWEEN D.PRVS_WEEK_BGNG_DATE AND D.PRVS_WEEK_ENDNG_DATE
AND C240_CLAIMS_FLAG = 'y'
GROUP BY agre_id,CUST_ID,POLICY_NO,ORG_UNT_NM;
/* 12. populates the c240 rows with reporting indicator */
CREATE TEMPORARY TABLE C240_CLAIMS_TEMP_RPT3  AS 
SELECT A.AGRE_ID,
A.CUST_ID,
A.POLICY_NO,
A.ORG_UNT_NM, 
A.TASK_CREA_DTM,
A.C240_CLAIMS_FLAG,
A.PRIMARY_FLAG,
CASE WHEN B.AGRE_ID IS NULL AND C240_CLAIMS_FLAG = 'y' THEN 'n'  ELSE 'y' END AS REPORTING_IND
FROM C240_CLAIMS_TEMP_RPT1 A
LEFT OUTER JOIN C240_CLAIMS_TEMP_RPT2 B
ON A.CUST_ID = B.CUST_ID
AND A.AGRE_ID = B.AGRE_ID
AND A.POLICY_NO = B.POLICY_NO
AND COALESCE(A.ORG_UNT_NM,'-1') = COALESCE(B.ORG_UNT_NM,'-1')
AND A.TASK_CREA_DTM = B.TASK_CREA_DTM
WHERE C240_CLAIMS_FLAG = 'y';
/* 13. Per Reporting need a new indicator 'reporting_ind' is being created and following steps populates the indicator column for c240 claim rows*/  
CREATE TEMPORARY TABLE C240_CLAIMS_TEMP_RPT4  AS
SELECT agre_id, 
CUST_ID, 
POLICY_NO,
ORG_UNT_NM, 
TASK_CREA_DTM,
C240_CLAIMS_FLAG,
PRIMARY_FLAG,
'y' AS REPORTING_IND
FROM C240_CLAIMS_TEMP_RPT1 
WHERE C240_CLAIMS_FLAG = 'n'
AND CUST_ID  IN (SELECT CUST_ID FROM C240_CLAIMS_TEMP_RPT2) 
UNION 
SELECT agre_id, 
CUST_ID, 
POLICY_NO,
ORG_UNT_NM, 
TASK_CREA_DTM,
C240_CLAIMS_FLAG,
PRIMARY_FLAG, 
'n' AS REPORTING_IND
FROM C240_CLAIMS_TEMP_RPT1 
WHERE C240_CLAIMS_FLAG = 'n'
AND CUST_ID  NOT IN (SELECT CUST_ID FROM C240_CLAIMS_TEMP_RPT2) ;
/* TEMP TABLE */
CREATE TEMPORARY TABLE C240_CLAIMS_TEMP_RPT5  AS
SELECT agre_id AS CLM_AGRE_ID
,TASK_CREA_DTM AS TASK_CREATE_DT
,PRIMARY_FLAG
,CUST_ID
,POLICY_NO AS PLCY_NO
,ORG_UNT_NM
,C240_CLAIMS_FLAG
,REPORTING_IND
,CURRENT_DATE AS DW_CREATE_DTTM
,CURRENT_DATE AS DW_UPDATE_DTTM
FROM C240_CLAIMS_TEMP_RPT3
UNION 
SELECT agre_id AS CLM_AGRE_ID
,TASK_CREA_DTM AS TASK_CREATE_DT
,PRIMARY_FLAG
,CUST_ID
,POLICY_NO AS PLCY_NO
,ORG_UNT_NM
,C240_CLAIMS_FLAG
,REPORTING_IND
,CURRENT_DATE AS DW_CREATE_DTTM
,CURRENT_DATE AS DW_UPDATE_DTTM
FROM C240_CLAIMS_TEMP_RPT4;
/* 12. FINAL STEP: TRUNCATE AND LOAD THE TARGET TABLE */
TRUNCATE TABLE dw_report.DW_C240_CLAIMS;
INSERT  /*+DIRECT*/  INTO dw_report.DW_C240_CLAIMS
(CLM_AGRE_ID
,TASK_CREATE_DT
,PRIMARY_FLAG
,CUST_ID
,PLCY_NO
,ORG_UNT_NM
,C240_CLAIMS_FLAG
,REPORTING_IND
,DW_CREATE_DTTM
,DW_UPDATE_DTTM) 
SELECT 
RPT5.CLM_AGRE_ID
,RPT5.TASK_CREATE_DT
,RPT5.PRIMARY_FLAG
,RPT5.CUST_ID
,RPT5.PLCY_NO
,RPT5.ORG_UNT_NM
,RPT5.C240_CLAIMS_FLAG
,CASE WHEN RPT6.CUST_ID IS NULL THEN 'n' ELSE 'y' END AS REPORTING_IND
,DW_CREATE_DTTM
,DW_UPDATE_DTTM
FROM 
C240_CLAIMS_TEMP_RPT5 RPT5
	LEFT OUTER JOIN (SELECT DISTINCT CUST_ID FROM C240_CLAIMS_TEMP_RPT5
WHERE PRIMARY_FLAG = 'y' and reporting_ind = 'y') RPT6 ON RPT5.CUST_ID = RPT6.CUST_ID;COMMIT;