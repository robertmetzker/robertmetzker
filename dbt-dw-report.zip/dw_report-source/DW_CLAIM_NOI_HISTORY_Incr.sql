/* Version #  1		 	:  	(Prod Release date  ) */

/* Table Description 	: 	a) This table will store the Nature of Injury Category Type for each claim at any given point in its history. 
										There should be one row per claim at a given time, and only one current row per claim. Valid types are: Accident, Occupational Disease, or Death.

							b) PS has Nature of Injury Category and Nature of Injury Type. Per Arnold Haas, he is not interested in the history of the Nature of Injury Type, 
										which breaks the categories down further, since this was not done in legacy.

							c) This data is coming from two sources:
									1. PCMP.CLAIM_HISTORY - this table stores any history change to the claim, so we have to merge the concurrent history rows together 
											where the category type code values are the same. (For converted claims, the history effective date on the first row is always set to 
											the claim's entry date - AUDIT_USER_CREA_DTM - but there could've been previous unconverted history rows left in the frozen table).
									2. BWCFRZN.THFCLAT - this frozen table stores the history before PowerSuite go-live. During conversion, the current values at that time 
											were converted to PowerSuite values, so we only need to bring the rows that were not current at go-live.
			
							d) The merge of the two sources requires logic that will correct the dates on the history rows, so they don't overlap or create gaps. */


/*Data Merging Rules:
							1. Select all rows from BWCFRZN.THFCLAT that were NOT current at go-live. Replace legacy type values with PS code values. Join to PCMP.CLAIM to get the AGRE_ID.
										i.e. ACCIDENT = 'acc'; OCCUPATIONAL DISEASE = 'occ_dis'; DEATH = 'dth'
							2. Select all rows from PCMP.CLAIM_HISTORY. Use DATE() function on HIST_EFF_DTM and HIST_END_DTM to retrive only the date functions. Exclude rows where date(HIST_EFF_DTM) = date(HIST_END_DTM).
							3. UNION results from steps 1 and 2, in order by Claim Number and Effective Dates.
							4. IF legacy rows exist, set the effective date of the earliest PCMP row to the last legacy row + 1 day.
							5. IF end date is equal to the effective date of the next row, subtract 1 day from the end date, to avoid conflicting date ranges.
							6. Merge the conurrent rows with the same type codes, combining the date ranges.
							7. Insert finished product into table */
							
							
							
/* Source Tables 		:   	PCMP.CLAIM_HISTORY 
								PCMP.CLAIM
								BWCFRZN.THFCLAT
					            DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM */
							
		
					
/* L1 Dependency 		: 	DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM */


--\set ON_ERROR_STOP on

/* 1. Select all rows from BWCFRZN.THFCLAT that were NOT current at go-live. Replace legacy type values with PS code values. Join to PCMP.CLAIM to get the AGRE_ID.
										i.e. ACCIDENT = 'acc'; OCCUPATIONAL DISEASE = 'occ_dis'; DEATH = 'dth'
2. Select all rows from PCMP.CLAIM_HISTORY. Use DATE() function on HIST_EFF_DTM and HIST_END_DTM to retrive only the date functions. Exclude rows where date(HIST_EFF_DTM) = date(HIST_END_DTM).
3. UNION results from steps 1 and 2, in order by Claim Number and Effective Dates. */

CREATE TEMPORARY TABLE NOI_TEMP  as
(SELECT 
C.AGRE_ID  AS CLM_AGRE_ID
,TRIM(T.CLAIM_NO) AS CLM_NO
,CASE 
    WHEN TRIM(CLAIM_TYPE_TEXT) = 'ACCIDENT' THEN 'acc'
    WHEN TRIM(CLAIM_TYPE_TEXT) = 'OCCUPATIONAL DISEASE' THEN 'occ_dis'
    WHEN TRIM(CLAIM_TYPE_TEXT) = 'DEATH' THEN 'dth'
END AS NOI_CTG_TYP_CD 
,DATE (T.CLAT_BGN_DATE) AS NOI_EFF_DATE_ORG
,DATE (T.CLAT_END_DATE) AS NOI_END_DATE_ORG
,'LGCY' AS SOURCE
FROM BWCFRZN.THFCLAT T
LEFT JOIN PCMP.CLAIM C 
ON C.CLM_NO = TRIM(T.CLAIM_NO)
WHERE CLAT_RLTNS_FLAG = 'N' 
ORDER BY T.CLAIM_NO,CLAT_BGN_DATE ASC )
UNION
(SELECT 
CH.AGRE_ID AS CLM_AGRE_ID
,CH.CLM_NO  AS CLM_NO
,CH.NOI_CTG_TYP_CD
,DATE (HIST_EFF_DTM) AS NOI_EFF_DATE_ORG
,DATE (HIST_END_DTM) AS NOI_END_DATE_ORG
,'PCMP' AS SOURCE
FROM PCMP.CLAIM_HISTORY CH
WHERE
(date(CH.HIST_EFF_DTM) <> date(CH.HIST_END_DTM) OR  HIST_END_DTM IS NULL)
AND CLM_REL_SNPSHT_IND = 'n'
order by CH.CLM_NO,NOI_CTG_TYP_CD ASC, HIST_EFF_DTM DESC );

/*4.IF legacy rows exist, set the effective date of the earliest PCMP row to the last legacy row + 1 day */
CREATE TEMPORARY TABLE NOI_TEMP1  as
SELECT 
A.CLM_AGRE_ID
,A.CLM_NO
,A.NOI_CTG_TYP_CD
,A.NOI_EFF_DATE_ORG
,case 
	When A.RANK =1 AND SOURCE ='PCMP' 	THEN  DATE (A.NOI_EFF_DATE_CHNG)  +1
else DATE(A.NOI_EFF_DATE_ORG)
end AS NOI_EFF_DATE_STG
,A.NOI_END_DATE_ORG
,A.RANK
,A.SOURCE
FROM 
(
SELECT 
CLM_AGRE_ID
,CLM_NO
,NOI_CTG_TYP_CD
,NOI_EFF_DATE_ORG
,LAG (NOI_END_DATE_ORG) over (partition by CLM_NO order by NOI_END_DATE_ORG )AS NOI_EFF_DATE_CHNG
,ROW_NUMBER() OVER (PARTITION BY CLM_NO,SOURCE ORDER BY NOI_EFF_DATE_ORG , NOI_END_DATE_ORG ) AS RANK
,NOI_END_DATE_ORG
,SOURCE 
FROM 
NOI_TEMP)A;

/*4.IF legacy rows exist, set the effective date of the earliest PCMP row to the last legacy row + 1 day 
		Taken care if  rows are only pcmp not in BWCFRZN.THFCLAT */
CREATE TEMPORARY TABLE NOI_TEMP11  as
SELECT 
A.CLM_AGRE_ID
,A.CLM_NO
,A.NOI_CTG_TYP_CD
,A.NOI_EFF_DATE_ORG
,case 
		When A.RANK2 =1  then DATE (A.NOI_EFF_DATE_ORG)
else DATE(A.NOI_EFF_DATE_STG) 
end AS NOI_EFF_DATE_CHNG
,A.NOI_END_DATE_ORG
,A.RANK
,A.RANK2
,A.SOURCE
FROM 
(
SELECT 
CLM_AGRE_ID
,CLM_NO
,NOI_CTG_TYP_CD
,NOI_EFF_DATE_ORG
,NOI_EFF_DATE_STG
,RANK
,CASE 
	WHEN RANK =1 AND NOI_EFF_DATE_STG IS NULL
		THEN ROW_NUMBER() OVER (PARTITION BY CLM_NO,SOURCE ORDER BY NOI_END_DATE_ORG ASC ) 
    ELSE NULL
  END AS RANK2
,NOI_END_DATE_ORG
,SOURCE 
FROM 
NOI_TEMP1 
) A;


/* 5.IF end date is equal to the effective date of the next row, subtract 1 day from the end date, to avoid conflicting date ranges. 
		  314 rows that have NULLs for NOI_CTG_TYP_CD and NOI_CTG_TYP_NM.  default those as “Accident”.  */
CREATE TEMPORARY TABLE NOI_TEMP2  as
SELECT 
CLM_AGRE_ID
,CLM_NO
,CASE 
	WHEN NOI_CTG_TYP_CD IS NULL
		  THEN  'acc'
	ELSE NOI_CTG_TYP_CD
   END AS NOI_CTG_TYP_CD
,NOI_EFF_DATE_ORG
,NOI_EFF_DATE_CHNG
,CASE
  WHEN 
  DATE(NOI_END_DATE_ORG) = LEAD(DATE(NOI_EFF_DATE_CHNG)) over (partition by CLM_NO order by NOI_END_DATE_ORG )
   THEN DATE (NOI_END_DATE_ORG ) -1
   ELSE NOI_END_DATE_ORG
   END 	AS NOI_END_DATE_CHNG
 ,NOI_END_DATE_ORG
  ,RANK
  ,RANK2
,SOURCE 
FROM 
NOI_TEMP11;

/*6. Merge the conurrent rows with the same type codes, combining the date ranges. */
     
CREATE TEMPORARY TABLE NOI_TEMP3  as 
SELECT DISTINCT  
A.CLM_AGRE_ID
,A.CLM_NO
, CASE 
	WHEN A.NOI_CTG_TYP_CD IS NULL
		  THEN  'acc'
	ELSE A.NOI_CTG_TYP_CD
   END AS NOI_CTG_TYP_CD
	 
,MIN (A.NOI_EFF_DATE_CHNG) AS NOI_EFF_DATE_CHNG
,MAX (A.NOI_END_DATE_CHNG) AS NOI_END_DATE_CHNG
,MIN (A.NOI_EFF_DATE_ORG) AS NOI_EFF_DATE_ORG
,MAX (A.NOI_END_DATE_ORG) AS NOI_END_DATE_ORG
,MAX (A.SOURCE) AS SOURCE
FROM ( SELECT CLM_AGRE_ID,CLM_NO,NOI_CTG_TYP_CD ,NOI_EFF_DATE_CHNG,NVL( NOI_END_DATE_CHNG,TO_DATE('9999-12-31','YYYY-MM-DD')) AS NOI_END_DATE_CHNG,coalesce(NOI_CTG_TYP_CD,'0') as no_null_NOI_CTG_TYP_CD,
		 CONDITIONAL_CHANGE_EVENT(no_null_NOI_CTG_TYP_CD) OVER(PARTITION BY CLM_AGRE_ID,CLM_NO ORDER BY NOI_EFF_DATE_CHNG,NOI_END_DATE_CHNG) CCE
         ,NOI_EFF_DATE_ORG,NOI_END_DATE_ORG,SOURCE
			FROM NOI_TEMP2
					ORDER BY CLM_NO,NOI_EFF_DATE_CHNG,NOI_END_DATE_CHNG) A
GROUP BY A.CLM_AGRE_ID,A.CLM_NO,A.NOI_CTG_TYP_CD,A.CCE;

/*7. Insert finished product into table */
TRUNCATE TABLE DW_REPORT.DW_CLAIM_NOI_HISTORY;
INSERT /*+DIRECT*/ INTO DW_REPORT.DW_CLAIM_NOI_HISTORY ( 
CLM_AGRE_ID
,CLM_NO
,NOI_CTG_TYP_CD
,NOI_CTG_TYP_NM
,NOI_EFF_DATE
,NOI_END_DATE
,CRNT_IND
,DW_CREATE_DTM
,DW_UPDATE_DTM
)
(
SELECT 
 CLM_AGRE_ID
,CLM_NO
,NOI_CTG_TYP_CD
,NICT.SRC_CODE_TEXT AS NOI_CTG_TYP_NM
,NOI_EFF_DATE_CHNG AS NOI_EFF_DATE
,CASE 
	WHEN NOI_END_DATE_CHNG = '9999-12-31'
	 THEN NULL
  ELSE NOI_END_DATE_CHNG 
 END AS NOI_END_DATE
,CASE 
	WHEN NOI_END_DATE_CHNG = '9999-12-31'
	 THEN 'y'
	ELSE 'n'
 END AS CRNT_IND
,CURRENT_DATE AS DW_CREATE_DTM
,CURRENT_DATE AS DW_UPDATE_DTM
FROM NOI_TEMP3 A 
LEFT JOIN (SELECT * FROM DW_REPORT.DW_REPORT_MSTR_TYPCODE_DIM WHERE SRC_TBL_NAME = 'NATURE_OF_INJURY_CATEGORY_TYPE') NICT ON  A.NOI_CTG_TYP_CD = NICT.SRC_CODE
ORDER BY CLM_NO,NOI_EFF_DATE_CHNG
 );
COMMIT;