# Configuration of DBSETUP

```python
config = {
    'env': {
        'tt': {
            'E21BSE': {
                'dbtype': 'oracle',
                'host': 'dmaslorcl01',
                'port': '1521',
                'service_name': 'e21bse.masl10devsrv1',  # ServiceName or SID
                'user': '',                              # Username used to login to Oracle
                'password': '',                          # Encrypted password (use base64, or encrypt.py )
                }
            },
        'dev': {
                'personal': {
                'dbtype': 'snowflake',
                'account': 'fbhs_gpg.east-us-2.azure' ,  # https://fbhs_gpg.east-us-2.azure (everything up to snowflakecomputing.com)
                'user': 'robert.metzker@fbwinn.com' ,    # Email address used for jamf
                'database': 'PLAYRGROUND' ,
                'role': 'DATALOAD_DEV' ,
                'warehouse': 'WH_DATALOAD_DEV' , 
                'schema':'ROBERT_METZKER',
                'authenticator': 'externalbrowser' ,     # externalbrowser, snowflake``
                'CLIENT_SESSION_KEEP_ALIVE': True ,     # 3600 default heartbeat freq in sec
            },
        }
    }```
